# UEMCP · UE 平面场景搭建（参考图驱动）

**编排层**：宿主 → 本 server（stdio）→ 官方 Unreal MCP（HTTP `127.0.0.1:8000`）→ UE。自己不碰 UE，改关卡 / 摆 Actor 都经官方工具集。

**阶段**：一资产确认、二平面放置规划、三资产布局生成**已实现**；四碰撞修正及以后**未实现** —— 问到时如实说"还没做"。

**硬规矩**：① 禁止猜"疑似资产"，名字对得上才算找到；② 用户确认前不落盘、不摆东西；③ **规划图没经用户确认不许进第三阶段**，数据与图缺一不可且必须一致；④ **绝不存盘**；⑤ 返回数字必须无损穿过 JSON（`-0.0` / `NaN` / `Infinity` 会被宿主整条拒收）。

**13 个工具**：`official_status`、`check_build_target`、`confirm_elements`、`plan_assets`、`rename_assets`、`confirm_assets`、`get_asset_list`、`generate_plan`、`get_plan`、`request_plan_change`、`confirm_plan`、`generate_build_orders`、`execute_build`。宿主不读 `instructions`，要求写在各工具 docstring 里。

**跑法**：DSH 以 stdio 启动；改完 `src/mcp_server/main.py` 后由**用户**跑 `tests/preflight.py`（脚本方式），绿了再重启。坑（取消域炸 server、规划层不能顶部 import、`find_assets` 不匹配文件夹名）见代码注释。

# =============================================================================
# 本 server 是编排层，自己不碰 UE：
#   宿主(agent) → 本 server → 官方 Unreal MCP（HTTP 127.0.0.1:8000）→ UE 编辑器
#
# 阶段一流程由用户定义、不许改（原文见 docs/阶段一-资产确认.md）：
#   ① 根据上传图片提取所需资产 → 让用户确认
#   ② 寻找资产：名字对得上就是找到了
#   ③ 没找到 → 禁止寻找疑似的，直接告知用户缺少什么资产
#   ④ 要求用户把"存在但是 agent 没找到"的资产的【路径 + 名字】告诉 agent
#   ⑤ 让 agent 重命名
#   ⑥ 确认资产列表，并向用户确认 → 交付资产清单
#
# 为什么"禁止猜"是硬规则：我给"名字是否规范"做过两版判据，两版都在实测里误报
#   （v1 长度+字符集、v2 连续辅音 ≥4）。根因是没有词典时，随机哈希和英文单词拼接
#   在字符层面无法区分。既然猜不准，就不猜 —— 用户指路，模型改名。
#
# 为什么必须支持"按文件夹名找"：官方 find_assets 的名字过滤只匹配资产名、
#   不匹配文件夹名（实测），哈希名资产（MI_sjfnch0a）靠资产名永远搜不到。
# =============================================================================

import hashlib
import json
import logging
import math
import re
import sys
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any

import anyio
from pydantic import BaseModel, Field

from mcp import Client
from mcp.server import MCPServer
from mcp.server.mcpserver import Context
from mcp.server.mcpserver.exceptions import ToolError

# 阶段二·规划层不能在文件顶部 import —— 见 _planning_modules() 里的血账说明：
#   宿主是按脚本方式起本文件（python ...\src\mcp_server\main.py），此时相对导入
#   `from .planning import ...` 会抛 "attempted relative import with no known parent package"。

# --- 常量 ---------------------------------------------------------------------

OFFICIAL_URL = "http://127.0.0.1:8000/mcp"

# 状态文件目录：项目根目录下的 catalog/（parents[0]=mcp_server, [1]=src, [2]=项目根）
STATE_DIR = Path(__file__).resolve().parents[2] / "catalog"
ELEMENTS_PATH = STATE_DIR / "elements.json"       # 用户确认过的元素清单
ASSET_LIST_PATH = STATE_DIR / "asset_list.json"   # 交付给用户的资产清单
LIBRARY_PATH = STATE_DIR / "library_snapshot.json"  # 资产库指纹（给清单"签字"用）

# 官方工具的"地址" = 工具集名 + 工具名
TS_ASSET = "editor_toolset.toolsets.asset.AssetTools"    # 找资产 / 改名 / 验证存在
TS_SCENE = "editor_toolset.toolsets.scene.SceneTools"    # 关卡信息 / 摆 Actor / outliner
TS_ACTOR = "editor_toolset.toolsets.actor.ActorTools"    # 读回变换 / 改标签 / 读组件
TS_PRIM = "editor_toolset.toolsets.primitive.PrimitiveTools"  # 白膜加图元（add_cube）
TS_OBJECT = "editor_toolset.toolsets.object.ObjectTools"  # 读对象属性（白膜尺寸在组件上）

# 资产类别 → 官方的类路径（find_assets 的 asset_type 要的是类路径）
CLASS_PRESETS: dict[str, str] = {
    "mesh": "/Script/Engine.StaticMesh",
    "material": "/Script/Engine.Material",
    "material_instance": "/Script/Engine.MaterialInstanceConstant",
    "texture": "/Script/Engine.Texture2D",
}
DEFAULT_ASSET_TYPES = ["mesh", "material_instance", "material"]
SIZE_QUERY_TYPES = {"mesh"}

# 关卡资产的类路径（find_assets 的 asset_type 要的是类路径）—— 用来列"项目里有哪些图"
LEVEL_CLASS_PATH = "/Script/Engine.World"

# 我们自己摆的东西都挂在 outliner 的这个根文件夹下（阶段三幂等对账的判据）
OUR_FOLDER_ROOT = "UEMCP"

# 阶段三 · 搭建指令表的落盘位置（给人看 / 给下一次执行读）
VIEWS_DIR = STATE_DIR.parent / "views"
BUILD_ORDERS_PATH = VIEWS_DIR / "build_orders_v1.json"

# 阶段三 · **搭建台账**（2026-09-26 增量改造新增）—— 记"上次到底搭了什么"。
# ⚠ 这是我们自己的 JSON（与 catalog/ 同类），**不是 UE 资产、不是关卡存盘** —— 不违反硬规矩。
# 为什么必须有它：没有台账，"增量"就无从判断关卡里哪个 Actor 对应指令表哪一行，
# 只能全量重摆（把用户根本没动过的东西也删一遍再摆一遍）。
BUILD_STATE_PATH = VIEWS_DIR / "build_state_v1.json"

# 阶段三 · **「搭哪张图」的答复台账**（2026-09-26 加）—— `check_build_target()` 把用户的答复记在这儿，
# `execute_build()` 落关卡前拿它**核对当前关卡**。
# 为什么必须有它（把软约束变硬）：`check_build_target` 是阶段三第 1 步，可代码里**从来没核对过
#   它跑没跑** —— 「拿到用户答复前一个 Actor 都不许放」只写在工具描述与 docs 里。
#   没读参数说明的 agent 会直接 `execute_build`，于是可能搭在错的图上（客户问过"你搭哪张图了"）。
BUILD_TARGET_PATH = VIEWS_DIR / "build_target_v1.json"

MIN_CONFIRM_DELAY_S = 15.0
"""确认前，那张图至少要"出炉"多少秒 —— **防机器人式秒确认**（2026-09-26 加）。

依据：**图是 agent 自己画的、确认也是它自己调的** —— 画完立刻 `confirm_plan`，只可能有一个意思：
它压根没把图给用户看（实测被这么绕过一次：客户原话「你摆你牛魔呢，图都不先让我确认就摆」）。
人看一眼平面图不可能 15 秒内完成，我们自己在图上核对一遍要几分钟。
⚠ 这是**可调的口径**（觉得太严/太松就改这个数），不是实测出来的物理常量。"""

# --- 阶段三 · 落位口径（**plan 里没有 Z** —— 竖直方向只能在这里推，依据照实写出来）----
# 为什么口径写在代码里而不是文档里：文档会腐烂，代码里的常量改不动就摆不出来。
# 下面每一条都标了依据；**没有依据的那就是不变量级的口径决定，不是实测**。

ROAD_SURFACE_Z_M = 0.0
"""车行道**路面**标高（米）= 0。

依据：`views/plan_v1.json` 的白膜行里，车行道那条的 note 写「路面标高」——
也就是说**路面就是 z=0 这个基准面**，其余东西相对它定高低。"""

GROUND_Z_M = 0.15
"""两侧地面（人行道 / 草坪的**顶面**）比路面高 **15 cm** —— 也就是路缘石的高度。

依据：plan 的人行道 / 连接路白膜行自带 `height_m = 0.15`（cube 厚 15 cm），
且同一条 note 写明「y-10～-8.5。cube 高 15 cm」—— 15 cm 就是这个高差。"""

WHITEBOX_VERTICAL: dict[str, tuple[str, float]] = {
    "road":     ("top", ROAD_SURFACE_Z_M),     # 路面本身：**顶面**压在路面标高上
    "sidewalk": ("bottom", ROAD_SURFACE_Z_M),  # 人行道：底面落路面，厚 15 cm → 顶面 = 地面
    "path":     ("bottom", ROAD_SURFACE_Z_M),  # 连接路：同上（也是 15 cm 厚）
    "grass":    ("top", GROUND_Z_M),           # 草坪：**顶面** = 两侧地面（薄板 5 cm）
    "shrub":    ("bottom", GROUND_Z_M),        # 灌木：站在 15 cm 高的地面上
}
"""白膜的竖直摆法：`(贴哪一头, 那一头的标高[米])`。

为什么要分「贴顶 / 贴底」：`PrimitiveTools.add_cube` 的方块**以 Actor 原点为中心**
（2026-09-26 实测，见 docs/阶段三 §11 第 4 条），所以拿到的是**中心点标高** ——
薄板（路面 / 草坪）该贴顶面，有厚度的台（人行道 / 连接路）与立着的东西（灌木）该贴底面。
**表里没有的 element_key 按 `("bottom", GROUND_Z_M)`**（立在地面上），并在报文里点名。"""

DEFAULT_SLAB_THICKNESS_CM = 15.0
"""`plane` 类白膜压成薄板时的**兜底**厚度（厘米）—— 只在阶段一清单里找不到该元素的
`size_cm[2]` 时才用。正常路径是取清单实测/登记的那个数（车行道 15、草坪 5）。"""

SURFACE_MATERIAL_HINT: dict[str, str] = {
    "road":     "/Game/demo/Landscape/mcp_mats/MI_Asphalt",
    "sidewalk": "/Game/demo/Landscape/mcp_mats/MI_Concrete",
    "path":     "/Game/demo/Landscape/mcp_mats/MI_Concrete",
    "grass":    "/Game/demo/Landscape/mcp_mats/MI_Lawn",
}
"""阶段六贴表面要用的材质实例 —— **阶段三一律不贴**，只原样记进指令表。

⚠ 这几个路径抄自**阶段一清单里那几行的备注**（「本轮新发现专用材质 MI_Asphalt」等）——
   阶段三**没有验证它们存在**，别把它当实测。要贴之前先 `exists()`。"""

ASSET_PIVOT_LIFT_CM: dict[str, float] = {
    "/Game/Fab/Tree/realistic_tree/StaticMeshes/realistic_tree": 31.44,
}
"""**原点不在底面**的资产：scale=1 时原点比底面高多少厘米。

依据：2026-09-26 官方 `get_bounds` 实测（docs/阶段三-资产布局生成.md §11 第 2 条）——
`realistic_tree` 在 scale 1、loc.z=0 时**底面在 -31.44 cm** → 让它站在标高 G 上，
原点得放到 `G + 31.44 × scale`；照 `loc.z = G` 硬摆会**沉进地里**（scale 0.31 时沉 9.75 cm）。
`house1` / `house2` 实测原点**就在底面**（bottom ≈ 0）→ 不在本表里 = 不用抬。
⚠ 这是**唯一一处**"按资产路径特判"的地方；多一个资产要特判就往这张表里加一行。"""

FOLDER_BY_ELEMENT: dict[str, str] = {
    "house":    f"{OUR_FOLDER_ROOT}/houses",
    "tree":     f"{OUR_FOLDER_ROOT}/trees",
    "road":     f"{OUR_FOLDER_ROOT}/road",
    "sidewalk": f"{OUR_FOLDER_ROOT}/sidewalk",
    "grass":    f"{OUR_FOLDER_ROOT}/grass",
    "path":     f"{OUR_FOLDER_ROOT}/paths",
    "shrub":    f"{OUR_FOLDER_ROOT}/shrubs",
}
"""元素 → outliner 分组。这是**幂等对账的判据**（清场只清 `UEMCP/` 下的），
也是用户能"一键清理"的抓手。表里没有的 element_key 落到 `UEMCP/<element_key>`。"""

ACTOR_CLASS_PATH = "/Script/Engine.Actor"
"""白膜用的空 Actor 类 —— 2026-09-26 实测 `add_to_scene_from_class` 可以 spawn 它
（docs/阶段三 §11 第 3 条）。"""


def _ref_path(value: Any) -> str:
    """从官方返回里取 `refPath`（对象引用）。

    官方把 UObject 引用序列化成 `{"refPath": "..."}`；但**不能假设它一定是这个形状** ——
    实测个别接口会直接把字符串丢回来。取不到就返回空串（调用方据此判"没拿到 Actor"），
    **绝不编一个路径**。
    """
    if isinstance(value, dict):
        ref = value.get("refPath")
        return str(ref) if ref else ""
    if isinstance(value, str):
        return value
    return ""


def _angle_close(a: float, b: float, tol: float = 0.05) -> bool:
    """两个 yaw（度）算不算同一个朝向 —— **按角度差比，不按数值比**。

    为什么不能直接 `abs(a-b) <= tol`（2026-09-26 实测踩到）：UE 把 yaw 折进 **±180** 存，
    指令里写 `270`、`get_actor_transform` 读回来是 `-90` —— **同一个朝向**，
    数值相减却是 360。第一版就是这么比的，于是刚摆好的 5 栋房子里有 2 栋被误报"对不上"。
    """
    return abs((a - b + 180.0) % 360.0 - 180.0) <= tol


def _safe_actor_name(label: str, index: int, element_key: str) -> str:
    """人话标签 → **UE 能当对象名用的字符串**。

    plan 的 label 是中文带括号的（「住宅 #1（house1）」），直接当 Actor 名有风险
    （括号 / `#` / 空格都可能被拒）。这里只保留中日韩汉字、字母、数字、下划线、连字符，
    其余一律换成下划线 —— 结果是**可读且唯一**（label 本来就一物一个），
    省掉了"先摆再改标签"的 60 次调用。
    真要是标签被洗成空串（纯符号），退回 `元素名_序号` 兜底。
    """
    safe = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]", "_", str(label or ""))
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or f"{element_key or 'actor'}_{index:03d}"


# --- [完工-01] 官方连接（由专用 task 持有，全程复用一条连接）---
# 实测 2026-09-23 12:07 起本会话持续服务：数十次官方调用，无 cancel-scope 崩溃。
#
# 为什么必须是"专用 task"（2026-09-23 实测定案，别改回去）：
#   `mcp.Client.__aenter__` 会把 streamable-http 传输压进一个 AsyncExitStack，
#   而这个传输内部会 `async with anyio.create_task_group()` —— 即进入一个取消域。
#   anyio 的铁律：取消域只能由进入它的那个 task 退出。旧写法在【工具调用的 task】里
#   建连接、却在【lifespan 的 task】里关，跨 task 退出必抛
#   RuntimeError: Attempted to exit a cancel scope that isn't the current tasks's
#   current cancel scope —— 它穿透 SDK 派发器的 task group，整个 server 进程退出。
#   修法：建和关都收进同一个 task（`_connection_loop`），取消域进出同源。
#   ⚠ 别再往 `asyncio.Lock` 上找：去掉锁之后它照样发生，真凶是上面这个"跨 task 关闭"。
#
RETRY_SECONDS = 3.0
"""连不上官方时的重试间隔（秒）。编辑器没开时会一直按这个间隔重试。"""

READY_TIMEOUT = 15.0
"""工具调用等"连接 task 首次表态"的上限（秒）；超时就抛 ToolError，而不是干等。"""


@dataclass
class AppContext:
    """服务器生命周期内共享的状态：一条官方连接 + 两个同步信号。

    所有权约定（**改这个文件时请守住**）：
      - `ue` 只有 `_connection_loop` 这一个 task 会写，其它 task 只读；
      - 谁都不许在工具调用的 task 里创建或关闭官方客户端 —— 那正是炸进程的原因。
    """

    ue: Any = None
    """官方 MCP 客户端。**只能由连接 task 创建和关闭**；工具调用只读它、用它发请求。"""

    ready: Any = None
    """连接 task 首次表态（连上 or 失败）后 set，让工具调用不必干等。"""

    stop: Any = None
    """要求连接 task 断开重连的信号。工具调用发现连接死了就 set 它。"""

    error: str = "尚未连上（连接 task 还在重试）"
    """最近一次连接失败的原因原文，拼进 ToolError 给用户看。"""


async def _connection_loop(app: AppContext) -> None:
    """专用连接 task：**唯一**允许创建/关闭官方客户端的地方。

    循环做三件事：
      ① 建连接（进入 `async with client`）；
      ② 把连接借出去 —— 挂在 `app.stop.wait()` 上不动；
      ③ 被要求重连（`app.stop` 被 set）或连不上时，退出 `async with`
         （**在同一个 task 里关**），歇一会儿回到 ①。

    ⚠ `app.stop` 每轮都换一个新的 `anyio.Event`：Event 一旦 set 就不会自动复位，
      不换的话第二轮会立刻又"被要求重连"，变成死循环。
    ⚠ `except Exception` 接不住 `CancelledError`（它是 `BaseException` 的子类）——
      这正是我们要的：关机时 task group 取消本 task，取消要能正常往外抛；
      而 `finally` 照样会执行。
    """
    log = logging.getLogger(__name__)
    while True:
        app.stop = anyio.Event()
        app.ue = None
        client = Client(OFFICIAL_URL)
        backoff = RETRY_SECONDS
        try:
            async with client:
                app.ue = client
                app.error = ""
                log.info("已连上官方 Unreal MCP：%s", OFFICIAL_URL)
                # 连上就**立刻**表态放行等待者，不能等退出 async with 才表态：
                # 下面要挂在这里把连接借出去、可能挂很久；若只在 finally 里 set，
                # 工具调用会一直等 ready 直到 READY_TIMEOUT 超时 —— 而日志里明明
                # 已经打了"已连上官方 Unreal MCP"（这个坑我实测踩到过）。
                if app.ready is not None:
                    app.ready.set()
                await app.stop.wait()
                backoff = 0.5
        except Exception as exc:
            app.error = f"{type(exc).__name__}: {exc}"
            log.warning("连不上官方 Unreal MCP（%s）：%s", OFFICIAL_URL, exc)
        finally:
            app.ue = None
            if app.ready is not None:
                app.ready.set()
        await anyio.sleep(backoff)


async def official_client(ctx: Context[AppContext]) -> Any:
    """取当前可用的官方客户端；没连上就抛 ToolError（给模型看人话，而不是崩栈）。

    连不上是**可预期**的（编辑器没开），所以这里一律转成 ToolError 原文说明，
    不把底层异常抛给协议层。
    """
    app = ctx.request_context.lifespan_context
    try:
        # 等连接 task 首次表态：server 刚起来时它可能还在握手，直接判失败会误报
        with anyio.fail_after(READY_TIMEOUT):
            await app.ready.wait()
    except TimeoutError:
        raise ToolError(
            f"等官方连接就绪超时（{READY_TIMEOUT:.0f} 秒）：{app.error or '连接仍无结果'}"
        ) from None
    if app.ue is None:
        raise ToolError(
            f"连不上官方 Unreal MCP（{OFFICIAL_URL}）："
            f"{app.error or '连接正在重建，请稍后重试'}。"
            f"请确认 ① UE 编辑器已打开 ② ModelContextProtocol 插件已启用 "
            f"③ 端口 8000 在监听。"
        )
    return app.ue


@asynccontextmanager
async def app_lifespan(server: MCPServer):
    """服务器启动时拉起连接 task，关闭时收回（不留孤儿 task）。

    ⚠ 两处必须"同源"，这是修复的全部要点：
      - task group 在**本 lifespan 的 task** 里进、也在本 task 里出；
      - 官方客户端的进/出都发生在**子 task**（`_connection_loop`）内部。
      两者互不越界，所以不会再出现"取消域跨 task 退出"的 RuntimeError。

    ⚠ 这里**不再吞异常**：旧版在 finally 里 `except BaseException` 把关闭连接的
      错误咽掉，结果只是把崩溃推迟到了 SDK 派发器的 task group（那里没人接），
      照样炸进程。现在关闭动作归连接 task 所有，它自己的收尾由 anyio 的
      task group 负责，不需要这里兜。
    """
    app = AppContext(ready=anyio.Event(), stop=anyio.Event())
    async with anyio.create_task_group() as tg:
        tg.start_soon(_connection_loop, app)
        try:
            yield app
        finally:
            tg.cancel_scope.cancel()


# 顺序很关键：app_lifespan 必须在 MCPServer(...) 之前定义；
# mcp 必须在任何 @mcp.tool() 之前存在（装饰器在"定义时"就执行）。
#
# 为什么没有 instructions=（2026-09-23 实测，别加回来）：本宿主不读 MCP 的
# instructions（dsh-mcp-client 的 connect() 返回值连赋值都没有）。
# 真正到模型眼前的是 tools/list（工具名 + 描述 + schema），
# 所以要求写在各工具的 docstring 里。
mcp = MCPServer("UEMCP-SceneLayout", lifespan=app_lifespan)


# --- [完工-02] 厚函数（纯逻辑，不碰网络，可直接单测）---
# 实测 2026-09-23 12:07–12:24：token_match / num / size_from_box / parse_return /
# to_object_path / load_json / save_json 经 plan_assets、confirm_assets 反复调用。

def parse_return(text: str) -> Any:
    """把官方返回的那段文本解析成 Python 对象。

    官方返回值包在 {"returnValue": ...} 里。解析失败就把原文当字符串返回 ——
    免得因为格式差异整个工具崩掉。
    """
    if not text:
        return None
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        return text
    if isinstance(data, dict) and "returnValue" in data:
        return data["returnValue"]
    return data


def to_object_path(package_path: str) -> str:
    """包路径 → 对象路径。

    官方有些接口不接受 "/Game/A/B/house1"，要 "/Game/A/B/house1.house1"
    （对象路径 = 包路径 + "." + 资产名）。这条是实测踩出来的。
    """
    name = package_path.rsplit("/", 1)[-1]
    return f"{package_path}.{name}"


def token_match(keyword: str, text: str) -> bool:
    """词边界匹配 —— 专门对冲官方"纯子串"的缺陷。

    官方 find_assets 的名字过滤是纯子串：搜 "Tree" 会命中 "s**tree**t_lamp_01_4k"（路灯）。
    这里把文本切成"词"（按 _ - 空格 以及小写转大写的边界切），
    要求关键词作为**一个完整的词**出现才认；也允许"词 + 数字后缀"（house → house1）。
    """
    kw = keyword.lower().strip()
    if not kw:
        return False

    words: list[str] = []
    for part in text.replace("-", "_").replace(" ", "_").split("_"):
        chunk = ""
        prev_lower = False
        for ch in part:
            if ch.isupper() and prev_lower:
                if chunk:
                    words.append(chunk)
                chunk = ch
            else:
                chunk += ch
            prev_lower = ch.islower()
        if chunk:
            words.append(chunk)

    for word in words:
        low = word.lower()
        if low == kw:
            return True
        # house → house1：允许关键词后面直接跟数字
        if low.startswith(kw) and low[len(kw):].isdigit():
            return True
    return False


def num(value: Any, digits: int = 2) -> float:
    """把官方给的数字变成"能安全穿过 JSON 的数字"。三件事缺一不可：

      ① float()  —— 官方有时把数字包成字符串
      ② round()  —— 去掉浮点噪声
      ③ 负零归一 + 非有限值兜底

    ⚠ 为什么必须管负零（-0.0）：Python 把 -0.0 序列化成 "-0.0"，而 JS 的
      JSON.stringify(-0) 得到 "0"，往返不无损。宿主会据此判定整个工具返回值
      "value is not lossless JSON" 并**整条拒绝** —— 不是丢一个字段，是工具直接不可用。
      实测（2026-09-23）：get_scene_context(limit=6) 结果里 0 个负零 → 成功；
      limit=15/40 各含 1 个负零（actors[7].center_cm[0] = -0.0）→ 宿主报错整条拒收。
      触发条件：某个物体的中心坐标恰好压在某根轴上。
    """
    v = round(float(value), digits)
    if not math.isfinite(v):
        # inf/nan 会让 JSON 写成 Infinity/NaN，同样被宿主整条拒收。
        return 0.0
    return 0.0 if v == 0 else v


def size_from_box(box: Any) -> list[float] | None:
    """把官方包围盒换算成 [X, Y, Z] 尺寸（厘米）。"""
    if not isinstance(box, dict) or not box.get("isValid"):
        return None
    mn, mx = box.get("min"), box.get("max")
    if not isinstance(mn, dict) or not isinstance(mx, dict):
        return None
    return [
        num(float(mx["x"]) - float(mn["x"])),
        num(float(mx["y"]) - float(mn["y"])),
        num(float(mx["z"]) - float(mn["z"])),
    ]


# --- 白膜占位（阶段一「没有资产可用」的元素）------------------------------------
# 2026-09-24 用户要求（原文见 docs/阶段一-资产确认.md 第四节）：
#   「用户确认没有的资产，以及用材质实例顶替的资产都要先预估尺寸并用白膜替代，
#     然后再让用户确认资产清单」。
# 这里只是清单登记 —— 阶段一不许往关卡里摆任何东西（硬规则 4）。

PLACEHOLDER_SHAPES = ("cube", "plane")
"""白膜形状：`cube`（体，如窗户 / 车道）/ `plane`（面，如马路 / 草坪）。

`cube` 要有**体积**（三个数），`plane` 是**覆盖面**（至少 X、Y）。
阶段六按这个形状用官方 PrimitiveTools 往 Actor 上加图元。
"""

SIZE_SOURCE_ESTIMATED = "预估（参考图目测，待核实）"
"""白膜行的标准尺寸来源文案 —— **预估值不许伪装成实测值**（硬规则 6）。"""

SIZE_SOURCE_ESTIMATED_LEGACY = "预估（待核实）"
"""旧写法，同样只表示「这是估的」（`placeholder_errors()` 按 `"预估" in src` 判合格）。"""

MATERIAL_ONLY_MARK = "命中的全是非网格资产"
"""`plan_assets` 的 `placeholder_hint` 里，用来标"这个元素只命中材质"的那句话。

单独拎成常量：生成它的地方和回头筛它的地方各写一份字面量的话，
改一处忘一处就会静默漏报（不报错，只是少一条提醒）。"""


def placeholder_errors(item: Any) -> list[str]:
    """校验**一行白膜占位**填得合不合规矩；返回错误清单（空 = 合格）。

    为什么要有这个函数：白膜行是"没有可用资产"的元素在清单里的**唯一交代**。
    它一旦填得不完整（没写形状 / 没给尺寸 / 尺寸来源不是预估），
    读表的人就会把**预估值当实测值**用 —— 那正是硬规则 6 要挡的事。
    所以宁可当场拒收，也不放一行"看着像资产"的白膜进去。

    四道校验：
      ① `asset_path` 必须**空** —— 白膜就是没有资产，带路径是自相矛盾；
      ② `placeholder_shape` 必须是 `cube` / `plane` 之一（不给就是没形状，阶段六没法实例化）；
      ③ `size_cm` 至少给 X、Y（`cube` 还要 Z，要有体积）；
      ④ `size_source` 必须写明是**预估**（默认值也算）—— 不许让预估值看起来像实测值。
    """
    errs: list[str] = []
    name = str(getattr(item, "element", "") or "?")

    if str(getattr(item, "asset_path", "") or "").strip():
        errs.append(
            f"{name!r}：白膜占位行的 asset_path **必须是空的**（白膜就是「没有可用资产」），"
            f"现在填了 {getattr(item, 'asset_path', '')!r} —— "
            "要么把它改成真资产行（is_placeholder=false），要么把路径清空。"
        )

    shape = str(getattr(item, "placeholder_shape", "") or "").strip().lower()
    if shape not in PLACEHOLDER_SHAPES:
        errs.append(
            f"{name!r}：白膜占位行必须填 placeholder_shape，"
            f"只能是 {' / '.join(PLACEHOLDER_SHAPES)}（现在填的是 {shape!r}）。"
            "cube = 有体积的（窗 / 车道），plane = 覆盖面（马路 / 草坪）——"
            "阶段六要按这个形状加图元。"
        )

    size = getattr(item, "size_cm", None)
    n = len(size) if isinstance(size, (list, tuple)) else 0
    if n < 2:
        errs.append(
            f"{name!r}：白膜占位行必须给**预估尺寸** size_cm（厘米，至少 X、Y）；"
            + ("cube 还要给 Z（要有体积）。" if shape == "cube" else "")
        )
    elif shape == "cube" and n < 3:
        errs.append(f"{name!r}：cube（体）类的白膜要给三个数 [X, Y, Z] —— 现在只有 {n} 个。")

    src = str(getattr(item, "size_source", "") or "").strip()
    if src and "预估" not in src:
        errs.append(
            f"{name!r}：白膜占位行的尺寸是**估的**，size_source 必须写明"
            f"（建议原样写 {SIZE_SOURCE_ESTIMATED!r}），现在写的是 {src!r} —— "
            "预估值不许伪装成实测值。"
        )
    return errs


def load_json(path: Path) -> Any:
    """读状态文件；不存在返回 None（第一次跑本来就没有，不是错误）。"""
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    """写状态文件（目录不存在就先建整条路径）。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# --- 大类表（阶段一「元素 → 大类」的词表）---------------------------------------
# 2026-09-24 用户要求：先有这张大类表（照 Fab 的 3D 分类树），根据参考图把它填好，再去按类找资产。

CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"
CATEGORY_PATH = CONFIG_DIR / "asset_categories.json"
UNCATEGORIZED = "uncategorized"
UNCATEGORIZED_CN = "未分类"


def load_categories() -> dict:
    """读大类表 → `{by_key, order, kinds, scene_keys, value_field, how_to_fill, fallback_*, defined}`。

    - `by_key`      : key → 中文名
    - `kinds`       : key → `asset`（要去资产库找）/ `scene`（场景级信息，**不是资产**）
    - `value_field` : scene 项的值填在 `ElementItem` 的哪个字段（如地图大小 → size_m）
    ⚠ 读不到表**不报错**，退化成"只有未分类一项" —— 缺一张词表不该把阶段一整条链卡死；
      但 `defined` 会如实报出表里原有几项，调用方一眼能看出表丢了。
    """
    doc = load_json(CATEGORY_PATH) or {}
    by_key: dict[str, str] = {}
    order: list[str] = []
    kinds: dict[str, str] = {}
    value_field: dict[str, str] = {}
    how_to_fill: dict[str, str] = {}
    for c in (doc.get("categories") or []):
        if not isinstance(c, dict):
            continue
        k = str(c.get("key") or "").strip()
        if not k or k in by_key:
            continue
        by_key[k] = str(c.get("cn") or k)
        order.append(k)
        kinds[k] = "scene" if str(c.get("kind") or "asset").strip() == "scene" else "asset"
        value_field[k] = str(c.get("value_field") or "")
        how_to_fill[k] = str(c.get("how_to_fill") or "")
    fb_key = str(doc.get("fallback_key") or UNCATEGORIZED)
    fb_cn = str(doc.get("fallback_cn") or UNCATEGORIZED_CN)
    if fb_key not in by_key:
        by_key[fb_key] = fb_cn
        order.append(fb_key)
        kinds[fb_key] = "asset"
    return {
        "by_key": by_key,
        "order": order,
        "kinds": kinds,
        "scene_keys": [k for k in order if kinds.get(k) == "scene"],
        "value_field": value_field,
        "how_to_fill": how_to_fill,
        "fallback_key": fb_key,
        "fallback_cn": fb_cn,
        "defined": len(order) - 1,
    }


def category_kind(key: str, table: dict | None = None) -> str:
    """这个大类是 `asset`（找资产）还是 `scene`（场景级信息，不是资产）；未分类算 asset。"""
    t = table if table is not None else load_categories()
    return t["kinds"].get((key or "").strip(), "asset")


def is_scene_category(key: str, table: dict | None = None) -> bool:
    """是不是"场景项"（地图大小 / 地图对应时间）—— 这类**不许去搜资产、也不许当白膜**。"""
    return category_kind(key, table) == "scene"


def category_cn(key: str, table: dict | None = None) -> str:
    """大类 key → 中文名（查表；空 key = 未分类）。

    ⚠ 查不到就写 `<key>（不在大类表里）`，**不编**一个中文名、也不静默吞成"未分类" ——
      表改过 / 手改过数据时要看得见。
    """
    t = table if table is not None else load_categories()
    k = (key or "").strip()
    if not k:
        return t["fallback_cn"]
    return t["by_key"].get(k, f"{k}（不在大类表里）")


def group_elements_by_category(items: list[dict], table: dict | None = None) -> dict:
    """把带 `category` 的行分组 → `{中文大类名: [元素名, ...]}`，**顺序照表**，未分类排最后。

    键用中文名：这份分组是要**直接给人看**的（"填好的表"），读表的人不该去猜 furniture 是什么。
    表里没有的大类（旧数据 / 手改）放最后 —— **不许丢**。
    """
    t = table if table is not None else load_categories()
    buckets: dict[str, list[str]] = {}
    for it in items:
        if not isinstance(it, dict):
            continue
        cn = category_cn(str(it.get("category") or ""), t)
        buckets.setdefault(cn, []).append(str(it.get("element") or ""))
    ordered: dict[str, list[str]] = {}
    for k in t["order"]:
        cn = t["by_key"][k]
        if cn in buckets:
            ordered[cn] = buckets.pop(cn)
    for cn in sorted(buckets):
        ordered[cn] = buckets[cn]
    return ordered


def order_category_names(names: set[str], table: dict | None = None) -> list[str]:
    """把一组中文大类名按**表里的顺序**排好；表外的（未分类 / 手改过的）放最后 —— **不丢**。"""
    t = table if table is not None else load_categories()
    order = [t["by_key"][k] for k in t["order"]]
    return [cn for cn in order if cn in names] + sorted(cn for cn in names if cn not in order)


def scene_from_rows(rows: list[dict], table: dict | None = None) -> tuple[dict, list, str]:
    """从表里 `kind=scene` 的行抽出场景项。

    返回 `({中文名: 人话值}, 地图大小 [X,Y] 或 None, 时间字符串)`。
    值填在哪个字段由**表**决定（`value_field`）—— 代码不写死 key，
    以后往表里加第三个场景项，只要表里写清 value_field 就能自动带出来。
    """
    t = table if table is not None else load_categories()
    scene: dict[str, str] = {}
    size_m: list[float] | None = None
    tod = ""
    for e in rows:
        if not isinstance(e, dict):
            continue
        cat = str(e.get("category") or "")
        if not is_scene_category(cat, t):
            continue
        cn = t["by_key"].get(cat, cat)
        vf = t["value_field"].get(cat, "")
        raw = e.get("size_m")
        if vf == "size_m" and isinstance(raw, (list, tuple)) and len(raw) >= 2:
            size_m = [float(raw[0]), float(raw[1])]
            scene[cn] = f"{size_m[0]:g}×{size_m[1]:g} m（预估）"
        elif vf == "time_of_day" and str(e.get("time_of_day") or "").strip():
            tod = str(e["time_of_day"]).strip()
            scene[cn] = tod
        else:
            scene[cn] = str(e.get("note") or "(未记录)")
    return scene, size_m, tod


def library_fingerprint(inventory: dict[str, list[str]]) -> tuple[str, dict[str, int]]:
    """把「资产库快照」压成一个 sha256 指纹 + 每类数量。

    为什么需要它：`delivered_at` 只能说明"什么时候确认的"，回答不了"项目变没变"。
    这里**只对路径负责**：同一批路径（与枚举顺序无关）→ 同一个指纹。

    ⚠ 路径没变、资产**内容**变了（换贴图、改材质参数）**测不出来** —— 这是刻意的取舍：
      要覆盖内容得上资产 GUID / 磁盘时间戳，成本高一个量级。
      所以交付文案里要写明：清单承诺的是**路径有效**，不是**内容没变**。
    """
    parts: list[str] = []          # 每一类压成一段字符串，最后整体哈希
    counts: dict[str, int] = {}    # 每类多少个，用于"58 → 56"这种人话差异
    for type_name in sorted(inventory):          # 排序：让指纹与字典顺序无关
        paths = sorted(inventory[type_name])     # 排序：让指纹与官方返回顺序无关
        counts[type_name] = len(paths)
        parts.append(f"{type_name}:{len(paths)}:" + "|".join(paths))
    digest = hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()
    return digest, counts


def describe_count_changes(signed: dict[str, int], live: dict[str, int]) -> list[str]:
    """把「签字时」与「现在」的数量差异说成人话，只报变了的那几类。

    例子：`["material_instance: 58 → 56"]` —— 这正是 2026-09-23 那次
    `/Game/Fab/Urban_Street_Pack` 整个包消失时该出现的信号。
    """
    out: list[str] = []
    for type_name in sorted(set(signed) | set(live)):   # 并集：一方没有的类也要比
        before, after = signed.get(type_name, 0), live.get(type_name, 0)
        if before != after:
            out.append(f"{type_name}: {before} → {after}")
    return out


def element_keys_from_items(items: list[dict]) -> tuple[set[str], str]:
    """从交付表的行里取出「已经落位的元素关键词」，以及**用的是哪种判定方式**。

    优先用 `element_key`（显式标注，最可靠）；旧表没有这个字段，
    退回"标签首词"（如 `"house 主屋"` → `house`）—— 那是**推断**，
    所以把用的哪种方式一起返回，别让推断冒充事实。
    """
    keys: set[str] = set()
    explicit = 0
    for it in items:
        key = str(it.get("element_key") or "").strip().lower()
        if key:
            explicit += 1
            keys.add(key)
            continue
        label = str(it.get("element") or "").strip()
        if label:
            keys.add(label.split()[0].lower())   # split()[0] = 以空白切开取第一个词
    if items and explicit == len(items):
        mode = "element_key 显式标注"
    elif explicit:
        mode = f"混合（{explicit}/{len(items)} 行有 element_key，其余按标签首词推断）"
    else:
        mode = "标签首词推断（表里没有 element_key）"
    return keys, mode


# --- [完工-03] 官方调用与枚举/实测（call_official / library_inventory / measure_asset）---
# 实测 2026-09-23 12:24：confirm_assets 用它量到 4 个网格的包围盒，
# 并对 2 个材质如实报"material_instance 没有包围盒"（没编数字）。


async def call_official(
    ctx: Context[AppContext], tool_name: str, arguments: dict, toolset: str | None = None
) -> Any:
    """调用官方的一个能力，并把结果解析成 Python 对象。

    两种调用方式（实测）：
      - toolset=None   → 直接调官方**元工具**（list_toolsets / describe_toolset / call_tool）
      - toolset=某工具集 → 经元工具 call_tool 转发到具体工具
        （官方 Tool Search 默认开着，具体工具不出现在 tools/list 里，只能这样转发）

    ⚠ 连接由 `_connection_loop` 持有：这里**只借用，不建也不关**
      （原因见本文件顶部"官方连接"那段）。
    """
    if toolset is None:
        mcp_tool, payload = tool_name, arguments
    else:
        mcp_tool = "call_tool"
        payload = {"toolset_name": toolset, "tool_name": tool_name, "arguments": arguments}

    app = ctx.request_context.lifespan_context
    client = await official_client(ctx)

    async def once(target: Any) -> Any:
        result = await target.call_tool(mcp_tool, payload)
        if result.is_error:
            text = result.content[0].text if result.content else "(无内容)"
            raise ToolError(f"官方工具 {tool_name} 返回错误：{text}")
        text = result.content[0].text if result.content else ""
        return parse_return(text)

    try:
        return await once(client)
    except ToolError:
        raise
    except Exception as first_error:
        # 连接可能已经死了（编辑器关了、会话被踢）。不能在这里关连接 ——
        # 只发一个"请重连"的信号，让连接 task 在它自己的 task 里收尾并重建。
        app.stop.set()
        new_client = None
        for _ in range(60):
            await anyio.sleep(0.1)
            if app.ue is not None and app.ue is not client:
                new_client = app.ue
                break
        if new_client is None:
            raise ToolError(
                f"调用官方 {tool_name} 失败，且自动重连没成功：{first_error}"
            ) from first_error
        try:
            return await once(new_client)
        except Exception as second_error:
            raise ToolError(
                f"调用官方 {tool_name} 失败（已重试一次）："
                f"第一次 {first_error}；第二次 {second_error}"
            ) from first_error


async def library_inventory(
    ctx: Context[AppContext]
) -> tuple[dict[str, list[str]], int]:
    """实况枚举项目资产库：**每类一次** find_assets（空名字 = 全都要）。

    返回 `(库存, 调了几次官方)`；库存形如 `{"mesh": ["/Game/..."], ...}`（已排序）。

    ⚠ 这里是**唯一一份**枚举逻辑：`plan_assets` 和 `get_asset_list` 都调它
      （2026-09-23 用户拍板合并）。
    返回的路径已排序：让指纹与枚举顺序无关，也让"截前 N 个"更确定。
    """
    inventory: dict[str, list[str]] = {}
    calls = 0
    for type_name in DEFAULT_ASSET_TYPES:
        class_path = CLASS_PRESETS.get(type_name)
        if class_path is None:
            continue
        paths = await call_official(
            ctx,
            "find_assets",
            {
                "folder_path": "/Game",
                "name": "",                     # 空名字 = 全都要（这就是"枚举"）
                "asset_type": {"refPath": class_path},
                "recursive": True,
            },
            toolset=TS_ASSET,
        )
        calls += 1
        inventory[type_name] = sorted(p for p in (paths or []) if isinstance(p, str))
    return inventory, calls


async def measure_asset(
    ctx: Context[AppContext], asset_path: str, asset_type: str = ""
) -> tuple[list[float] | None, float | None, str]:
    """量一个资产的**包围盒**尺寸与体积，返回 `(尺寸, 体积, 来源说明)`。

    为什么由工具来量、不让调用方填：
      "我以为它多大"和"它真的多大"是两回事 —— 尺寸拿去算缩放倍数，
      填错一个数，摆出来的房子就是错的比例。所以**实测值覆盖**调用方填的值。

    只有网格有包围盒；材质/材质实例一律返回 `(None, None, 原因)`。类别判定三档：
      ① `asset_type` 就在本 server 的类别表 `CLASS_PRESETS` 里 → 直接按它判，省一次调用；
      ② 不在表里（空值或别的写法）→ 问官方 `get_asset_class()` 拿类名再判；
      ③ 量取失败 → **原样带上官方报错，绝不编一个数字**。
    """
    resolved = asset_type
    if resolved not in CLASS_PRESETS:
        try:
            cls_name = await call_official(
                ctx, "get_asset_class", {"asset_path": asset_path}, toolset=TS_ASSET
            )
        except ToolError as exc:
            return None, None, f"类别没查到：{exc}"
        cls_text = str(cls_name or "")
        if "StaticMesh" in cls_text:
            resolved = "mesh"
        else:
            return None, None, f"{cls_text or '类别未知'} 没有包围盒"

    if resolved not in SIZE_QUERY_TYPES:
        return None, None, f"{resolved} 没有包围盒"

    try:
        box = await call_official(
            ctx,
            "get_bounds",
            {"mesh": {"refPath": to_object_path(asset_path)}},
            toolset="editor_toolset.toolsets.static_mesh.StaticMeshTools",
        )
    except ToolError as exc:
        return None, None, f"量取失败：{exc}"

    size = size_from_box(box)
    if size is None:
        return None, None, "官方没给出有效包围盒"
    volume = num(size[0] * size[1] * size[2])
    return size, volume, "官方 get_bounds 实测（包围盒）"


# --- [完工-04] 模型（工具返回结构 = 模型看到的"参数说明书"）---
# 实测 2026-09-23 12:12 / 12:24：confirm_assets 与 get_asset_list 完整序列化往返，
# 含新增的 size_cm / bbox_volume_cm3 / size_source / items。

class OfficialStatus(BaseModel):
    """官方链路自检结果。"""

    reachable: bool = Field(description="能不能连上官方 Unreal MCP")
    protocol_version: str | None = Field(default=None, description="协商出的 MCP 协议版本")
    toolset_count: int = Field(default=0, description="官方一共有多少个工具集")
    error: str | None = Field(default=None, description="连不上时的错误原文")


class BuildTargetCheck(BaseModel):
    """阶段三第 1 步（**只读**）：先问清"搭哪儿"，不碰用户的关卡。"""

    stage: str = Field(description="阶段名")
    readonly: bool = Field(
        description=("恒 True：本工具**不碰关卡** —— 不新建/不切换关卡、不摆不删任何 Actor、不存 UE。"
                     "唯一会写的是我们自己的 `views/build_target_v1.json`（答复台账）"))
    official_calls: list[str] = Field(
        default_factory=list,
        description="这次只读地问了官方哪些东西（留痕，方便复核「它真没动手」）")
    current_level: str = Field(description="UE 当前打开的关卡路径")
    candidate_levels: list[str] = Field(
        default_factory=list, description="项目里可选的关卡资产（供用户指定「用哪张图」）")
    our_folders: list[str] = Field(
        default_factory=list, description=f"当前关卡里属于 {OUR_FOLDER_ROOT} 的 outliner 文件夹")
    our_actor_count: int = Field(default=0, description=f"当前关卡里 {OUR_FOLDER_ROOT}/ 下的 Actor 数")
    total_actors: int = Field(default=0, description="当前关卡里的 Actor 总数")
    can_create_level: bool = Field(
        default=False, description="官方有没有「新建关卡」的工具（实测：**没有**，只有 load_level）")
    decision: str = Field(
        default="",
        description=("用户答复的目标：`current`（就用当前这张）/ `existing`（指定的既有图）/ "
                     "`new`（开新图）；**空 = 还没拿到答复**（那 `execute_build` 会被拒收）"))
    answer_recorded: bool = Field(
        default=False, description="用户的答复有没有落盘（`views/build_target_v1.json`）")
    record_path: str = Field(default="", description="答复台账的落盘位置")
    warnings: list[str] = Field(default_factory=list, description="要提醒用户的事")
    question: str = Field(description="要问用户的话")
    options: list[str] = Field(default_factory=list, description="给用户选的选项")
    next_step: str = Field(description="拿到用户答复后下一步做什么")


# --- 阶段三 · 步骤 2：搭建指令表 / 批量落关卡（2026-09-26）----------------------


class BuildOrderRow(BaseModel):
    """**搭建指令表里的一行** = 一个要落进关卡的东西（阶段三第 2 步）。

    ⚠ 这是"翻译件"不是"重新规划"：`loc_cm` 由 plan 的 `pos`（米）×100 得来，
      **一个字都不许在这里改**。plan 里没有的只有两样，都在这里补上：
      ① **Z**（竖直标高，规则见 `WHITEBOX_VERTICAL` / `ASSET_PIVOT_LIFT_CM`）；
      ② 白膜的**图元**（`primitive`）与**尺寸**（`size_cm`）—— 官方 PrimitiveTools
         没有 `add_plane`，所以 `plane` 一律压成极薄的 cube（口径见 docs/阶段三 §5）。
    """

    index: int = Field(description="序号（1 起；资产行在前、白膜行在后，与 plan 同序）")
    label: str = Field(description="plan 里的 label（原样带出，便于追溯）")
    uid: str = Field(
        default="",
        description=("**稳定身份**（`element_key`|`label`）—— 增量搭建靠它把这一行与台账那一行对齐。"
                     "⚠ 不要用 `index` 对账：中间插一行会让后面的行号全部平移。"))
    name: str = Field(description="真正给 UE 的 Actor 名（由 label 洗成可当对象名的字符串）")
    kind: str = Field(description="`asset`（用资产摆）/ `whitebox`（用图元搭）")
    element_key: str = Field(default="", description="元素关键词（与阶段一/二一致）")
    asset_path: str = Field(default="", description="资产包路径；**白膜行为空**")
    primitive: str = Field(default="", description="白膜用哪个图元：`cube`（plane 也压成 cube）")
    loc_cm: list[float] = Field(default_factory=list, description="UE 世界坐标 [X, Y, Z]（厘米）")
    rot: dict = Field(default_factory=dict, description="UE 旋转 {pitch, yaw, roll}（度）")
    scale: list[float] = Field(default_factory=list, description="UE 缩放（资产行取 plan.scale；白膜恒 [1,1,1]）")
    size_cm: list[float] | None = Field(
        default=None, description="白膜图元尺寸 [X, Y, Z]（厘米）；资产行为 null"
    )
    folder: str = Field(description=f"outliner 分组（幂等对账与一键清理的判据），如 {OUR_FOLDER_ROOT}/trees")
    surface_material_hint: str = Field(
        default="", description="阶段六贴表面要用的材质实例（**阶段三不贴**，且未验证存在性）"
    )
    note: str = Field(default="", description="plan 里那行的 note（原样带出）+ 本工具补的 Z 依据")


class BuildOrdersResult(BaseModel):
    """搭建指令表（`views/build_orders_v1.json`）—— **离线算的**，一个 Actor 都没落。"""

    stage: str = Field(description="阶段名")
    data_path: str = Field(description="指令表落盘位置（阶段六换执行器时读它，不用重做）")
    plan_hash: str = Field(description="算这张表时 plan_v1.json 的几何指纹（变了这张表就作废）")
    world: dict = Field(default_factory=dict, description="世界中心 / 大小 / 包围盒（都是米）")
    counts: dict = Field(default_factory=dict, description="行数对账：资产行 / 白膜行 / 合计 / 各元素各几行")
    z_rules: list[str] = Field(
        default_factory=list, description="Z 是怎么推出来的（逐条列给人看，方便他一句『这个不对』就能改）"
    )
    rows: list[BuildOrderRow] = Field(default_factory=list, description="指令表全文（一物一行）")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")
    next_step: str = Field(description="下一步做什么")


class BuildRowResult(BaseModel):
    """一行**执行结果**（落没落成、落在哪、读回来对不对）。"""

    index: int = Field(description="与指令表的 `index` 对应")
    label: str = Field(default="", description="指令表里的 label")
    kind: str = Field(default="", description="`asset` / `whitebox`")
    actor: str = Field(default="", description="落成后官方返回的 Actor 引用（失败为空）")
    loc_cm: list[float] = Field(default_factory=list, description="**读回来**的坐标（厘米；没读为空）")
    yaw: float | None = Field(default=None, description="**读回来**的 yaw（度）")
    scale: list[float] = Field(default_factory=list, description="**读回来**的缩放")
    ok: bool = Field(default=True, description="这一行落成了吗")
    error: str = Field(default="", description="没落成 / 读回对不上的原文说明")


class BuildReport(BaseModel):
    """阶段三第 2 步的执行报告 —— 落完（或拒收 / 演练）之后的**如实交代**。"""

    stage: str = Field(description="阶段名")
    level: str = Field(description="落在哪张图（当前关卡）")
    dry_run: bool = Field(description="true = 只校验对账，**一个 Actor 都没落**")
    refused: bool = Field(default=False, description="被拒收了吗（拒收 = 一个 Actor 都没落）")
    reason: str = Field(default="", description="拒收原因（原文）")
    plan_hash: str = Field(default="", description="执行的是哪一版几何指纹")
    mode: str = Field(default="full",
                      description="这次是 `full`（全量重摆）还是 `incremental`（只动与台账比变了的行）")
    ledger_path: str = Field(default="", description="搭建台账（我们自己的文件，记上次搭了什么）")
    ledger_written: bool = Field(default=False, description="这次有没有更新台账")
    diff: dict = Field(
        default_factory=dict,
        description="增量差异：要删 / 要摆 / 没动 / 认领回来的 / 台账说在关卡里却没了 的行")
    planned: int = Field(default=0, description="指令表一共几行")
    removed: int = Field(default=0, description=f"开摆前从 {OUR_FOLDER_ROOT}/ 清掉几个旧 Actor（幂等）")
    placed: int = Field(default=0, description="成功落了几个")
    verified: int = Field(default=0, description="读回对账通过几个")
    mismatches: list[str] = Field(default_factory=list, description="读回来对不上的行（对不上就是没摆对）")
    groups: dict = Field(default_factory=dict, description="各 outliner 分组各落了几个")
    rows: list[BuildRowResult] = Field(default_factory=list, description="逐行结果（含官方返回的 Actor 引用）")
    official_calls: int = Field(default=0, description="这次一共调了官方几次（留痕，方便复核）")
    next_step: str = Field(description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class ElementItem(BaseModel):
    """参考图里需要的一个元素。"""

    element: str = Field(description="元素名，如 house / road / tree / sidewalk")
    category: str = Field(
        default="",
        description=(
            "**大类 key**（照 `config/asset_categories.json` 那张表填，如 building / nature / "
            "environment / furniture / props）。这是 2026-09-24 用户要求的：先有大类表，"
            "再按参考图把表填好，然后才去找资产。"
            "⚠ 填表里没有的 key 会被**拒收**（表就是词表）；实在没把握就填 uncategorized，"
            "并在 note 里写明为什么"
        ),
    )
    subcategory: str = Field(
        default="",
        description="更细的一层（自由文本，可留空；如 building 下的 house / garage）。**不参与判定**，只给人看",
    )
    count: int | None = Field(
        default=None,
        description=(
            "**预估数量**（画面里能看到几个）。2026-09-24 用户要求：**有数量的就要填**。"
            "⚠ 材质 / 面这种没有『个数』概念的行可以留空，但要在 note 里写明为什么没有数量。"
            "⚠ 场景项（地图大小 / 地图对应时间）不用填。"
        ),
    )
    count_source: str = Field(
        default="",
        description=(
            "数量是怎么来的：`预估（参考图目测）` / `实测（图上数出来的）` 等 —— "
            "**是估的就必须写明是估的**，不许让预估值看起来像实测值"
        ),
    )
    size_m: list[float] | None = Field(
        default=None,
        description=(
            "**只给『地图大小』那一行填**：`[X, Y]`（米，预估）—— 从上传图估的场景范围。"
            "其余行留空；是预估就在 note 里写明依据"
        ),
    )
    time_of_day: str = Field(
        default="",
        description=(
            "**只给『地图对应时间』那一行填**：从图里光线判断的时段，如 sunset（黄昏）/ "
            "blue_hour（蓝调）/ noon（正午）/ night（夜）/ overcast（阴天）。其余行留空"
        ),
    )
    note: str = Field(default="", description="备注：在画面里的位置、为什么没有数量、估的依据等")


class ElementList(BaseModel):
    """**用户确认过**的元素清单（= 按大类填好的那张表）。"""

    confirmed_at: str = Field(description="确认时间")
    source_image: str = Field(description="参考图路径（留档）")
    total: int = Field(description="几个元素")
    elements: list[ElementItem] = Field(description="元素清单")
    groups: dict[str, list[str]] = Field(
        default_factory=dict,
        description=(
            "**按大类分组**：`{中文大类名: [元素名, ...]}`，顺序照大类表，未分类排最后 —— "
            "这就是「根据参考图填好的那张表」，拿它逐类跟用户确认"
        ),
    )
    categories_defined: int = Field(
        default=0, description="大类表里一共定义了几项（读不到表时会是 0 —— 那就该去查表在不在）"
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（表里 `kind=scene` 那两行，**不是资产**）：`{中文名: 人话值}`，"
            "如 `{\"地图大小\": \"80×80 m（预估）\", \"地图对应时间\": \"sunset（黄昏）\"}`"
        ),
    )
    scene_map_size_m: list[float] | None = Field(
        default=None,
        description="场景项『地图大小』的结构化值 `[X, Y]`（米，预估）；没填就是 null",
    )
    scene_time_of_day: str = Field(
        default="", description="场景项『地图对应时间』的值（如 sunset / blue_hour）；没填就是空"
    )
    no_count: list[str] = Field(
        default_factory=list,
        description=(
            "**没填预估数量的元素**。材质 / 面这种没有『个数』概念的可以没有数量 —— "
            "但要在该行 note 里写明；其余的行请补上 count"
        ),
    )
    next_step: str = Field(description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class FoundAsset(BaseModel):
    """按某个元素找到的一个候选资产。"""

    name: str = Field(description="资产名（可能没有语义，如 MI_sjfnch0a）")
    path: str = Field(description="包路径")
    asset_type: str = Field(description="类别：mesh / material / material_instance")
    size_cm: list[float] | None = Field(
        default=None, description="实测尺寸 [X,Y,Z]（厘米）。只有网格有，材质是 null"
    )
    matched_by: str = Field(description="怎么命中的：资产名 / 文件夹名")
    matched_segment: str = Field(
        default="", description="按文件夹命中时，命中的那一段（这就是它的语义来源）"
    )


class ElementPlan(BaseModel):
    """一个元素的查找结果。"""

    element: str = Field(description="元素名")
    status: str = Field(description="found = 名字对得上；missing = 没找到")
    assets: list[FoundAsset] = Field(description="找到的候选（缺失时为空）")
    placeholder_hint: str = Field(
        default="",
        description=(
            "**白膜提示**（2026-09-24 用户要求）：这个元素**没有可用资产**，"
            "必须在 confirm_assets 里登记成**白膜占位**（`is_placeholder=true` + "
            "`placeholder_shape` + **预估** `size_cm`），再让用户确认清单。"
            "空串 = 有可用的网格资产，按普通行登记。"
            "⚠ 有值时**不许**把它当普通资产行交出去（那样清单会带一条不存在的路径）。"
        ),
    )
    question: str = Field(description="**要原样问用户的话**")


class PlanReport(BaseModel):
    """阶段一的查找报告。"""

    stage: str = Field(description="当前阶段")
    needs_user_confirmation: bool = Field(description="恒为 true —— 用户确认前不许往下走")
    source: str = Field(description="元素清单从哪来的：用户确认过的清单 / 本次传入的关键词")
    total_elements: int = Field(description="一共查了几个元素")
    found: int = Field(description="找到了几个")
    missing: int = Field(description="缺了几个")
    elements: list[ElementPlan] = Field(description="逐元素结果")
    by_category: dict[str, dict[str, list[str]]] = Field(
        default_factory=dict,
        description=(
            '**按大类分组的结果**：`{中文大类名: {"found": [...], "missing": [...]}}`（顺序照大类表）'
            " —— 拿它**逐类核对有没有漏**。"
            "⚠ 大类**不是搜索过滤参数**：官方 find_assets 只能按资产名/文件夹名/类路径找，"
            "这里只是把结果归到类里，不许说成『按类搜索』"
        ),
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（表里 `kind=scene` 的那两行，**不是资产**、本次没去搜）："
            "`{中文名: 人话值}`，如 `{'地图大小': '80×80 m（预估）', '地图对应时间': 'sunset'}`"
        ),
    )
    official_calls: int = Field(description="调了几次官方工具")
    next_step: str = Field(description="下一步做什么")
    warnings: list[str] = Field(description="要提醒的坑（不藏着）")


class RenameItem(BaseModel):
    """要改名的一个资产（路径和名字由**用户**提供）。"""

    path: str = Field(description="现在的完整包路径")
    new_name: str = Field(description="新的资产名（**只给名字**，不要带路径和斜杠）")


class RenameResult(BaseModel):
    """一个资产的改名结果。"""

    old_path: str = Field(description="改名前路径")
    new_path: str = Field(description="改名后路径")
    referencers: list[str] = Field(description="谁引用了它（改名前查的，看影响面）")
    ok: bool = Field(description="成功没有")
    error: str = Field(default="", description="失败原因（官方原文）")


class RenameReport(BaseModel):
    """一批改名的结果。"""

    dry_run: bool = Field(description="true = 只预览，**没有真改**")
    requested: int = Field(description="要求改几个")
    renamed: int = Field(description="真改成功几个（dry_run 时恒为 0）")
    failed: int = Field(description="几个不合法或失败")
    items: list[RenameResult] = Field(description="逐个结果")
    note: str = Field(description="说明与风险提示")


class AssetListItem(BaseModel):
    """交付清单里的一行：一个元素用哪个资产。"""

    element: str = Field(description="画面元素名（给人看的标签，可带说明，如 'house 主屋'）")
    element_key: str = Field(
        default="",
        description=(
            "**元素关键词**（如 house / sidewalk），必须和 elements.json 里的元素名一致 —— "
            "get_asset_list 靠它判断哪些元素已经落位；"
            "留空会退回『标签首词推断』（不可靠，会明说是推断）"
        ),
    )
    asset_path: str = Field(
        default="",
        description=(
            "确认使用的资产包路径。⚠ **白膜占位行留空**（见 is_placeholder）—— "
            "那种元素没有可用资产，没有路径可验证"
        ),
    )
    category: str = Field(
        default="",
        description=(
            "**大类 key**（照 `config/asset_categories.json` 那张表，与该元素在 elements.json 里"
            "记的一致）。**不填也行**：本工具会去 elements.json 那张表里按关键词取；"
            "两边都没有才记成 uncategorized。中文名由本工具查表回填，调用方**不用填中文名**"
        ),
    )
    category_cn: str = Field(
        default="",
        description="大类中文名（**本工具查表回填**，调用方不用填）",
    )
    asset_type: str = Field(default="", description="类别：mesh / material_instance / material / whitebox")
    is_placeholder: bool = Field(
        default=False,
        description=(
            "**白膜占位**（whitebox）：这个元素**没有可用资产** —— 找不到、用户确认没有，"
            "或者现在只有**材质实例顶着**（材质没有包围盒、摆不出实体）。"
            "这类行：不做 exists() 验证、尺寸用调用方给的**预估值**（不被实测覆盖）、"
            "asset_type 记 whitebox。⚠ **只是清单登记** —— 阶段一不许往关卡里摆任何东西。"
        ),
    )
    placeholder_shape: str = Field(
        default="",
        description=(
            "白膜形状：`cube`（体，如窗户/车道这种有体积的）/ `plane`（面，如马路/草坪这种覆盖面）。"
            "非白膜行留空。阶段六按这个形状用官方 PrimitiveTools 加图元实例化。"
        ),
    )
    exists: bool = Field(
        # ⚠ `default` 不能删：本字段由工具自己回填（见函数体里的 model_copy），调用方不填。
        #   2026-09-23 曾因缺 default 被 pydantic 判成 required，与下面那句描述自相矛盾 ——
        #   照描述办事的调用方一律被参数校验拒收，工具连函数体都进不去（check_tools 实测复现）。
        default=False,
        description=(
            "官方 exists() 验证结果 —— **必须为 true**（白膜占位行为 false：没有路径可验）。"
            "⚠ 调用方**不用填**：本工具会逐个调官方 exists() 把它覆盖掉"
        ),
    )
    size_cm: list[float] | None = Field(
        default=None,
        description=(
            "**实测**包围盒尺寸 [X, Y, Z]（厘米）—— 由 confirm_assets 调官方 get_bounds 回填，"
            "调用方填什么都会被覆盖；非网格（材质等）为 null。"
            "⚠ **白膜占位行例外**：那种行没有东西可测，必须由调用方给**预估尺寸**（至少 X、Y），"
            "预估值**不会被覆盖** —— 但必须在 size_source 里写明是预估"
        ),
    )
    bbox_volume_cm3: float | None = Field(
        default=None,
        description="**包围盒体积**（厘米³）= X×Y×Z；⚠ 是包围盒，不是网格实际体积",
    )
    size_source: str = Field(
        default="",
        description=(
            "尺寸是怎么来的 / 为什么没有：`官方 get_bounds 实测（包围盒）` / "
            "`<类别> 没有包围盒` / `预估（参考图目测，待核实）` / 量取失败原因"
        ),
    )
    note: str = Field(default="", description="备注（谁改的名、为什么选它、白膜为什么用这个尺寸等）")


class UnresolvedElement(BaseModel):
    """**元素清单里有、交付表里没有**对应资产的元素 —— 免得它静默消失。

    为什么要有这个结构（2026-09-23 实测暴露）：
      `elements.json` 确认了 14 条 / 9 个关键词，交付表只有 6 行 ——
      `window` / `sidewalk` / `driveway` 三个关键词**在交付表里没有任何交代**。
      信息其实没丢（`get_asset_list` 每次都会报 `missing_elements`），
      但**单看交付物本身看不出清单不完整** —— 读表的人会以为一共就 6 个元素。
    """

    element_key: str = Field(description="元素关键词（与 elements.json 里的元素名一致）")
    occurrences: int = Field(default=0, description="该关键词在元素清单里出现几处")
    note: str = Field(
        default="",
        description="元素清单里对它的说明 —— **原样带出，不改写**",
    )


class AssetListDelivery(BaseModel):
    """**最终交付物**：给用户的资产清单。"""

    delivered_at: str = Field(description="交付时间")
    source_image: str = Field(description="参考图路径")
    total: int = Field(description="一共几个元素")
    verified: int = Field(description="路径验证通过几个")
    placeholders: int = Field(
        default=0,
        description=(
            "**白膜占位**几行（没有可用资产的元素 / 只有材质实例顶着的元素）—— "
            "这些行的尺寸是**预估**，请用户重点确认"
        ),
    )
    invalid_paths: list[str] = Field(
        default_factory=list,
        description=(
            "**验证不存在的路径**。⚠ 2026-09-24 整改后**恒为空**："
            "路径验不过的行会被 confirm_assets **当场拒收**（要求改成白膜占位或给对路径），"
            "根本走不到交付这一步。字段保留是为了不破坏交付物结构"
        ),
    )
    items: list[AssetListItem] = Field(description="资产清单")
    unresolved_elements: list[UnresolvedElement] = Field(
        default_factory=list,
        description=(
            "**元素清单里有、本表里没有对应资产**的元素 —— 不许静默消失。"
            "note 是元素清单原话（可能已写明归属，如『按光照环境处理』）。"
            "⚠ 本工具**不推断**没落位的原因：只说事实，要原因得问用户。"
            "⚠ 已经用**白膜占位**登记过的元素**不算未落位**（它已经有交代了）。"
        ),
    )
    deliverable: str = Field(description="给人看的清单正文（直接贴给用户）")
    note: str = Field(description="说明与下一步")


class AssetListRow(BaseModel):
    """交付表里的**一行**（get_asset_list 用）—— 原样带出表里记的尺寸信息。"""

    element: str = Field(default="", description="画面元素标签")
    element_key: str = Field(default="", description="元素关键词（表里显式记的那个）")
    category: str = Field(default="", description="大类 key")
    category_cn: str = Field(default="", description="大类中文名（交付时查表回填的）")
    asset_path: str = Field(default="", description="资产包路径")
    asset_type: str = Field(
        default="", description="类别：mesh / material_instance / material / whitebox"
    )
    is_placeholder: bool = Field(
        default=False, description="**白膜占位**行（没有可用资产；尺寸是**预估**、不是实测）"
    )
    placeholder_shape: str = Field(
        default="", description="白膜形状：cube（体）/ plane（面）；非白膜行留空"
    )
    size_cm: list[float] | None = Field(
        default=None,
        description=(
            "交付时记录的包围盒尺寸 [X, Y, Z]（厘米）。"
            "⚠ 白膜占位行这里是**预估尺寸**（见 size_source），不是实测"
        ),
    )
    bbox_volume_cm3: float | None = Field(
        default=None, description="包围盒体积（厘米³）；⚠ 是包围盒，不是网格实际体积"
    )
    size_source: str = Field(default="", description="尺寸来源 / 为什么没有尺寸")
    note: str = Field(default="", description="交付时的备注")


class PathCheck(BaseModel):
    """清单里**一条路径**的验活结果（get_asset_list 用）。"""

    element: str = Field(default="", description="这一行对应的元素标签")
    asset_path: str = Field(description="清单里记的资产路径")
    ok: bool = Field(description="官方 exists() 是否通过")
    error: str = Field(default="", description="验证失败时的官方原文")


class AssetListStatus(BaseModel):
    """**「当前这张资产清单还作不作数」**的判定结果（get_asset_list 用）。

    字段分成四组，对应它回答的四个问题：
      有没有表   → has_list / delivered_at / source_image / total
      表变没变   → stale / signed_* / live_* / changed_types
      路径还活吗 → path_check / dead_paths
      缺的有着落吗 → missing_elements / new_candidates / coverage_mode
    """

    has_list: bool = Field(description="有没有交付过清单（false 时其余字段无意义）")
    delivered_at: str = Field(default="", description="清单是什么时候交付的")
    source_image: str = Field(default="", description="当初那张参考图")
    total: int = Field(default=0, description="清单里共几条")
    placeholders: int = Field(
        default=0,
        description="其中**白膜占位**几条（这些行的尺寸是**预估**，不是实测 —— 别当实测值用）",
    )
    items: list[AssetListRow] = Field(
        default_factory=list,
        description="表里的**每一行**（含实测尺寸/包围盒体积），原样带出，不做二次加工",
    )
    stale: bool | None = Field(
        default=None,
        description="指纹对不上 = true（表已过期）；没有指纹可比 = null（旧版本落的表）",
    )
    signed_at: str = Field(default="", description="指纹是什么时候记的")
    signed_hash: str = Field(default="", description="签字时的资产库指纹")
    signed_counts: dict[str, int] = Field(
        default_factory=dict, description="签字时每类资产各多少个"
    )
    live_hash: str = Field(default="", description="刚测出来的资产库指纹")
    live_counts: dict[str, int] = Field(
        default_factory=dict, description="刚测出来每类资产各多少个"
    )
    changed_types: list[str] = Field(
        default_factory=list, description="变了的那几类，人话写法，如 'material_instance: 58 → 56'"
    )
    path_check: list[PathCheck] = Field(
        default_factory=list, description="逐条验活结果（verify_paths=false 时为空）"
    )
    dead_paths: list[str] = Field(
        default_factory=list, description="**已经验不存在的路径**（必须处理掉才能往下走）"
    )
    missing_elements: list[str] = Field(
        default_factory=list, description="还没有资产落位的元素关键词"
    )
    missing_by_category: dict[str, list[str]] = Field(
        default_factory=dict,
        description=(
            "**上面那些缺失元素按大类分组**：`{中文大类名: [元素关键词...]}`（顺序照大类表）—— "
            "一眼看出哪一类还缺东西"
        ),
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（从 `catalog/elements.json` 原样带出，**不是资产**）："
            "`{中文名: 人话值}`，如 `{'地图大小': '80×80 m（预估）', '地图对应时间': 'sunset'}`；"
            "没填过就是空"
        ),
    )
    new_candidates: dict[str, list[str]] = Field(
        default_factory=dict, description="缺的元素在实况库存里**名字对得上**的新候选（元素 → 路径）"
    )
    coverage_mode: str = Field(
        default="", description="『元素已落位』是怎么判的：element_key 显式标注 / 标签首词推断"
    )
    official_calls: int = Field(default=0, description="本次调了几次官方工具")
    needs_user_confirmation: bool = Field(
        default=True, description="恒为 true —— 用户确认前不许往下走"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class PlanGate(BaseModel):
    """规划图的**闸门状态**：这张图还作不作数。"""

    confirmed: bool = Field(description="用户/客户是否已确认这张图")
    params_hash_ok: bool = Field(
        default=True,
        description=(
            "⚠ 2026-09-24 起**恒为 true**：参数文件已删（参数由调用方给），没有"
            "『哪份参数』可比。字段保留只为兼容旧 plan_v1.json（老文件里存过 params_hash）。"
            "闸门现在只有 `plan_hash_ok` 一道。"
        ),
    )
    plan_hash_ok: bool = Field(
        description="几何指纹是否仍与算出来时一致（false = 文件被手改过 → 这张图作废）"
    )
    confirmed_by: str = Field(default="", description="谁确认的")
    confirmed_at: str = Field(default="", description="什么时候确认的（UTC）")
    params_hash: str = Field(default="", description="（已废弃，恒空）")
    plan_hash: str = Field(default="", description="当前几何指纹")


class PlanSummary(BaseModel):
    """放置规模摘要（给人看的几个数）。"""

    world_center: list[float] = Field(default_factory=list, description="平面世界中心 [X, Y]（米）")
    world_size: list[float] = Field(default_factory=list, description="平面世界大小 [X, Y]（米）")
    assets: int = Field(default=0, description="已有资产的放置条数（一物一行）")
    whiteboxes: int = Field(default=0, description="白膜占位的条数（一物一行）")
    # ⚠ 2026-09-25：原来这里有 checks_total / checks_failed / failed_names —— 阶段二自检整段删除
    #   （用户指令），字段一并去掉。碰撞检测与布局修正归**第四阶段**。


class PlanAcceptance(BaseModel):
    """**阶段二验收**的状态（2026-09-25 用户要求新增）。

    位置：**阶段二（规划 + 生图）之后、第三阶段之前**。生图 = 阶段二结束，进这一段；
    用户在图上看过说"行"才放行进第三阶段，说"要改"就回到「改参数 → 重落盘 → 重画图」。

    ⚠ `state` 是**现算**的（`planning.acceptance_state()`），不是台账里那个旧快照 ——
      因为图常常是"落盘之后"才画好的，读快照会拿着"等出图"的旧字样回答"走到哪了"。
    """

    stage: str = Field(default="阶段二验收", description="阶段名")
    round: int = Field(default=0, description="第几轮（**几何指纹变一次 = 新的一轮**，同一版重复落盘不算）")
    state: str = Field(
        default="",
        description=(
            "`not_started` 空表 / `awaiting_figure` 等出图 / `awaiting_user` 等用户看图确认 / "
            "`changes_requested` 用户提了要改 / `accepted` 验收通过"
        ),
    )
    state_cn: str = Field(default="", description="上面那个状态的中文说明（给人看）")
    plan_hash: str = Field(default="", description="这一轮验的是**哪个几何指纹**")
    figures: list[str] = Field(
        default_factory=list,
        description="**认这份数据**的图（图名）—— 就是该**交付成卡片给用户看**的那几张；空 = 还没画或图与数据不一致",
    )
    pending_changes: list[str] = Field(
        default_factory=list,
        description="用户在验收时提出、**还没落到数据里**的改动点（用户原话）",
    )
    change_window_open: bool = Field(
        default=False,
        description=(
            "**「改动窗口」开着没有**（2026-09-26 加）：开 = 台账里已经有「要改什么 / 谁要的」的记录，"
            "`generate_plan` 才准改几何。`request_plan_change()` 打开它（对象是用户原话或 `agent 自查`），"
            "`confirm_plan()` 关上它。关着的时候直接改几何 → `generate_plan` **拒收**"
            "（客户 agent 自评：他一次都没调过 `request_plan_change`，直接 patch）"
        ),
    )
    change_set: dict = Field(
        default_factory=dict,
        description=(
            "**这一版相对『上一次用户确认过的那一版』改了什么**（2026-09-26 起）："
            "`{local, baseline, added, changed, removed, same, required_labels, note}`。"
            "`local=true` = 局部一轮：**图里只要出现 `required_labels` 那几行**，"
            "没动的行不必重画（用户要求：局部改就全局部，不要全部重做）；"
            "`local=false` = 还没有基线（第一次搭）→ 图里要出现**每一行**。"
        ),
    )
    awaiting_readback: dict = Field(
        default_factory=dict,
        description=(
            "**「这一版还没回读」的登记**（2026-09-26 把软约束变硬）：非空 = 在你调 `get_plan()` "
            "之前，`generate_plan` 与 `execute_build` 都会被**拒收**。里面带 "
            "`plan_hash` / `at` / `change_set`（改了什么，逐行）。调一次 `get_plan()` 即清掉。"
        ),
    )
    updated_at: str = Field(default="", description="台账最后更新时间（UTC）")
    ledger_path: str = Field(default="", description="验收台账文件：views/acceptance.json")
    history: list[dict] = Field(
        default_factory=list, description="台账最近几条事件（谁 / 何时 / 第几轮 / 哪个指纹 / 干了什么）"
    )


class PlanResult(BaseModel):
    """算几何 / 确认的结果。"""

    stage: str = Field(description="阶段二 · 平面放置规划")
    unit: str = Field(default="m", description="单位（米制）")
    data_path: str = Field(description="几何数据文件 —— **后续计算只读它**")
    image_path: str = Field(
        default="",
        description=(
            "⚠ 2026-09-24 起**恒为空**：不再由代码按固定模板画图（用户拍板）。"
            "要图就自己拿 `data_path` 的几何数据去画 —— 画法不写死在代码里。"
        ),
    )
    summary: PlanSummary = Field(description="规模摘要")
    gate: PlanGate = Field(description="闸门状态")
    acceptance: PlanAcceptance | None = Field(
        default=None,
        description=(
            "**阶段二验收**状态（生图后进这一段）：第几轮、等谁、要交付哪几张图、"
            "用户提了哪些要改的地方。`figures` 就是**要交付给用户打开的图**。"
        ),
    )
    changed_params: list[str] = Field(
        default_factory=list, description="本次覆盖了哪些参数（点号路径；空 = 没改）"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class PlanStatus(BaseModel):
    """『当前规划图还作不作数』+ 计划本体（get_plan 用）。"""

    has_plan: bool = Field(description="有没有算过规划")
    status: str = Field(
        default="",
        description=(
            "`initialized` = **两张表都空**（结构立好了，但还没有任何坐标 —— 图的依据没来）；"
            "`draft` = 有内容、等着用户确认；`confirmed` = 已确认"
        ),
    )
    data_path: str = Field(default="", description="几何数据文件")
    image_path: str = Field(
        default="", description="（恒空 —— 图由 AI 拿 data_path 自己画，代码不出图）"
    )
    summary: PlanSummary = Field(default_factory=PlanSummary, description="规模摘要")
    gate: PlanGate | None = Field(
        default=None, description="闸门状态；**confirmed=false 时不许进第三阶段**"
    )
    acceptance: PlanAcceptance | None = Field(
        default=None,
        description=(
            "**阶段二验收**状态（现算）：`awaiting_user` = 图与数据一致、该交付给用户了；"
            "`changes_requested` = 用户提了改动、还没落到数据里；`accepted` = 验收通过、闸门开。"
        ),
    )
    plan: dict | None = Field(
        default=None, description="完整计划数据（include_plan=true 时带出）"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑")


def candidates_for(
    keyword: str, inventory: dict[str, list[str]], limit: int = 5
) -> list[FoundAsset]:
    """在实况库存里按【资产名】+【文件夹名】两条路找候选（与 plan_assets 同一套判据）。

    ⚠ 只返回**名字对得上**的；名字对不上就是空列表 —— **禁止猜"疑似是它"**。
      这是本项目两次实测误报之后定下的硬规则，这里照旧执行。

    ⚠ **为什么这个函数待在「模型」区后面**（2026-09-23 血账，别搬回去）：
      签名里写了 `-> list[FoundAsset]`，而**函数签名上的注解是在 `def` 被执行的那一刻
      求值的**（不是等到调用时）。只要 FoundAsset 还没定义，模块 import 就抛
      `NameError: name 'FoundAsset' is not defined` —— server 直接起不来。
      第一版我把它放在"厚函数"区（模型区之前），实测正是这个报错，
      宿主侧表现为 mcp-client(mine) 重连 10 次全败。
      结论：**返回值里带模型的函数，必须放在模型定义之后。**
    """
    kw = keyword.lower().strip()
    out: list[FoundAsset] = []
    if not kw:
        return out
    for type_name, paths in inventory.items():
        for p in paths:
            name = p.rsplit("/", 1)[-1]          # rsplit(...,1)[-1] = 取最后一段 = 资产名
            matched_by, seg = "", ""
            if token_match(kw, name):
                matched_by = "资产名"
            else:
                for part in p.split("/"):        # 逐段试文件夹名
                    if part and token_match(kw, part):
                        matched_by, seg = "文件夹名", part
                        break
            if matched_by:
                out.append(
                    FoundAsset(name=name, path=p, asset_type=type_name,
                               matched_by=matched_by, matched_segment=seg)
                )
    out.sort(key=lambda a: (a.matched_by != "资产名", len(a.path)))
    return out[:limit]


# --- [完工-05] 工具 1：链路自检 ---
# 实测 2026-09-23 12:07：返回 reachable=true / protocol 2025-11-25 / 52 个工具集。

@mcp.tool()
async def official_status(ctx: Context[AppContext]) -> OfficialStatus:
    """自检：能不能连上官方 Unreal MCP，并报告协议版本和工具集数量。

    任何依赖官方的操作之前，先用它确认链路。连不上时返回**错误原文**，不猜原因。

    ⚠ 本 server 是**编排层**：自己完全不碰 UE —— 改关卡 / 摆 Actor / 改材质都要经官方
      `unreal` 那侧的工具做。
    ⚠ **没有对应工具的能力 = 还没实现** —— 如实说「还没做」，不许硬凑、不许假装能做。
    ⚠ 讲流程时**以 `docs/` 下的规划文档为准，不许凭印象**。
    ⚠ 硬性禁止：不许寻找/猜测「疑似资产」；不许删资产；**不许存盘**（保存 UE 关卡 / 资产）。
    """
    # ⚠ 这次调用本身要留痕（2026-09-26 加）：`execute_build` 落关卡前会核对"开场动作做过没有"，
    #   见 `_session_prereq_guard()`。**在入口就记**（不看返回值）—— 连不上也算"调过"，
    #   否则链路一断就变成死锁：越连不上越被拦，越被拦越没法往下走。
    _mark_session_prereq("official_status")
    try:
        catalog = await call_official(ctx, "list_toolsets", {})
        text = catalog if isinstance(catalog, str) else json.dumps(catalog, ensure_ascii=False)
        # 官方把工具集列成 "- 工具集名: 说明"。只数形如 "- xxx.yyy:" 的行，
        # 别把说明里的项目符号也算进去（实测：那样会数出 67，真实值是 52）。
        count = len(re.findall(r"^-\s+\S*\.\S*:", text, flags=re.MULTILINE))
    except ToolError as exc:
        return OfficialStatus(reachable=False, error=str(exc))

    # 协商出的协议版本：上面那次 list_toolsets 调用已经把连接建起来了，
    # 所以此刻读 client.protocol_version 是安全的（未连接时抛 RuntimeError）。
    # 读不到不算自检失败：版本只是报告项，不该把整条结果判死。
    version: str | None = None
    try:
        app = ctx.request_context.lifespan_context
        version = app.ue.protocol_version if app.ue is not None else None
    except (RuntimeError, AttributeError) as exc:
        logging.getLogger(__name__).warning("读协议版本失败（已忽略）：%r", exc)

    return OfficialStatus(reachable=True, protocol_version=version, toolset_count=count)


# --- 阶段三 · 步骤 1：搭建目标检查（2026-09-26 用户要求）--------------------------
# 用户原话：「第三阶段第一步应该是检查，别动用户的 UE，先问用户在哪开始搭建，
#   是开新图还是用户指定地图或区域，确认开新图就新建关卡开始搭建，
#   用户有指定就去指定地方搭建」。
# 所以这一步**只读**：只问、只看、只报告 —— 一个 Actor 都不放、一张图都不切。

@mcp.tool()
async def check_build_target(
    ctx: Context[AppContext],
    decision: Annotated[str, Field(
        description=(
            "**用户的答复**（拿到答复后**再调一次本工具**把它记下来）："
            "`current` = 就用当前这张图 / `existing` = 用他指定的既有图（同时给 `target_level`）/ "
            "`new` = 开新图（**他自己**在 UE 里建好并打开）。"
            "⚠ 留空 = 还没问过用户 —— 那就只是问一遍（只记下「问的是哪张图」，不记答复），"
            "`execute_build` 也不会放行"))] = "",
    target_level: Annotated[str, Field(
        description="`decision=\"existing\"` 时，用户指定的关卡路径（如 `/Game/Maps/Street`）")] = "",
    user_quote: Annotated[str, Field(
        description=(
            "**用户答复的原话（给了 `decision` 就必填）** —— 与 `confirm_plan` 同一条纪律："
            "拿不出原话，就说明你还没问过他。**不许自己编**"))] = "",
) -> BuildTargetCheck:
    """阶段三第 1 步：问清楚「搭在哪张图」—— **不碰关卡**，只写我们自己的答复台账。

    为什么第一步是它（用户 2026-09-26 明确要求）：**别动用户的 UE**。开搭之前必须先问清楚
    目标是**新图**、**指定的既有图**、还是**当前这张图**；确认开新图才新建关卡，有指定就去
    指定地方搭。

    ⚠ **本工具不碰关卡**：不新建关卡、不切换关卡、不摆也不删任何 Actor，**不存 UE**。
      唯一写的是我们自己的 `views/build_target_v1.json`（谁问的、用户怎么答的）。
    ⚠ **官方没有「新建关卡」的工具**（实测：`SceneTools` 只有 `load_level`，没有 new level）——
      所以「开新图」这一步得**用户自己**在 UE 里建好并打开，我们只在他建好的图上搭。
      这条如实报出来，不假装能建。
    ⚠ **流程（两步，别合成一步）**：
      ① **先问**（`decision` 留空）→ 把 `question` / `options` 交给用户 → **停下等他打字**；
      ② 拿到他的话之后**再调一次**，带 `decision`（+ `existing` 还要 `target_level`）+ `user_quote`
         —— 这一步只是把答复记下来。
      ③ 之后 `execute_build()` 会拿这份答复**核对当前关卡**：对不上就拒收（一个 Actor 都不动）。
         "拿到用户答复前一个 Actor 都不许放" 现在是**代码闸**，不再是文档里的软约束。
    """
    calls: list[str] = []
    warnings: list[str] = []

    # ① 当前关卡（读不到就是链路/编辑器的问题，直接如实返回）
    current = ""
    try:
        current = str(await call_official(ctx, "get_current_level", {}, toolset=TS_SCENE) or "")
        calls.append("SceneTools.get_current_level")
    except ToolError as exc:
        return BuildTargetCheck(
            stage="阶段三 · 资产布局生成（步骤 1/检查）",
            readonly=True, official_calls=calls, current_level="",
            question=f"读不到当前关卡：{exc}",
            next_step="先确认 UE 编辑器开着、ModelContextProtocol 插件启用、端口 8000 在监听，再调一次。",
        )

    # ② 项目里有哪些关卡资产（供用户「指定地图」用）
    candidates: list[str] = []
    try:
        found = await call_official(
            ctx, "find_assets",
            {"folder_path": "/Game", "name": "",
             "asset_type": {"refPath": LEVEL_CLASS_PATH}, "recursive": True},
            toolset=TS_ASSET,
        )
        candidates = sorted(p for p in (found or []) if isinstance(p, str))
        calls.append("AssetTools.find_assets(/Script/Engine.World)")
    except ToolError as exc:
        warnings.append(f"列关卡资产失败（{exc}）—— 候选列表不完整，不影响你直接指定路径。")

    # ③ 当前关卡里有没有「我们上次摆过的东西」（靠 outliner 的 UEMCP/ 文件夹认）
    total = 0
    try:
        actors = await call_official(
            ctx, "find_actors", {"name": "", "tag": "", "collision_channels": []},
            toolset=TS_SCENE)
        total = len(actors or [])
        calls.append("SceneTools.find_actors")
    except ToolError as exc:
        warnings.append(f"数关卡 Actor 失败（{exc}）。")

    our_folders: list[str] = []
    try:
        folders = await call_official(ctx, "get_folders", {}, toolset=TS_SCENE)
        our_folders = sorted(
            f for f in (folders or [])
            if isinstance(f, str)
            and (f == OUR_FOLDER_ROOT or f.startswith(OUR_FOLDER_ROOT + "/"))
        )
        calls.append("SceneTools.get_folders")
    except ToolError as exc:
        warnings.append(f"读 outliner 文件夹失败（{exc}）。")

    # ⚠ **只数根文件夹一次**（`recursive=True` 已经把子文件夹里的都算进来了）。
    # 2026-09-26 实测踩到：根 + 7 个子文件夹各数一遍 = **2 倍**（根里真 89 个，报成了 178）。
    # 顺带比一下"指令表几行"—— 数量一致就说明关卡与这一版表对得上，局部改可以直接走增量。
    our_refs: set[str] = set()
    for folder in ([OUR_FOLDER_ROOT] if OUR_FOLDER_ROOT in our_folders else our_folders):
        try:
            members = await call_official(
                ctx, "get_actors_in_folder",
                {"folder_path": folder, "recursive": True}, toolset=TS_SCENE)
            calls.append(f"SceneTools.get_actors_in_folder({folder})")
            for item in (members or []):
                ref = _ref_path(item)
                if ref:
                    our_refs.add(ref)
        except ToolError:
            continue
    our_count = len(our_refs)

    orders_doc = load_json(BUILD_ORDERS_PATH) or {}
    want = len(orders_doc.get("rows") or []) if isinstance(orders_doc, dict) else 0

    if our_count:
        if not want:
            hint = " 还没有指令表可比 —— 先用 `generate_build_orders()` 生成。"
        elif want == our_count:
            hint = (f" 与 `views/build_orders_v1.json` 的 {want} 行**数量一致**，看起来就是这一版"
                    "搭出来的 → 局部改动走**增量**：`execute_build(mode=\"incremental\")`"
                    "（还没台账就先 `adopt=true` 认领现状）。")
        else:
            hint = (f" 但指令表是 {want} 行 —— **数量对不上**，先查差额（多半是上一版的残留）："
                    "要么 `mode=\"full\"` 重摆，要么先 `adopt=true` 看清现状。")
        warnings.append(
            f"⚠ 当前关卡里已经躺着**我们摆过的 {our_count} 个 Actor**"
            f"（outliner 文件夹：{'、'.join(our_folders)}）——" + hint + " 两条路都要用户拍板。")
    if not current:
        warnings.append("当前关卡路径读不到（返回空字符串）。")

    question = (
        f"搭在哪里？（当前关卡：{current or '读不到'}）"
        "① 开新图　② 用项目里已有的某张图（你把路径给我）　③ 就用当前这张图 —— 你定。"
        "⚠ 官方工具里**没有「新建关卡」**，所以选 ① 的话要**你在 UE 里新建并打开**，我再去那张图上搭。"
    )
    options = [
        "① 开新图 —— 你在 UE 里新建并打开（官方没有 new level 工具，我只能在你建好的图上搭）",
        f"② 用指定的既有图 —— 项目里能列到 {len(candidates)} 张（见 candidate_levels）；"
        "你给路径，我用 SceneTools.load_level 切过去",
        f"③ 就用当前这张：{current or '（读不到）'}",
    ]

    # ---------- 用户的答复：记下来（**阶段三第 1 步的终点，也是 execute_build 的闸**）----------
    # 2026-09-26 加：这一步以前只是"把问题返回给宿主"，**答复没有任何地方留痕** ——
    #   于是 execute_build 根本无从核对"到底问没问、问的是哪张图"（客户反馈：agent 会跳过它直接搭）。
    decision_key = ""
    answer: dict | None = None
    kept_answer = False          # 这一版没带答复、但台账里**已有**一份（要如实报，别报成"没答复"）
    record_path = ""
    if str(decision or "").strip():
        decision_key = _norm_decision(decision)
        quote = str(user_quote or "").strip()
        if not quote:
            raise ToolError(
                "拒收：给了 `decision` 但**没给 `user_quote`（用户答复的原话）**。\n"
                "· 目标图是**用户**定的，不是我们挑的 —— 拿不出他的原话，就说明还没问过他。\n"
                "· 正确顺序：先不带 `decision` 调一次（只读地问）→ 把问题交给用户、**停下等他打字**\n"
                "  → 再带 `decision` + 他的原话调一次（把答复记下来）。"
            )
        if decision_key == "existing" and not str(target_level or "").strip():
            raise ToolError(
                "拒收：`decision=\"existing\"`（用指定的既有图）必须同时给 `target_level` —— "
                "**路径要用户给**，我不猜他用哪张图（项目里可能有好几张）。"
            )
        answer_level = (str(target_level or "").strip() if decision_key == "existing" else current)
        answer = {
            "decision": decision_key,
            "level": answer_level,
            "user_quote": quote,
            "at": datetime.now(timezone.utc).isoformat(),
        }
        record_path = _save_build_target(current, answer)
        warnings.append(
            f"答复已记进 `{record_path}`：**{decision_key}** → `{answer_level or '（关卡读不到）'}`"
            f"（用户原话「{quote}」）。`execute_build()` 会拿它与当前关卡核对，对不上就拒收。")
        if decision_key == "existing" and answer_level and candidates and answer_level not in candidates:
            warnings.append(
                f"⚠ 你指定的 `{answer_level}` **不在我列到的 {len(candidates)} 张关卡里** —— "
                "可能它在别的目录、或路径写法不同（我不猜）。本工具**不切图**：请确认这张图存在，"
                "并在 UE 里切过去；切过去之后 `execute_build` 才认。")
        if decision_key == "new":
            warnings.append(
                f"⚠ 用户选的是**开新图** —— 官方没有「新建关卡」的工具（实测只有 `load_level`），"
                "**要他自己在 UE 里新建并打开**。在他打开新图之前调 `execute_build` 会被拒收"
                f"（现在开着的还是 `{current or '（读不到）'}`）。")
    else:
        record_path = _save_build_target(current, None)
        _prev = _load_build_target().get("answer")
        if isinstance(_prev, dict) and _prev:
            kept_answer = True
            warnings.append(
                f"这次只**问**、没带答复 —— 已经留痕的那份答复"
                f"（`{_prev.get('decision')}` → `{_prev.get('level')}`）**原样保留**"
                f"（`{record_path}`）。要**改**答复就带 `decision`（`existing` 还要 "
                "`target_level`）+ 用户原话再调一次；否则 `execute_build` 认的还是原来那份。")
        else:
            warnings.append(
                f"这次只**问**、还没有答复（已把『问的时候 UE 开着哪张图』记进 `{record_path}`）。"
                "把上面那句 `question` 交给用户、**停下等他打字**，再带他的原话调一次本工具。"
                "⚠ **在他答复之前，`execute_build` 会被代码拒收**（一个 Actor 都不会落）。")

    if answer:
        next_step = (
            f"答复已留痕（`{decision_key}`）。**下一步**："
            "⓪ 开场动作（`official_status()` + `get_asset_list()`，各一次；没做过 `execute_build` 会拒收）→ "
            "① `generate_build_orders()` 生成搭建指令表 → "
            "② `execute_build()` 落关卡 —— 它会**先核对『这份答复 vs 当前关卡』**，不一致就拒收列出来；"
            "③ 想先看不动手就传 `dry_run=true`。⚠ `execute_build` 还会过**回读闸**"
            "（这一版没 `get_plan()` 过就拒收）。⚠ 全程**不存盘**。"
        )
    else:
        next_step = (
            ("（⚠ 台账里**原来那份答复还在** —— `execute_build` 认的还是它；要改就带 "
             "`decision` + 用户原话重调一次。）" if kept_answer else "")
            + "把用户的选择回给我。**在他答复之前，我不会往关卡里放任何东西**"
              "（现在这条是**代码闸**：没答复就调 `execute_build`，会被拒收）。"
              "他答复之后：带 `decision`（`existing` 还要 `target_level`）+ 他的原话**再调一次本工具**，"
              "才轮到「生成搭建指令表 → 落关卡」。"
        )

    return BuildTargetCheck(
        stage="阶段三 · 资产布局生成（步骤 1/检查）",
        readonly=True,
        official_calls=calls,
        current_level=current,
        candidate_levels=candidates,
        our_folders=our_folders,
        our_actor_count=our_count,
        total_actors=total,
        can_create_level=False,     # 实测：官方没有 new level 工具
        decision=decision_key,
        answer_recorded=bool(answer) or kept_answer,
        record_path=record_path,
        warnings=warnings,
        question=question,
        options=options,
        next_step=next_step,
    )


# --- 阶段三 · 步骤 2：搭建指令表 + 批量落关卡（2026-09-26）-----------------------
# 用户原话（2026-09-26）：「继续完善第三阶段，第二步代码，按照位置坐标表开始一次性全部批量搭建」。
# 分工照 docs/阶段三-资产布局生成.md §2：
#   ① `generate_build_orders()` —— **纯计算**，把 plan（米）翻成 UE 能照做的指令表（厘米）；
#   ② `execute_build()` —— **先整批校验**（不过就一个 Actor 都不落）→ 清旧的 → 按表落 → 读回对账。
# ⚠ 两个工具**都不存盘**（不调任何 save 类工具）—— 这是硬规矩。
#
# ✅ [完工-14] 实测 2026-09-26（经 MCP 真跑，非演练）：plan 指纹 a01717bd14…（已确认+验收通过）
#   · `generate_build_orders()` → 落盘 views/build_orders_v1.json，**60 行**（资产 39 + 白膜 21），
#     分元素 house5/tree34/road1/sidewalk2/grass9/path6/shrub3，warnings 为空；
#   · `execute_build()` → **placed 60 / 60**、`removed 0`（首跑，图上本来没有 UEMCP/ 的东西）、
#     `official_calls 206`、7 个分组各就各位、落完后 UEMCP/ 计数 60（= 指令表行数，没报警）；
#   · 读回对账报 2 条 "yaw -90 != 270"（house2 ×2）—— **是同一角度**，UE 把 yaw 折进 ±180 存；
#     → 对账已改成按角度差比（`_angle_close`）。
#   · 全程未调任何 save。
# ✅ [完工-14] 追加实测 2026-09-26（同一批工具，第二次真跑 —— 把上面那条修正验掉了）：
#   plan 指纹 36d3697d37…（第 22 轮，用户看图后确认）· **89 行**（资产 39 + 白膜 50）：
#   · `generate_build_orders()` → 89 行，分元素 house5/tree34/road1/sidewalk2/grass5/path25/shrub17；
#     报出**越界警告**（#60/#68 屋后走道中心已出界）—— 如实报、不拦（越界处置留给阶段四）。
#   · `execute_build()` → **placed 89 / 89**、`removed 60`（清掉上一版全部旧 Actor）、
#     `verified 89 / 89`、**`mismatches` 空**、`official_calls 383`、7 个分组计数与指令表逐项相等。
#     ⚠ 上一版同一组 house2 行（yaw 指令 270 / 读回 -90）在这里报过 2 条假警报，
#       本次判据换成 `_angle_close` 后**为 0 条** —— 这一处修正**已实测**。
#   · **仍未实测**的一处：`get_actors_in_folder` 抛 "Folder does not exist" 时**不再刷警告**
#     那段分支（本次开局 `UEMCP/` 里有 60 个旧 Actor，走的不是那条路）。
# ⚠ 2026-09-26 增量改造（**尚未实测** —— 等用户跑 `tests/preflight.py` / MCP 真跑补证据）：
#   · 每行新增稳定身份 `uid`（`element_key`|`label`）、新增台账 `views/build_state_v1.json`；
#   · `execute_build` 新增 `mode`（full / incremental）与 `adopt`；
#   · `check_build_target` 的 `our_actor_count` 由"根 + 各子文件夹递归相加"（实测正好 2 倍：
#     根里 89 个报成 178）改成**只数根一次**；
#   · 上面两条 [完工-14] 的实测记录针对的是**全量**路径 —— 全量逻辑本身没改
#     （只是落完之后多写一次台账、并且现在按标签认领而不是靠行号）。


# --- 阶段三 · 增量搭建的对账件（2026-09-26；用户要求：局部改动只重建改动处）-------
# 用户原话：「关于已经大搭建好的，如果用户需要局部更改就继续回去改图，然后再让用户确认，
#   再生成需要改的地方而不是全部重新搭建」。
# 两个前提事实（2026-09-26 实测，不是推断）：
#   ① `add_to_scene_from_asset(name=...)` 传的名字落在 **Actor 的 label（显示名）** 上，
#      对象名是 UE 自动编号（`StaticMeshActor_48` / `Actor_25`）——
#      所以"认领"要靠 `get_label`，不是靠 refPath 猜；
#   ② 曾经把"根文件夹递归"与"每个子文件夹递归"相加当总数 → **2 倍**（根 89 报成 178）。
# 增量靠 `uid`（= `element_key`|`label`）把"指令表一行"与"台账一行"对齐；台账里存 Actor 引用。


def _row_uid(element_key: str, label: str) -> str:
    """一行指令的**稳定身份**（`element_key` + `label`）—— 增量对账全靠它。

    为什么不用 `index`：`index` 是行号，**中间插一行会让后面所有行的号码平移**，
    按号码对账会把"新加了一行"错认成"后面每一行都变了"。
    label 是阶段二要求"同类多个要能区分"的，天然唯一；element_key 再兜一层。
    ⚠ label 是用户可见、可改的：他要是把某行改名，这一版就会被当成"删一行 + 加一行" ——
      这是**如实行为**（不猜），报告里会点名。
    """
    return f"{element_key or '-'}|{label or '-'}"


def _load_build_state() -> dict:
    """读搭建台账；没有 / 格式不对都返回 `{}`（当"没有基线"处理，拒不拒收由调用方定）。"""
    doc = load_json(BUILD_STATE_PATH)
    return doc if isinstance(doc, dict) else {}


def _save_build_state(level: str, plan_hash: str, how: str, ledger_rows: list[dict]) -> str:
    """写搭建台账（**我们自己的文件，不碰 UE**）。`how` = full / incremental / adopt。"""
    save_json(BUILD_STATE_PATH, {
        "stage": "阶段三 · 搭建台账（我们自己的文件，不是 UE 资产；里面没有任何关卡存盘）",
        "level": level,
        "plan_hash": plan_hash,
        "how": how,
        "at": datetime.now(timezone.utc).isoformat(),
        "unit": "cm",
        "rows": ledger_rows,
        "note": ("每一行 = 指令表的一行，靠 `uid`（element_key|label）对齐。"
                 "`readback=true` 表示 loc/yaw/scale 是**从关卡读回来的**；"
                 "`false` 表示记的是**指令值**、没核实过。"),
    })
    return str(BUILD_STATE_PATH)


# --- 阶段三 · 「搭哪张图」的答复台账与闸（2026-09-26 加；**尚未实测** —— 等 preflight / 真跑补证据）--
# 客户的 agent 交付后自评里点名的软约束之一：「连上 MCP 应该先看完所有工具参数 —— 我走一步查一步」，
# 以及更贵的那条：「用户手动改的东西不该删 —— 我 full 重摆给删了」。
# 前者在代码里的具体表现就是：`check_build_target` 是第 1 步，但**没有任何代码核对它跑没跑**；
# 后者是：落关卡前**从没读过关卡现状**，于是"手改过的东西"既没人保护、也没人报。
# 下面这几个函数就是把这两条从文档搬进代码。


def _load_build_target() -> dict:
    """读「搭哪张图」的答复台账；没有 / 格式不对都返回 `{}`（当"还没问过"处理）。"""
    doc = load_json(BUILD_TARGET_PATH)
    return doc if isinstance(doc, dict) else {}


def _save_build_target(asked_level: str, answer: dict | None = None) -> str:
    """写「搭哪张图」的答复台账（**我们自己的 JSON，不是 UE 存盘、不碰关卡**）。

    ⚠ 只记「问的时候 UE 开着哪张图 / 用户怎么答的」—— 不改关卡、不摆 Actor。
    ⚠ **"已经答复过"的答复不许被下一次"只问一句"擦掉**（这次 `answer=None`）：
      否则 agent 顺手再问一遍现场情况（`our_actor_count` 之类），
      刚留痕的答复就没了、`execute_build` 会莫名被拒 —— 这就是"记的东西被自己抹掉"。
      「问题问的是哪张图」（`asked_at` / `asked_level`）同样只在**还没有答复**时才重记：
      它是"用户选的是开新图，而他到底换图没有"的凭据，换掉了就判断不出来。
    """
    old = _load_build_target()
    old_answer = old.get("answer") if isinstance(old.get("answer"), dict) else None
    keep_ask = bool(old.get("asked_at")) and (answer is not None or old_answer is not None)
    doc = {
        "stage": "阶段三 · 「搭哪张图」的答复台账（我们自己的文件，非 UE 存盘）",
        "asked_at": (str(old.get("asked_at") or "") if keep_ask
                     else datetime.now(timezone.utc).isoformat()),
        "asked_level": (str(old.get("asked_level") or "") if keep_ask else str(asked_level or "")),
        "answer": answer if answer is not None else old_answer,
        "at": datetime.now(timezone.utc).isoformat(),
        "note": ("`asked_*` = 问的时候 UE 开着哪张图；`answer.decision` 三个取值："
                 "current（就用当前这张）/ existing（用户指定的既有图，路径在 answer.level）/ "
                 "new（开新图，用户自己建）。`execute_build` 拿它与当前关卡核对 —— 对不上不搭。"),
    }
    save_json(BUILD_TARGET_PATH, doc)
    return str(BUILD_TARGET_PATH)


_DECISION_ALIASES = {
    "current": "current", "当前": "current", "当前图": "current",
    "就用当前这张": "current", "就用当前这张图": "current",
    "existing": "existing", "既有": "existing", "既有图": "existing", "指定": "existing",
    "new": "new", "新图": "new", "开新图": "new", "新建": "new",
}


def _norm_decision(raw: str) -> str:
    """把用户的答复（中英文都接）归一成 `current` / `existing` / `new`；认不出就抛。

    ⚠ 只认这三个词，**不猜** —— 「随便」「你看着办」换不出目标图，那种答复要回去问清楚：
      挑哪张图是**用户的决定**（AGENTS：不许替用户做决定）。
    """
    key = str(raw or "").strip().lower()
    if key in _DECISION_ALIASES:
        return _DECISION_ALIASES[key]
    for alias, val in _DECISION_ALIASES.items():        # 容 "① 开新图" / "③ 就用当前这张" 这种写法
        if alias and key.endswith(alias):
            return val
    raise ToolError(
        f"`decision` 认不出：`{raw}` —— 只认三样：`current`（就用当前这张）/ "
        "`existing`（用他指定的既有图，同时给 `target_level`）/ `new`（开新图，他自己建）。"
        "用户要是没说清搭哪张图，就再问他一次；**不许替他挑**。")


def _same_level(a: str, b: str) -> bool:
    """两个关卡路径算不算**同一张图**。

    为什么要它：`get_current_level` 返回的是包路径（实测 `/Game/demo/Landscape/MCP`），
    而用户/文档里常常写成 UE 的"包.对象"写法（`/Game/demo/Landscape/MCP.MCP`）——
    只做**这一种**写法归一（不做大小写/前缀乱配），免得把"写法不同"误判成"搭错图"。
    """
    a, b = str(a or "").strip(), str(b or "").strip()
    if not a or not b:
        return False
    if a == b:
        return True
    try:
        return a == b.split(".", 1)[0] or b == a.split(".", 1)[0]
    except (AttributeError, IndexError):
        return False


def _build_target_guard(level: str) -> None:
    """**「先问清搭哪张图」这道闸**（2026-09-26 加，把软约束变硬）。

    谁调它：`execute_build()` —— 拿到当前关卡之后、**动任何 Actor 之前**。
    判据：`views/build_target_v1.json` 里要有一份**用户答复过的**目标，且与当前这张图对得上：
      · `current`  —— 答复时那张图必须就是现在这张（用户中途换了图 = 那次答复不再指这张）；
      · `existing` —— 用户指定的路径必须就是现在这张（还没切过去 → 不许搭）；
      · `new`      —— 现在这张**不能**还是答复当时那张（说明他还没把新图建好/打开）。
    为什么要有它：`check_build_target` 是阶段三第 1 步，可代码里从来没核对过它跑没跑 ——
      「拿到用户答复前一个 Actor 都不许放」原先只写在工具描述与 docs 里（软约束）。
    ⚠ 台账没答复 / 内容不认 → **照拦**（与 `_readback_guard` 的"基础设施故障就放行"相反）：
      这道闸挡的是"往用户的图里放东西"，拿不准就该停下问人 —— **放行才是会造成损失的那一边**。
    """
    doc = _load_build_target()
    ans = doc.get("answer") if isinstance(doc.get("answer"), dict) else {}
    if not ans:
        raise ToolError(
            "拒收：**还没拿到用户对『搭哪张图』的答复** —— 一个 Actor 都没动。\n"
            "正确顺序：① `check_build_target()`（先只读地问一遍：当前关卡 / 可选的图 / "
            f"`{OUR_FOLDER_ROOT}/` 下有没有旧东西）→ ② **把问题交给用户、停下等他打字** → "
            "③ 带他的原话再调一次 `check_build_target(decision=…, user_quote=…)`（只记答复，仍不碰关卡）"
            "→ ④ 才轮到 `execute_build()`。\n"
            "（为什么拦：官方**没有「新建关卡」的工具**，选「开新图」得用户自己在 UE 里建 —— "
            "不问就搭，十有八九搭在他不想要的那张图上。这条以前只是文档里的软约束。）"
        )
    dec = str(ans.get("decision") or "")
    if dec not in ("current", "existing", "new"):
        raise ToolError(
            f"拒收：答复台账里的 `answer.decision` 不认：`{dec}`（`{BUILD_TARGET_PATH}`）—— "
            "一个 Actor 都没动。请重新走一遍 `check_build_target(decision=…, user_quote=…)`。"
        )
    asked = str(doc.get("asked_level") or "")
    answered = str(ans.get("level") or "")
    if dec == "new" and asked and _same_level(level, asked):
        raise ToolError(
            f"拒收：用户选的是**开新图**，但当前关卡还是当初问他的那张 `{asked}` —— "
            "他还没把新图建好/打开（官方没有新建关卡的工具，这一步只能他做）—— **一个 Actor 都没动**。\n"
            "请他新建并打开目标图，再调 `execute_build()`。"
        )
    if dec == "existing" and answered and not _same_level(level, answered):
        raise ToolError(
            f"拒收：用户指定的是 `{answered}`，当前关卡却是 `{level}` —— **还没切过去**，"
            "**一个 Actor 都没动**。请先在 UE 里切到那张图（或明确让我用官方 `load_level` 切），再搭。"
        )
    if dec == "current" and answered and not _same_level(level, answered):
        raise ToolError(
            f"拒收：用户当时选的是『就用当前这张』= `{answered}`，现在开着的是 `{level}` —— "
            "**对不上了**（有人换过图），那次答复不再指这张图 —— **一个 Actor 都没动**。\n"
            "请重新问一次：`check_build_target()` → 用户答复 → `check_build_target(decision=…)`。"
        )


def _xform_of(got: Any) -> tuple[list[float] | None, float | None, list[float] | None]:
    """官方 `get_actor_transform` 的返回 → `(loc_cm, yaw, scale)`；解析不了给 `(None, None, None)`。"""
    doc = got if isinstance(got, dict) else {}
    loc = doc.get("location") or {}
    rot = doc.get("rotation") or {}
    scl = doc.get("scale") or {}
    try:
        return (
            [num(float(loc.get("x", 0.0))), num(float(loc.get("y", 0.0))),
             num(float(loc.get("z", 0.0)))],
            num(float(rot.get("yaw", 0.0))),
            [num(float(scl.get("x", 0.0))), num(float(scl.get("y", 0.0))),
             num(float(scl.get("z", 0.0)))],
        )
    except (TypeError, ValueError):
        return (None, None, None)


def _loc_close(a: Any, b: Any, tol: float = 0.05) -> bool:
    """两个坐标是不是同一个（厘米，容差 0.05 = 与读回对账同一把尺子）。"""
    if not (isinstance(a, (list, tuple)) and isinstance(b, (list, tuple))
            and len(a) == 3 and len(b) == 3):
        return False
    try:
        return all(abs(float(x) - float(y)) <= tol for x, y in zip(a, b))
    except (TypeError, ValueError):
        return False


def _scale_close(a: Any, b: Any, tol: float = 1e-4) -> bool:
    """两个缩放是不是同一个（与读回对账同一把尺子）。"""
    if not (isinstance(a, (list, tuple)) and isinstance(b, (list, tuple))
            and len(a) == 3 and len(b) == 3):
        return False
    try:
        return all(abs(float(x) - float(y)) <= tol for x, y in zip(a, b))
    except (TypeError, ValueError):
        return False


async def _read_cube_size_cm(
    ctx: Context[AppContext], actor_ref: str
) -> tuple[list[float] | None, int]:
    """读白膜 Actor 上那个 cube 组件的**实际尺寸**（厘米）→ `(尺寸 或 None, 调了几次官方)`。

    ⚠ **为什么非要读它（2026-09-26 动手前实测出来的一个漏洞，别删这段）**：
      白膜的尺寸**不在 Actor 变换里** —— `add_cube` 把它写在组件的 `RelativeScale3D` 上
      （基础方块 100 cm；实测 `Actor_25.cube` = {x:120, y:8, z:0.15} → 12000×800×15 cm，
      正好是「沥青车行道 120×8 m」那条），而官方 `get_actor_bounds` 对这类 Actor
      恒返回 ±128 的**假包围盒**（实测，见 docs/阶段三 §11.1）。
      于是「认领现状」（adopt）若拿**当前指令表**里的尺寸当基线，就会把「我以为它多大」
      当成「它真的多大」：用户刚把五条连接路加宽到 4 m，adopt 却记成"已经是 4 m"，
      增量比对判它**没变** → **那五条路永远摆不下去**（静默失效，比报错坏得多）。
      实测佐证：`Actor_33.cube`（连接路 #1）= {x:2, y:36} —— 关卡里**确实还是 2 m**。

    读不到就给 `None`：调用方据此记 `null`，让下一次比对**必判"尺寸变了"→ 重摆**
    （安全侧：宁可多重摆一行，也不许把用户刚改的东西静默跳过）。
    """
    used = 0
    try:
        comps = await call_official(
            ctx, "get_components", {"actor": {"refPath": actor_ref}}, toolset=TS_ACTOR)
        used += 1
    except ToolError:
        return (None, used)
    target = ""
    for c in (comps or []):
        ref = _ref_path(c)
        if ref and ref.rsplit(".", 1)[-1] == "cube":     # add_cube 时给组件起的名字
            target = ref
            break
    if not target:                                        # 名字对不上就退一步：挑一个非默认组件
        for c in (comps or []):
            ref = _ref_path(c)
            if ref and "DefaultSceneRoot" not in ref and "Billboard" not in ref:
                target = ref
                break
    if not target:
        return (None, used)
    try:
        props = await call_official(
            ctx, "get_properties",
            {"instance": {"refPath": target}, "properties": ["RelativeScale3D"]},
            toolset=TS_OBJECT)
        used += 1
    except ToolError:
        return (None, used)
    doc = props
    if isinstance(doc, str):                              # 官方把属性包成 JSON 字符串（实测）
        try:
            doc = json.loads(doc)
        except (ValueError, TypeError):
            return (None, used)
    scl = doc.get("RelativeScale3D") if isinstance(doc, dict) else None
    if not isinstance(scl, dict):
        return (None, used)
    try:
        # 基础方块 100 cm：官方 add_cube 传 [100,200,50] 得到 RelativeScale3D=(1,2,0.5)（实测）
        base_cm = 100.0
        return ([num(float(scl.get("x", 0.0)) * base_cm),
                 num(float(scl.get("y", 0.0)) * base_cm),
                 num(float(scl.get("z", 0.0)) * base_cm)], used)
    except (TypeError, ValueError):
        return (None, used)


async def _live_vs_ledger(
    ctx: Context[AppContext],
    ledger_rows: list[dict],
    live_set: set[str],
    loc_tol: float = 0.5,
) -> tuple[list[dict], int]:
    """把**关卡现状**与台账逐行比一遍 → `([{uid,label,actor,kind,why,ledger}, …], 官方调用次数)`。

    为什么要有它（2026-09-26 加，客户 agent 自评里点名的那条「没帮到我」）：
      · `full` 会把 `UEMCP/` 下的 Actor **全部清掉** —— 用户手工挪过的那几个也在里面；
      · 增量虽然不碰"没变的行"，但它**压根没读过关卡现状** —— 于是"地皮厚度被人改过"这种事
        既没人发现、也没人报（原话：「它不会告诉我『用户手动改了地皮你别删』」、
        「incremental 对比不够智能，识别不出『地皮高度变了需要重贴』」）。
    判据：台账那一行的 `loc_cm / yaw / scale` vs 关卡**现在**的样子。
      `readback=false` 的行台账记的是**指令值** —— 拿它比仍然成立：它代表"我们上次让它变成的样子"。
      ⚠ **白膜行还要另外读组件尺寸**（`_read_cube_size_cm`）：厚薄 / 高度**不在 Actor 变换里**，
        这正是"地皮高度变了却没人知道"的根因。
      ⚠ 位置容差给 **0.5 cm**（不是读回对账那 0.05）：这里判的是"人手动挪过没有" ——
        人挪一下至少几厘米，而浮点回写的零头不该刷出假警报。
    只比"台账里有 Actor 引用、且那个 Actor 现在还在关卡里"的行；**读不回来就不判"改过"**（不猜）。
    """
    used = 0
    out: list[dict] = []
    for old in ledger_rows:
        actor = str(old.get("actor") or "")
        if not actor or actor not in live_set:
            continue
        used += 1
        try:
            got = await call_official(
                ctx, "get_actor_transform", {"actor": {"refPath": actor}}, toolset=TS_ACTOR)
        except ToolError:
            continue                       # 读不到就不判"改过"（宁可漏报，不编）
        loc, yaw, scale = _xform_of(got)
        why: list[str] = []
        if loc is not None and not _loc_close(loc, old.get("loc_cm"), tol=loc_tol):
            why.append(f"位置 {old.get('loc_cm')} → 现在 {loc}")
        if yaw is not None:
            try:
                if not _angle_close(yaw, float(old.get("yaw") or 0.0)):
                    why.append(f"yaw {old.get('yaw')} → 现在 {yaw}")
            except (TypeError, ValueError):
                pass
        if scale is not None and not _scale_close(scale, old.get("scale")):
            why.append(f"缩放 {old.get('scale')} → 现在 {scale}")
        if str(old.get("kind") or "") == "whitebox":
            dim, cost = await _read_cube_size_cm(ctx, actor)
            used += cost
            want = old.get("size_cm")
            if (isinstance(dim, list) and len(dim) == 3
                    and isinstance(want, (list, tuple)) and len(want) == 3):
                if [round(float(x), 2) for x in dim] != [round(float(x), 2) for x in want]:
                    why.append(f"白膜尺寸（厚薄 / 高宽）{list(want)} → 现在 {dim}")
        if why:
            out.append({
                "uid": str(old.get("uid") or ""),
                "label": str(old.get("label") or ""),
                "actor": actor,
                "kind": str(old.get("kind") or ""),
                "why": why,
                "ledger": old,
            })
    return out, used


def _row_changes(order: dict, old: dict) -> list[str]:
    """指令表的这一行 vs 台账里的那一行 —— 变了没有？变了就**逐条说清变在哪**。"""
    why: list[str] = []
    if str(order.get("asset_path") or "") != str(old.get("asset_path") or ""):
        why.append(f"资产路径 {old.get('asset_path') or '（空）'} → {order.get('asset_path') or '（空）'}")
    if (order.get("size_cm") or None) != (old.get("size_cm") or None):
        # ⚠ 第 3 维就是**厚薄 / 高度**（plan 的 `height_m` → 白膜 cube 的 Z）。
        #   客户 agent 自评里点名「incremental 对比不够智能，识别不出『地皮高度变了需要重贴』」——
        #   尺寸变了本来就判得出；这里额外**把话说清楚**，免得差异明细里一行数字看不出是高度。
        note = ""
        try:
            oz = float((old.get("size_cm") or [None, None, None])[2])
            nz = float((order.get("size_cm") or [None, None, None])[2])
            if abs(oz - nz) > 1e-6:
                note = f"（第 3 维 = 厚薄 / 高度变了：{oz:g} → {nz:g} cm —— 这一行必须重贴）"
        except (TypeError, ValueError, IndexError):
            note = "（尺寸变了 —— 这一行必须重贴）"
        why.append(f"白膜尺寸 {old.get('size_cm')} → {order.get('size_cm')}{note}")
    if str(order.get("folder") or "") != str(old.get("folder") or ""):
        why.append(f"分组 {old.get('folder')} → {order.get('folder')}")
    if not _loc_close(order.get("loc_cm"), old.get("loc_cm")):
        why.append(f"位置 {old.get('loc_cm')} → {order.get('loc_cm')}")
    try:
        if not _angle_close(float((order.get("rot") or {}).get("yaw") or 0.0),
                            float(old.get("yaw") or 0.0)):
            why.append(f"yaw {old.get('yaw')} → {(order.get('rot') or {}).get('yaw')}")
    except (TypeError, ValueError):
        why.append("yaw 读不出来")
    if not _scale_close(order.get("scale"), old.get("scale")):
        why.append(f"缩放 {old.get('scale')} → {order.get('scale')}")
    return why


def _ledger_row(order: dict, actor: str, loc: Any = None, yaw: Any = None,
                scale: Any = None, readback: bool = False) -> dict:
    """指令表一行 → 台账一行。

    `readback=False` 时 loc/yaw/scale 记的是**指令值**（没读回来核实过）—— 台账里带这个标记，
    免得以后把"我以为它在那儿"当成"它真在那儿"（硬规则 6 的同一条纪律）。
    """
    return {
        "uid": order["uid"], "index": order["index"], "label": order["label"],
        "name": order["name"], "kind": order["kind"], "element_key": order["element_key"],
        "asset_path": order["asset_path"], "size_cm": order.get("size_cm"),
        "folder": order["folder"], "actor": actor,
        "loc_cm": (list(loc) if (isinstance(loc, (list, tuple)) and len(loc) == 3)
                   else list(order["loc_cm"])),
        "yaw": (float(yaw) if isinstance(yaw, (int, float))
                else float((order.get("rot") or {}).get("yaw") or 0.0)),
        "scale": (list(scale) if (isinstance(scale, (list, tuple)) and len(scale) == 3)
                  else list(order["scale"])),
        "readback": bool(readback),
    }


def _compose_build_rows(plan: dict, asset_list: dict) -> tuple[list[dict], list[str], list[str]]:
    """把 `plan_v1.json` 翻成**搭建指令表**（纯计算，不碰 UE）。返回 `(rows, z_rules, warnings)`。

    翻译只做三件事，其余一律照抄 —— **坐标本身一个字都不许在这里改**：
      ① **米 → 厘米**：`cm = m × 100`，**只缩放不翻轴**（plan 写明与 UE 同为左手系 Z-up，
         X 前进 / Y 右 / Z 上 —— `world.coordinate_system`）；
      ② `rot_deg` → UE `yaw`：**不反号**（2026-09-26 实测两者同向，docs/阶段三 §3 的表）；
      ③ **补 Z**：plan 只有平面坐标 `pos: [X, Y]`，竖直方向的两条依据写在本文件顶部的
         `WHITEBOX_VERTICAL`（白膜）与 `ASSET_PIVOT_LIFT_CM`（原点不在底面的资产）里。

    顺序也是照抄 plan 的：**已有资产在前、白膜在后**（阶段二定的顺序不能反 ——
    白膜的占地是在资产占完位之后才估出来的）。
    """
    warnings: list[str] = []

    # 白膜厚度兜底：阶段一清单里每个元素都登记过一个 `size_cm[2]`（车行道 15 cm、草坪 5 cm…）。
    # 为什么从清单取而不是在代码里写死：那是**登记过的**尺寸，代码写死就成了"我替用户估"。
    thickness_cm: dict[str, float] = {}
    for it in (asset_list.get("items") or []):
        if not isinstance(it, dict):
            continue
        key = str(it.get("element_key") or "").strip()
        size = it.get("size_cm")
        if key and key not in thickness_cm and isinstance(size, (list, tuple)) and len(size) >= 3:
            try:
                thickness_cm[key] = float(size[2])
            except (TypeError, ValueError):
                pass

    rows: list[dict] = []
    index = 0

    # ---------- ① 已有资产：占地与坐标都是阶段二确认过的 ----------
    for a in (plan.get("assets") or []):
        index += 1
        key = str(a.get("element_key") or "")
        label = str(a.get("label") or key)
        path = str(a.get("asset_path") or "")
        pos = list(a.get("pos") or [0.0, 0.0])
        scale = float(a.get("scale") or 1.0)
        yaw = float(a.get("rot_deg") or 0.0)
        note = str(a.get("note") or "")

        # Z：地面标高 + 「原点比底面高」的那一段（乘上这个资产的缩放）—— 见 ASSET_PIVOT_LIFT_CM
        lift_cm = ASSET_PIVOT_LIFT_CM.get(path, 0.0) * scale
        z_cm = GROUND_Z_M * 100.0 + lift_cm
        if lift_cm:
            note += (f" ｜ 阶段三补 Z：该资产原点比底面高 {ASSET_PIVOT_LIFT_CM[path]:g} cm"
                     f"（scale 1 实测）×{scale:g} = {lift_cm:.2f} cm，"
                     f"挪到地面 {GROUND_Z_M * 100:g} cm 之上 → z = {z_cm:.2f} cm")

        rows.append({
            "index": index, "label": label,
            "uid": _row_uid(key, label),
            "name": _safe_actor_name(label, index, key),
            "kind": "asset", "element_key": key, "asset_path": path, "primitive": "",
            "loc_cm": [num(pos[0] * 100.0), num(pos[1] * 100.0), num(z_cm)],
            "rot": {"pitch": 0.0, "yaw": num(yaw), "roll": 0.0},
            "scale": [num(scale), num(scale), num(scale)],
            "size_cm": None,
            "folder": FOLDER_BY_ELEMENT.get(key, f"{OUR_FOLDER_ROOT}/{key or 'misc'}"),
            "surface_material_hint": "",
            "note": note,
        })

    # ---------- ② 白膜：形状 / 占地 / 高度都是阶段二确认过的 ----------
    for w in (plan.get("whiteboxes") or []):
        index += 1
        key = str(w.get("element_key") or "")
        label = str(w.get("label") or key)
        pos = list(w.get("pos") or [0.0, 0.0])
        fp = list(w.get("footprint_m") or [0.0, 0.0])
        yaw = float(w.get("rot_deg") or 0.0)
        note = str(w.get("note") or "")
        shape = str(w.get("shape") or "").strip().lower()

        # 高度：plan 的 `height_m`（cube 行）优先；plane 行没有，取阶段一登记的薄板厚度。
        if w.get("height_m") is not None:
            height_m = float(w["height_m"])
            how = "plan 的 height_m"
        else:
            thick = thickness_cm.get(key, DEFAULT_SLAB_THICKNESS_CM)
            height_m = thick / 100.0
            how = (f"阶段一清单 {key} 的 size_cm[2] = {thick:g} cm"
                   if key in thickness_cm else f"兜底 {DEFAULT_SLAB_THICKNESS_CM:g} cm（清单里没登记）")
            if key not in thickness_cm:
                warnings.append(f"白膜「{label}」：清单里没有 {key} 的 size_cm[2]，厚度用了兜底值。")

        # Z：贴顶还是贴底 —— 官方 add_cube 的方块**以 Actor 原点为中心**，所以这里算的是中心点。
        anchor, anchor_z = WHITEBOX_VERTICAL.get(key, ("bottom", GROUND_Z_M))
        if key not in WHITEBOX_VERTICAL:
            warnings.append(f"白膜「{label}」：element_key `{key}` 没有竖直口径，按"
                            f"『底面贴地面 {GROUND_Z_M:g} m』处理 —— 不对就说，改代码里的表。")
        z_m = (anchor_z - height_m / 2.0) if anchor == "top" else (anchor_z + height_m / 2.0)

        if shape == "plane":
            note += (f" ｜ 阶段三：官方 PrimitiveTools **没有 add_plane**，按口径压成极薄 cube"
                     f"（厚 {height_m * 100:g} cm，取自{how}）")
        elif shape != "cube":
            warnings.append(f"白膜「{label}」：plan 里的 shape 是 `{shape or '空'}`，"
                            "只认 cube / plane —— 按 cube 处理。")

        rows.append({
            "index": index, "label": label,
            "uid": _row_uid(key, label),
            "name": _safe_actor_name(label, index, key),
            "kind": "whitebox", "element_key": key, "asset_path": "", "primitive": "cube",
            "loc_cm": [num(pos[0] * 100.0), num(pos[1] * 100.0), num(z_m * 100.0)],
            "rot": {"pitch": 0.0, "yaw": num(yaw), "roll": 0.0},
            "scale": [1.0, 1.0, 1.0],
            "size_cm": [num(fp[0] * 100.0), num(fp[1] * 100.0), num(height_m * 100.0)],
            "folder": FOLDER_BY_ELEMENT.get(key, f"{OUR_FOLDER_ROOT}/{key or 'misc'}"),
            "surface_material_hint": SURFACE_MATERIAL_HINT.get(key, ""),
            "note": note,
        })

    # ---------- ③ 越界体检：只**报**不拦（阶段三不改坐标 —— 改坐标是阶段二的事）----------
    bounds = (plan.get("world") or {}).get("bounds") or {}
    lo, hi = bounds.get("min"), bounds.get("max")
    if isinstance(lo, (list, tuple)) and isinstance(hi, (list, tuple)) and len(lo) >= 2:
        over_center: list[str] = []
        over_corner: list[str] = []
        for r in rows:
            x_m, y_m = r["loc_cm"][0] / 100.0, r["loc_cm"][1] / 100.0
            if not (lo[0] <= x_m <= hi[0] and lo[1] <= y_m <= hi[1]):
                over_center.append(f"#{r['index']} {r['label']}（中心 {x_m:g}, {y_m:g}）")
            size = r["size_cm"]
            if r["kind"] != "whitebox" or not (isinstance(size, list) and len(size) >= 2):
                continue                     # 资产行的实际占地要看资产包围盒，这里只体检白膜
            hx, hy = size[0] / 200.0, size[1] / 200.0
            if (x_m - hx < lo[0] or x_m + hx > hi[0]
                    or y_m - hy < lo[1] or y_m + hy > hi[1]):
                over_corner.append(f"#{r['index']} {r['label']}")
        if over_center:
            warnings.append("⚠ 中心点跑到世界包围盒外：" + "；".join(over_center))
        if over_corner:
            warnings.append("⚠ 白膜的四角超出世界包围盒（中心仍在界内）：" + "；".join(over_corner))

    z_rules = [
        f"路面标高 z = {ROAD_SURFACE_Z_M:g} m；两侧地面（人行道 / 草坪**顶面**）"
        f"比路面高 {GROUND_Z_M * 100:g} cm —— 依据：plan 的人行道/连接路白膜自带 height_m=0.15。",
        "白膜 cube：`add_cube` 的方块**以 Actor 原点为中心**（2026-09-26 实测）→ "
        "loc.z = 贴的那一头 ± 高度/2；贴哪一头见本文件 `WHITEBOX_VERTICAL`。",
        f"已有资产：loc.z = {GROUND_Z_M * 100:g} cm（站在抬高的地面上）；"
        "原点不在底面的（见 `ASSET_PIVOT_LIFT_CM`）再加『高出的那段 × scale』。",
        "⚠ 上面几条是**口径**（依据写在常量旁），不是实测值 —— 觉得不对就说，改表里的数即可。",
    ]
    return rows, z_rules, warnings


def _write_build_orders(payload: dict) -> str:
    """把指令表落盘到 `views/build_orders_v1.json`（**这不是 UE 资产，不违反"不许存盘"**）。"""
    VIEWS_DIR.mkdir(parents=True, exist_ok=True)
    BUILD_ORDERS_PATH.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return str(BUILD_ORDERS_PATH)


def _counts_of(rows: list[dict]) -> dict:
    """行数对账：资产 / 白膜 / 合计 / 分元素 / 分分组。"""
    by_element: dict[str, int] = {}
    by_folder: dict[str, int] = {}
    for r in rows:
        by_element[r["element_key"]] = by_element.get(r["element_key"], 0) + 1
        by_folder[r["folder"]] = by_folder.get(r["folder"], 0) + 1
    return {
        "资产行": sum(1 for r in rows if r["kind"] == "asset"),
        "白膜行": sum(1 for r in rows if r["kind"] == "whitebox"),
        "合计": len(rows),
        "分元素": by_element,
        "分分组": by_folder,
    }


@mcp.tool()
async def generate_build_orders() -> BuildOrdersResult:
    """阶段三第 2 步（前半）：把确认过的**平面放置表翻译成 UE 能照做的搭建指令表**。

    读 `views/plan_v1.json`（米）+ `catalog/asset_list.json`（白膜厚度 / 材质线索），
    落盘 `views/build_orders_v1.json`（厘米），**一个 Actor 都不落、不碰关卡**。

    翻译与补全规则（每一条在代码里都有出处）：
      ① 单位：**米 ×100 → 厘米**，只缩放不翻轴（plan 写明与 UE 同为左手系 Z-up）；
      ② 旋转：`rot_deg` 直接当 UE `yaw`，**不反号**（2026-09-26 实测同向）；
      ③ **补 Z**：plan 没有竖直信息 —— 路面 z=0、两侧地面顶面 z=15 cm；白膜 cube 贴顶或贴底
         （`add_cube` 的方块以 Actor 原点为中心，实测）；原点不在底面的资产（树）要抬一段；
      ④ 白膜图元：官方 `PrimitiveTools` **没有 `add_plane`** → `plane` 一律压成极薄 cube；
      ⑤ 材质**一律不贴**，只把阶段一记的材质实例当 `surface_material_hint` 带出去（留给阶段六）。

    ⚠ 本工具**不拦没确认的 plan**（那是 `execute_build` 的闸）：它只翻译。
      但落关卡前 `execute_build` 会**重新**校验闸门与指纹，所以这张表过期了也落不进去。
    ⚠ `z_rules` 那几条 Z 口径是**推出来的口径、不是实测值** —— 觉得不对就说，改常量即可。
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        raise ToolError("还没有规划数据（views/plan_v1.json）：先走完阶段二，再生成指令表。")
    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    if not (plan.get("assets") or plan.get("whiteboxes")):
        raise ToolError("plan_v1.json 是**初始化状态**（两张表都空）—— 没有坐标可翻译。")

    rows, z_rules, warns = _compose_build_rows(plan, load_json(ASSET_LIST_PATH) or {})
    plan_hash = planning.plan_geometry_hash(plan)
    counts = _counts_of(rows)

    path = _write_build_orders({
        "stage": "阶段三 · 搭建指令表（离线翻译件）",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "unit": "cm",
        "plan_hash": plan_hash,
        "world": plan.get("world") or {},
        "z_rules": z_rules,
        "counts": counts,
        "rows": rows,
        "warnings": warns,
        "note": "一物一行，顺序与 plan_v1.json 一致（已有资产在前、白膜在后）。"
                "loc_cm 由 plan 的 pos（米）×100 得来，坐标本身未做任何改动；"
                "补的只有 Z 与白膜图元 —— 依据见 z_rules。",
    })

    gate = planning.gate_check(plan)
    state = planning.acceptance_state(plan)
    extra: list[str] = []
    # 阶段三第 1 步（搭哪张图）有没有收到用户答复 —— 提前说，免得 agent 到 execute_build 才撞墙。
    _tgt = _load_build_target()
    if not (_tgt.get("answer") if isinstance(_tgt.get("answer"), dict) else {}):
        extra.append(
            "⚠ **还没拿到用户对「搭哪张图」的答复** —— `execute_build()` 会**拒收**。"
            "先 `check_build_target()`（只读地问：当前关卡 / 可选的图 / `UEMCP/` 下有没有旧东西）→ "
            "**把问题交给用户、停下等他打字** → 再带他的原话调 "
            "`check_build_target(decision=…, user_quote=…)` 把答复记下来。")
    if not gate["confirmed"]:
        extra.append("⚠ 这份 plan **还没被确认**（闸门关着）—— execute_build 会拒收。")
    elif not gate["plan_hash_ok"]:
        extra.append("⚠ 几何指纹对不上（plan_v1.json 被改过）—— 上次确认已作废，execute_build 会拒收。")
    if state != "accepted":
        extra.append(f"⚠ 阶段二验收状态是 `{state}`（不是 accepted）—— execute_build 会拒收。")

    return BuildOrdersResult(
        stage="阶段三 · 搭建指令表（离线翻译件）",
        data_path=path,
        plan_hash=plan_hash,
        world=plan.get("world") or {},
        counts=counts,
        z_rules=z_rules,
        rows=[BuildOrderRow(**r) for r in rows],
        warnings=warns + extra,
        next_step=(
            f"指令表已落盘（{len(rows)} 行）。**下一步调 `execute_build()`** —— 它会"
            "① 重新按当前 plan 算一遍（保证与几何一致）② 整批校验（闸门 / 指纹 / 路径 exists / "
            "行数 / 白膜自洽）③ 清掉 UEMCP/ 下的旧 Actor ④ 一次性把这一批全落进关卡 ⑤ 读回来对账。"
            "想先看不动手就传 `dry_run=true`。⚠ 全程**不存盘**。\n"
            "**局部改动别全量重摆**：关卡里已经搭好、这次只改了几行 → 用 "
            "`execute_build(mode=\"incremental\")`（只动与台账比变了的行）；"
            "还没有台账就先 `execute_build(mode=\"incremental\", adopt=true)` 认领现状。"
        ),
    )


@mcp.tool()
async def execute_build(
    ctx: Context[AppContext],
    mode: Annotated[str, Field(
        description=(
            "**默认 `auto`，一般别手动指定**：有可用台账就**只动「与台账比变了的那些行」**"
            "（增量，其余 Actor 一个都不碰）；没有台账（第一次搭 / 换了关卡）才全量。"
            "`incremental` = 强制增量；`full` = **全量重摆（会把 `UEMCP/` 下全部 Actor 删掉重摆）**"
            "—— 真跑时还要 `force_full=true` 才放行，**别用它来改几行**"
        ))] = "auto",
    force_full: Annotated[bool, Field(
        description=(
            "**只有 `mode=\"full\"` 真跑时才需要**：确认你**确实要**把 `UEMCP/` 下的 Actor 全删了重摆。"
            "台账存在时不给它 → `full` 会被拒收，并告诉你这次其实只变了几行（该走增量）"
        ))] = False,
    adopt: Annotated[bool, Field(
        description=(
            "**只与 `mode=\"incremental\"` 合用**：不改任何 Actor，把关卡现状（`UEMCP/` 下现有 "
            "Actor 的 label + 变换）读成台账（基线）。用在『场景已经搭好了但还没有台账』的时候，"
            "省掉一次白重摆。跑完它再调 `mode=\"incremental\"` 才是真正落差异"
        ))] = False,
    dry_run: Annotated[bool, Field(
        description="true = 只校验 + 对账，**一个 Actor 都不落**（先看一遍再动手用这个）")] = False,
    verify: Annotated[bool, Field(
        description=("true = 落完之后逐个读回 get_actor_transform 与指令表对账，"
                     "**白膜再读一遍组件尺寸（RelativeScale3D）**（多花 N 次官方调用）"))] = True,
    accept_user_edits: Annotated[bool, Field(
        description=(
            "**默认 false = 保护用户在 UE 里手改的东西**：动手前先逐行读一遍**关卡现状**与台账比 —— "
            "对不上（人工挪过 / 转过 / 缩放过 / 改过白膜厚薄）的行、以及台账里没有的活 Actor，"
            "**一律拒收并列出来**（一个 Actor 都不动）。"
            "确认『这些人工改动可以按 plan 覆盖（会被删掉重摆）』才传 true。"
            "⚠ 不要为了「让它过」随手传 true —— 那正是「用户手动改的东西被删了」的来源"
        ))] = False,
) -> BuildReport:
    """阶段三第 2 步（后半）：**把放置表落进关卡 —— 默认只动改过的行（增量），不推倒重来**。

    流程（顺序不能反）：
      ⓪ **「搭哪张图」闸**（2026-09-26 加）：`check_build_target()` 里那份**用户答复**必须存在，
         且与当前关卡对得上（选开新图而他还没换图 / 指定了别的图 / 中途换了图 → 拒收）。
         ⚠ 演练（`dry_run=true`）与 `adopt=true` 不拦（它们不碰关卡），但演练会在报告里点名
         "答复还没记"。
      ① **整批校验**：阶段二闸门 `confirmed` + 几何指纹 + 验收状态 `accepted` + 用户原话；
         资产路径逐个官方 `exists()`；白膜行不许带路径、必须有图元与三维尺寸；
         行数 == plan 的 `assets + whiteboxes` —— **任何一条不过 → 一个 Actor 都不落**
         （与 `confirm_assets` 拒收时"一个字节都不写"同一个道理）。
      ② **人工痕迹闸**（2026-09-26 加）：清场 / 重摆之前，先逐行读**关卡现状**与台账比
         （位置 / 朝向 / 缩放 / 白膜厚薄）；对不上的行、以及台账解释不了的活 Actor，
         **默认拒收**（一个 Actor 都不动），除非显式传 `accept_user_edits=true`。
         ⚠ 为什么要它：客户原话「用户手动改的东西不该删 —— 我 full 重摆给删了」；
           以前 `full` 无条件清空 `UEMCP/`，增量则**从不读现状**，手改的东西既没人保护也没人报。
      ③ **幂等清场**：只清 outliner 里 `UEMCP/` 下的 Actor（那才是**我们的**）；
         关卡自带的方向光 / 天空 / 玩家起点等**一个都不碰**。
      ④ **按表落**：资产行 → `add_to_scene_from_asset`；白膜行 →
         `add_to_scene_from_class(/Script/Engine.Actor)` + `PrimitiveTools.add_cube`；
         然后逐个 `set_actor_folder` 进 `UEMCP/<类>`（这也是下一次清场的判据）。
      ⑤ **读回对账**：逐个 `get_actor_transform` 与指令表的 `loc_cm / yaw / scale` 比；
         **白膜另外读组件 `RelativeScale3D`（×100 = 厘米）核对尺寸** —— 对不上的原地报出来（不掩饰）。
    ⚠ **绝不存盘**（不调任何 save 类工具）—— 关卡脏没脏由用户在 UE 里看。
    ⚠ 白膜尺寸**不能**用官方 `get_actor_bounds` 复核：它对这类 Actor 恒返回 ±128 的**假包围盒**
      （2026-09-26 实测）—— 所以走组件 `RelativeScale3D`（见 `_read_cube_size_cm`）。

    **增量（`mode="incremental"`，2026-09-26 用户要求）**：已经大搭建好的场景要局部改，就
    "回去改图 → 用户重新确认 → 只重摆改动的那几行"。差异靠**台账** `views/build_state_v1.json`
    与指令表的 `uid` 对账，分四类：`added`（表里有、台账没有）/ `changed`（同一 uid 但位置 /
    朝向 / 缩放 / 路径 / 白膜尺寸 / 分组变了）/ `removed`（台账有、表里没了）/ `drift`（台账说它在，
    关卡里却找不到 → 当"要重摆"）。**没变的行一个 Actor 都不碰。**
    ⚠ 台账是我们自己的 JSON，**不是 UE 存盘**。做增量的前提是台账存在且对得上当前关卡 ——
      不满足时**拒收**（一个 Actor 都不动），出路是 `adopt=true` 认领现状、或先跑一次 `full`。
    ⚠ 关卡 `UEMCP/` 下若有台账与指令表**都解释不了**的 Actor（有人手动改过名 / 手动摆过）→
      **拒收并列出来**。增量只能靠对账，对不上就不猜、也不删。
    ⚠ 交付后的自评点过一条「它不会告诉我『用户手动改了地皮你别删』」—— 现在会了：
      每次动手前都会读一遍现状，落在 `diff["人工改过（现状与台账不符）"]` 与 `warnings` 里。
    """
    planning = _planning_modules()
    calls = 0

    # ⚠ 碰 UE 之前先过**回读闸**（2026-09-26 用户要求把软约束变硬）：这一版没回读过，就不许落关卡。
    _readback_guard()

    # ---------- ① 整批校验（不过就一个 Actor 都不落）----------
    if not planning.OUT_JSON.exists():
        raise ToolError("还没有规划数据：先走完阶段二（generate_plan → 出图 → confirm_plan）。")
    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    problems: list[str] = []

    gate = planning.gate_check(plan)
    if not gate["confirmed"]:
        problems.append("阶段二闸门没过：plan_v1.json 的 `confirmation.confirmed` 是 false"
                        "（用户还没确认这一版规划）")
    if not gate["plan_hash_ok"]:
        problems.append("几何指纹对不上：plan_v1.json 被改过，上一次确认已作废"
                        "（要重新出图、重新确认）")
    state = planning.acceptance_state(plan)
    if state != "accepted":
        problems.append(f"阶段二验收状态是 `{state}`，不是 `accepted`")

    # ⚠ 证据链（2026-09-26）：确认里必须带**用户原话** —— 图是 agent 画的、确认是它调的，
    #   没有这句话就无法证明有人点过头（实测被绕过一次：客户当场质问"图都不先让我确认就摆"）。
    _conf = plan.get("confirmation") or {}
    if not str(_conf.get("user_quote") or "").strip():
        problems.append(
            "这一版的确认里**没有用户原话**（`confirmation.user_quote` 为空）—— "
            "证明不了是用户点的头。请按「交付图 → 停下等用户回话 → "
            "`confirm_plan(confirmed_by=…, user_quote=原话)`」重走一遍确认，再来搭建")

    rows, _z_rules, warns = _compose_build_rows(plan, load_json(ASSET_LIST_PATH) or {})

    want = len(plan.get("assets") or []) + len(plan.get("whiteboxes") or [])
    if len(rows) != want:
        problems.append(f"指令表行数 {len(rows)} != plan 的 assets+whiteboxes {want}（漏摆或重复）")

    for r in rows:
        if r["kind"] == "whitebox":
            if r["asset_path"]:
                problems.append(f"第 {r['index']} 行（{r['label']}）：白膜行带了资产路径 —— 自相矛盾")
            if not r["primitive"]:
                problems.append(f"第 {r['index']} 行（{r['label']}）：白膜行没写图元")
            if not (isinstance(r["size_cm"], list) and len(r["size_cm"]) == 3):
                problems.append(f"第 {r['index']} 行（{r['label']}）：白膜行尺寸不是三维的")
        else:
            if not r["asset_path"]:
                problems.append(f"第 {r['index']} 行（{r['label']}）：资产行没有路径")
            if len(r["loc_cm"]) != 3:
                problems.append(f"第 {r['index']} 行（{r['label']}）：坐标不是三维的")

    # 资产路径存在性：**逐个**调官方 exists()（实测教训：资产库会在工作期间少东西）
    unique_paths = sorted({r["asset_path"] for r in rows if r["kind"] == "asset" and r["asset_path"]})
    dead: list[str] = []
    for p in unique_paths:
        calls += 1
        try:
            ok = await call_official(ctx, "exists", {"path": p}, toolset=TS_ASSET)
        except ToolError as exc:
            dead.append(f"{p}（调用失败：{exc}）")
            continue
        if not ok:
            dead.append(p)
    if dead:
        problems.append("资产路径验不过（官方 exists() 返回否）：" + "、".join(dead))

    if problems:
        raise ToolError(
            "拒绝搭建：**一个 Actor 都没落**。问题如下 ——\n· " + "\n· ".join(problems)
            + "\n（口径见 docs/阶段三-资产布局生成.md §8：先整批校验、再执行。）"
        )

    # ---------- 当前关卡 + 现状清点（**只数根文件夹一次**）----------
    if mode not in ("auto", "full", "incremental"):
        raise ToolError(f"`mode` 只认 `auto`（默认，推荐）/ `full` / `incremental`，收到 `{mode}`。")

    level = str(await call_official(ctx, "get_current_level", {}, toolset=TS_SCENE) or "")
    calls += 1

    # ⚠ 拿到"当前是哪张图"之后、**动任何 Actor 之前**：先过**「搭哪张图」这道闸**（2026-09-26 加）。
    #   它挡的是"搭错图" —— 这一步以前只写在工具描述与 docs 里，代码里没人核对（软约束）。
    #   演练不拦（不碰关卡）；`adopt` 也不拦（它只把现状读成台账，**一个 Actor 都不动**）。
    if not dry_run and not adopt:
        _build_target_guard(level)

    # ⚠ 真跑之前还要过**开场动作闸**（2026-09-26 加）：`official_status()` + `get_asset_list()`
    #   都调过没有 —— 客户 agent 自评里承认这两条他都没做。`dry_run` / `adopt` 不拦。
    if not dry_run and not adopt:
        _session_prereq_guard()

    # ⚠ 只数根文件夹一次（recursive=True 已含子文件夹）。2026-09-26 实测踩到：
    #   连根带 7 个子文件夹各数一遍 = **2 倍**（根 89 报成 178）。
    live_refs: list[str] = []
    try:
        found = await call_official(
            ctx, "get_actors_in_folder",
            {"folder_path": OUR_FOLDER_ROOT, "recursive": True}, toolset=TS_SCENE)
        calls += 1
        for item in (found or []):
            ref = _ref_path(item)
            if ref:
                live_refs.append(ref)
    except ToolError as exc:
        # 「文件夹不存在」= 这张图上还没摆过我们的东西（**首次搭建的正常情况**），
        # 不是故障 —— 别把它报成警告（2026-09-26 首次真跑就被它刷了一条红字）。
        if "does not exist" not in str(exc).lower():
            warns.append(
                f"读 `{OUR_FOLDER_ROOT}/` 现有 Actor 失败（{exc}）—— 按『当前没有旧东西』继续。")

    ledger = _load_build_state()

    # ---------- 定模式：**默认 auto = 能不推倒就不推倒**（2026-09-26 实测教训）------------
    # 背景（用户问"为啥总是全删再摆放，我 MCP 工具里有局部改的啊"）：`mode` 原先默认 `full`，
    #   于是**没读参数说明的 agent** 每次都用默认值 → **每轮全清重摆 89 个**，好几轮白做。
    #   → 教训：**默认值必须落在最省、最不破坏的那条路上**，不能指望 agent 去读 schema。
    #   → 现在：有对得上的台账 = 增量；没有（第一次搭 / 换关卡）= 全量；显式 `full` 真跑要二次确认。
    ledger_by_uid = {str(x.get("uid")): x for x in (ledger.get("rows") or [])
                     if isinstance(x, dict) and x.get("uid")}
    mode_why = ""
    if mode == "auto":
        if adopt:
            # `adopt`（认领现状）本来就是增量语义；给定 auto 时必须先落到 incremental，
            # 否则会被下面那句"adopt 只跟 incremental 合用"拒掉（2026-09-26 自查发现的回归）。
            mode, mode_why = "incremental", "auto → 增量（adopt 认领现状）"
        else:
            usable = bool(ledger_by_uid) and str(ledger.get("level") or "") in ("", level)
            mode = "incremental" if usable else "full"
            mode_why = ("auto → 增量（台账对得上）" if usable
                        else "auto → 全量（没有可用台账：第一次搭或换了关卡）")
    elif mode == "full" and not dry_run and ledger_by_uid and not force_full:
        # 显式全量 + 有台账 = 十有八九是"没读参数就写了 full"或"手滑" → 拒收一次，把话说清
        _lb = ledger_by_uid
        n_changed = 0
        for _r in rows:
            _old = _lb.get(_r["uid"])
            if _old is None or _row_changes(_r, _old):
                n_changed += 1
        raise ToolError(
            f"拒收：你选的是**全量重摆**（`mode=\"full\"`）—— 那会把 `{OUR_FOLDER_ROOT}/` 下的 "
            f"{len(live_refs)} 个 Actor **全部删掉再摆一遍**。而这一版相对台账大约只动了 "
            f"**{n_changed} 行**，增量就够（默认 `mode=\"auto\"` 会自动走增量）。\n"
            "· 只想改几行 → 去掉 `mode`（或写 `mode=\"incremental\"`）。\n"
            "· 确实要推倒重来（关卡被搞乱了 / 想整批重摆）→ 再显式传 `force_full=true`。"
        )

    # ---------- ⚠「没有台账 + 关卡里已经有我们的 Actor」= **别悄悄全量清场** --------------
    # 2026-09-26 加（客户 agent 自评：「局部改不要全部重做 —— 反复违反，几乎每次都 mode=full
    #   全量重摆」；「用户手动改的东西不该删 —— 我 full 重摆给删了」）。
    # 为什么单独设这一道：`auto` 在没有可用台账时会落到**全量**，而全量 = 把 `UEMCP/` 下
    #   **全部** Actor 删掉重摆。这一步在**读现状之前**就拦住，既不再花那几十次调用，
    #   也把"安全的出路"直接摆在眼前（`adopt` 认领现状 = 一个 Actor 都不动）。
    # 判据：全量 + 关卡里已有我们的 Actor + **没有可用台账**（第一次搭不在内：那时 live_refs 为空）
    #   + 不是演练 + **没同时给 force_full 与 accept_user_edits**。
    if (mode == "full" and live_refs and not ledger_by_uid and not dry_run
            and not (force_full and accept_user_edits)):
        raise ToolError(
            f"拒收：`{OUR_FOLDER_ROOT}/` 下已经有 **{len(live_refs)} 个 Actor**，"
            "但**没有可用台账**（第一次搭那次没写 / 换了关卡 / 台账被删）—— "
            "现在这一版会走**全量重摆**，把它们**全部删掉重来** —— **一个 Actor 都没动**。\n"
            "· **先认领现状**（推荐，不动任何 Actor）：`execute_build(mode=\"incremental\", "
            "adopt=true)` 把关卡现状登记成基线 → 再 `execute_build(mode=\"incremental\")` 只落差异。\n"
            "· 确实要推倒重来（关卡被搞乱了 / 想整批重摆）："
            "`mode=\"full\", force_full=true, accept_user_edits=true` —— **两个都要给**。\n"
            "（为什么拦：客户 agent 自评原话「局部改不要全部重做 —— 反复违反，几乎每次都 mode=full "
            "全量重摆」。没有台账时全量是唯一选择，但「悄悄清掉 89 个再摆一遍」不该是默认路径。）"
        )

    # ---------- adopt：把关卡现状读成基线（**一个 Actor 都不动**）----------
    if adopt:
        if mode != "incremental":
            raise ToolError("`adopt` 只跟 `mode=\"incremental\"` 合用（`full` 本来就会重建台账）。")
        if dry_run:
            raise ToolError("`adopt` 要写台账 —— 与 `dry_run` 冲突，请去掉一个。")
        if not live_refs:
            raise ToolError(f"`{OUR_FOLDER_ROOT}/` 下一个 Actor 都没有 —— 没有现状可认领。"
                            "关卡还没搭就用 `mode=\"full\"`。")
        by_name: dict[str, dict] = {}
        for r in rows:
            by_name.setdefault(r["name"], r)          # Actor label = 我们 spawn 时传的 name（实测）
        adopted_rows: list[dict] = []
        unmatched: list[str] = []
        for ref in live_refs:
            calls += 1
            try:
                label = str(await call_official(
                    ctx, "get_label", {"actor": {"refPath": ref}}, toolset=TS_ACTOR) or "")
            except ToolError as exc:
                unmatched.append(f"{ref}（读 label 失败：{exc}）")
                continue
            r = by_name.get(label)
            if r is None:
                unmatched.append(f"{ref}（label = `{label}`，指令表里没有这一行）")
                continue
            calls += 1
            loc = yaw = scale = None
            try:
                got = await call_official(
                    ctx, "get_actor_transform", {"actor": {"refPath": ref}}, toolset=TS_ACTOR)
                loc, yaw, scale = _xform_of(got)
            except ToolError as exc:
                warns.append(f"「{r['label']}」读回变换失败（{exc}）"
                             " —— 台账里这一行记的是**指令值**，不是实测值。")
            entry = _ledger_row(r, ref, loc, yaw, scale, readback=loc is not None)
            if r["kind"] == "whitebox":
                # ⚠ 白膜尺寸必须**单独从关卡读**（详见 _read_cube_size_cm 的说明）：
                #   照抄"当前指令表"的尺寸会让"刚加宽过的那几行"被判成"没变" → 静默不摆。
                dim, used = await _read_cube_size_cm(ctx, ref)
                calls += used
                entry["size_cm"] = dim
                entry["size_readback"] = dim is not None
                if dim is None:
                    warns.append(
                        f"⚠ 「{r['label']}」的白膜尺寸**读不回来** —— 台账里记 null，"
                        "下一次增量会把它当『尺寸变了』**重摆一遍**（安全侧：宁可多摆一行）。")
                elif r.get("size_cm") and [round(float(x), 2) for x in dim] != [
                        round(float(x), 2) for x in r["size_cm"]]:
                    warns.append(
                        f"⚠ 「{r['label']}」的**实际尺寸与当前指令表不一致**：关卡里 {dim} cm、"
                        f"指令表 {r['size_cm']} cm —— 台账记的是**关卡实测值**"
                        "（这就是『已搭好的场景遇上改了指令表』该有的样子：下次增量会重摆它）。")
            adopted_rows.append(entry)
        _save_build_state(level, gate["plan_hash"], "adopt", adopted_rows)
        adopted_uids = {x["uid"] for x in adopted_rows}
        not_yet = [r["label"] for r in rows if r["uid"] not in adopted_uids]
        size_lie = [x["label"] for x in adopted_rows
                    if x.get("kind") == "whitebox" and not x.get("size_readback")]
        if size_lie:
            warns.append(
                f"⚠ 有 {len(size_lie)} 行白膜的尺寸**没能从关卡读回来**（台账里记 null）——"
                "下一次增量会把它们当『尺寸变了』各重摆一遍。清单："
                + "、".join(size_lie[:8]) + ("…" if len(size_lie) > 8 else ""))
        if unmatched:
            warns.append(
                f"⚠ 有 {len(unmatched)} 个 `{OUR_FOLDER_ROOT}/` 下的 Actor 认不出对应哪一行 —— "
                "它们会在下次增量时**挡住**（拒收），到时要么删掉它们、要么跑一次 `full`：\n· "
                + "\n· ".join(unmatched))
        return BuildReport(
            stage="阶段三 · 认领现状（adopt：只读现状 + 写台账，没动任何 Actor）",
            level=level, dry_run=False, refused=False, reason="adopt：不动 Actor，只登记基线",
            plan_hash=gate["plan_hash"], planned=len(rows),
            mode="incremental", ledger_path=str(BUILD_STATE_PATH), ledger_written=True,
            diff={"认领回来的": len(adopted_rows), "认不出的": len(unmatched),
                  "指令表里还没有的": not_yet},
            removed=0, placed=0, verified=0, groups={}, rows=[],
            official_calls=calls,
            next_step=("台账已按**关卡现状**登记（一个 Actor 都没动、也没存盘）。之后的循环是："
                       "改 plan（`generate_plan`）→ **重画图（写新指纹 + 本轮变更集那几行）** → "
                       "让用户看图确认（`confirm_plan`）→ `generate_build_orders()` → "
                       "`execute_build(mode=\"incremental\")` —— 那一次只动改动过的行。"
                       "⚠ 改完先看 `get_plan().acceptance.change_set.required_labels`："
                       "**那就是这一轮图里只需出现的那几行**，别整张重画。"),
            warnings=warns,
        )

    # ---------- 差异：这次到底要动哪几行（增量全靠它）----------
    orders: dict[str, dict] = {}
    dup: list[str] = []
    for r in rows:
        if r["uid"] in orders:
            dup.append(r["label"])
        orders[r["uid"]] = r
    if dup:
        raise ToolError("指令表里有**两行 label 相同**（uid 撞了）：" + "、".join(dup)
                        + " —— 增量对账认不出谁是谁。请把 label 改成互不相同再走增量。")

    # 增量是**按 Actor 的 label 认领**的（`_safe_actor_name` 会把括号 / # / 空格洗成下划线）：
    # 两个不同的 label 洗出同一个名字就认错了 —— 与其猜，不如当场拒收。
    name_owner: dict[str, list[str]] = {}
    for r in rows:
        name_owner.setdefault(r["name"], []).append(r["label"])
    clash = {n: ls for n, ls in name_owner.items() if len(ls) > 1}
    if clash and mode == "incremental":
        raise ToolError(
            "这些 label 洗干净之后**撞成同一个 Actor 名**了 —— 增量靠 label 认领，撞名就认不出来：\n· "
            + "\n· ".join(f"`{n}` ← " + "、".join(ls) for n, ls in clash.items())
            + "\n请把这几个 label 改得互不相同（阶段二允许同类多行，但每行要有区别）。")

    live_set = set(live_refs)          # `ledger_by_uid` 已在上面"定模式"时算好（同一份台账）

    if mode == "incremental" and not ledger_by_uid:
        raise ToolError(
            f"增量搭建需要**台账**（`{BUILD_STATE_PATH}`），现在没有 —— **一个 Actor 都没动**。"
            "两条出路：\n"
            "· 关卡里已经搭好了 → 先用 `adopt=true` 认领现状（只读 + 写台账，**不动任何 Actor**）；\n"
            "· 关卡还没搭 / 想推倒重来 → 用 `mode=\"full\"` 跑一次（会先清 UEMCP/ 再整批重摆）。")
    if mode == "incremental" and str(ledger.get("level") or "") not in ("", level):
        raise ToolError(
            f"台账记的关卡是 `{ledger.get('level')}`，当前关卡是 `{level}` —— **换图了**，"
            "台账里的 Actor 引用在这儿没有意义 —— **一个 Actor 都没动**。要么切回那张图，"
            "要么在**这张图上**用 `adopt=true` 重新登记，要么 `mode=\"full\"` 重摆。")

    # ---------- 关卡现状 vs 台账：**用户手改过的东西不许被静默删掉**（2026-09-26 加）----------
    # 这一步要**读关卡**（每个待查行 1 次 `get_actor_transform`，白膜行再 +2 次读组件尺寸），
    # 所以"查哪些行"有取舍 —— 扫描范围定在下面「算完差异之后」（见那段注释）。
    ledger_rows_all = [x for x in (ledger.get("rows") or []) if isinstance(x, dict)]
    known_refs = {str(x.get("actor") or "") for x in ledger_rows_all}
    unknown_refs = [ref for ref in live_refs if ref and ref not in known_refs]

    added: list[dict] = []
    # ⚠ 这里是**三元组**：(指令行, 台账里的旧行, 变在哪的说明)。
    #   2026-09-26 真跑踩到过：只存两项 `(行, 说明)`，下面 `remove_refs` 却按"(行, 旧行)"解包 →
    #   拿到的 `old` 是那个**说明 list** → `AttributeError: 'list' object has no attribute 'get'`
    #   （宿主只显示「Error executing tool execute_build」，得去 logs/harness.log 才看到栈）。**别改回去。**
    changed: list[tuple[dict, dict, list[str]]] = []
    same: list[dict] = []
    gone: list[dict] = []
    drifted: list[tuple[dict, dict]] = []
    reclaim_actor: dict[str, str] = {}
    strays: list[str] = []

    if mode == "incremental":
        for uid, r in orders.items():
            old = ledger_by_uid.get(uid)
            if old is None:
                added.append(r)
                continue
            actor = str(old.get("actor") or "")
            if not actor or actor not in live_set:
                # 台账说它在这儿，关卡里却没有（或上次就没落成）→ 得重摆
                drifted.append((r, old))
                continue
            why = _row_changes(r, old)
            if why:
                changed.append((r, old, why))
            else:
                same.append(r)
        for uid, old in ledger_by_uid.items():
            if uid not in orders:
                gone.append(old)

        # 台账解释不了的活 Actor：读 label 试着认领；认不出就**拒收**（不猜、不删）
        known_refs = {str(x.get("actor") or "") for x in ledger_by_uid.values()}
        for ref in live_refs:
            if ref in known_refs:
                continue
            calls += 1
            try:
                label = str(await call_official(
                    ctx, "get_label", {"actor": {"refPath": ref}}, toolset=TS_ACTOR) or "")
            except ToolError as exc:
                strays.append(f"{ref}（读 label 失败：{exc}）")
                continue
            hit = next((r for r in added if r["name"] == label), None)
            if hit is None:
                strays.append(f"{ref}（label = `{label}`：台账里没有它，指令表里也没有这个名字）")
            else:
                added.remove(hit)
                reclaim_actor[hit["uid"]] = ref
        if strays:
            raise ToolError(
                f"`{OUR_FOLDER_ROOT}/` 下有**台账和指令表都解释不了**的 Actor —— "
                "**一个 Actor 都没动**：\n· " + "\n· ".join(strays)
                + "\n（多半是有人在 UE 里手动改名 / 手动摆过。增量只能靠对账，对不上就不猜、"
                  "也不删 —— 请先把它们清理掉，或用 `adopt=true` 重新登记，或跑一次 `full`。）")

    # ---------- 扫描范围：**读关卡现状**是要花官方调用的，所以按"要动多少"来定 --------
    # 2026-09-26 的取舍（别随手改）：每查一行 1 次 `get_actor_transform`，白膜行再 +2 次
    #   （读组件尺寸）。真跑增量时**只扫这次会被删掉的那些行** —— 保护够用，代价与"动多少"成正比
    #   （实测口径：89 场景里改 5 行 ≈ 多花 15 次，而不是 +189 次）。
    # 下面三种情况扫**全表**：
    #   · `dry_run` —— 它是"看清楚"的那一步（用户问「我手改的东西还在不在」就靠它）；
    #   · `accept_user_edits=true` —— 要按 plan 覆盖人工改动，得先知道**哪些**被改过；
    #   · 全量 —— 本来就要把 `UEMCP/` 下全部清掉，每一行都在风险里。
    if dry_run or accept_user_edits or mode == "full":
        scan_rows = ledger_rows_all
        scan_why = "全表（演练 / 要按 plan 覆盖人工改动 / 全量重摆）"
    else:
        scan_rows = gone + [o for _r, o, _w in changed]
        scan_why = "只扫这次会被删掉的行（真跑增量）"
    manual, used = await _live_vs_ledger(ctx, scan_rows, live_set)
    calls += used
    if manual:
        warns.append(
            f"⚠ 有 {len(manual)} 行**现状与台账不符**（人工改过 / 官方没照做；扫描范围：{scan_why}）："
            + "；".join(f"「{m['label']}」{'；'.join(m['why'])}" for m in manual[:6])
            + ("…" if len(manual) > 6 else ""))
    # ⚠ `unknown_refs` 只在**全量**时报/拦：增量那边有更细的处置（读 label 认领，认不出就拒收），
    #   在这里重复一遍会把"能认领回来的新行"误报成人工痕迹。
    if unknown_refs and mode == "full":
        warns.append(
            f"⚠ `{OUR_FOLDER_ROOT}/` 下有 {len(unknown_refs)} 个 Actor **台账里没有**"
            "（可能是你手动摆的，也可能是上一版没登记）：" + "、".join(unknown_refs[:8])
            + ("…" if len(unknown_refs) > 8 else ""))

    # 用户手改过的行：`accept_user_edits=true` 时**当"改动"重摆**（plan 覆盖现状）；
    #   不传的话它们**一个都不动**，只有"会被删掉的那些"才走下面那道拒收闸。
    if accept_user_edits and mode == "incremental":
        promoted: list[str] = []
        for m in manual:
            r = orders.get(m["uid"])
            if r is None or any(r["uid"] == x["uid"] for x, _o, _w in changed):
                continue
            changed.append((r, m["ledger"], [f"人工改过 → 按 plan 覆盖：{'；'.join(m['why'])}"]))
            promoted.append(r["uid"])
        if promoted:
            same = [r for r in same if r["uid"] not in set(promoted)]
            warns.append(f"按 `accept_user_edits=true`：{len(promoted)} 行**人工改过的**被当成改动重摆。")

    targets: list[dict] = rows if mode == "full" else (
        [r for r in added if r["uid"] not in reclaim_actor]
        + [r for r, _old, _why in changed]
        + [r for r, _old in drifted])
    remove_refs: list[str] = live_refs if mode == "full" else [
        str(old.get("actor") or "") for old in (gone + [o for _r, o, _w in changed])
        if str(old.get("actor") or "") in live_set]

    # ---------- 人工痕迹的处置：**默认拒收，不静默删**（2026-09-26 加）------------------
    # 这一步在**清场之前**：清场一旦开始，用户手改的东西就没了（客户原话：
    # 「用户手动改的东西不该删 —— 我 full 重摆给删了」）。
    if mode == "incremental":
        will_delete_uids = ({str(o.get("uid") or "") for o in gone}
                            | {str(o.get("uid") or "") for _r, o, _w in changed})
        traces = [m for m in manual if m["uid"] in will_delete_uids]
    else:
        # 全量会把 UEMCP/ 下**全部**清掉：台账能认但现状被改过的是人工痕迹，
        # 台账**根本解释不了**的活 Actor 也是（有人手动摆在了我们的文件夹里）。
        traces = list(manual) + [
            {"label": ref, "why": ["台账里没有它 —— 可能是你手动摆的，也可能是上一版没登记"]}
            for ref in unknown_refs]
    if traces and not accept_user_edits and not dry_run:
        head = "\n".join(f"· 「{t['label']}」{'；'.join(t['why'])}" for t in traces[:12])
        more = f"\n（还有 {len(traces) - 12} 处没列全）" if len(traces) > 12 else ""
        raise ToolError(
            f"拒绝搭建：`{OUR_FOLDER_ROOT}/` 下有 **{len(traces)} 处人工痕迹**会被这次操作删掉 —— "
            "**一个 Actor 都没动**：\n" + head + more + "\n"
            "两条出路：\n"
            "· **保住它们**（推荐）：把用户想要的改动**写回阶段二** —— "
            "`generate_plan(patch=[...])` → 重画图（写新指纹 + 本轮变更集那几行）→ 用户看图确认 → "
            "`generate_build_orders()` → 增量落。这样 plan 与关卡就一致了。\n"
            "· **按 plan 覆盖它们**（会把上面这些行删掉重摆）：跟用户确认过，再传 "
            "`accept_user_edits=true` 调一次。\n"
            "（为什么拦：客户原话「用户手动改的东西不该删」。以前 `full` 无条件把 "
            f"`{OUR_FOLDER_ROOT}/` 下全清、增量**从不读现状** —— 手改的东西就这么没了，还没人报。）")

    if dry_run:
        if mode == "incremental":
            diff_dry = {
                "台账": str(BUILD_STATE_PATH) + ("" if ledger_by_uid else "（**还没有**）"),
                "要删": [old.get("label") for old in gone]
                        + [r["label"] for r, _o, _w in changed],
                "要摆": [r["label"] for r in targets],
                "没动": len(same),
                "认领回来的": [orders[u]["label"] for u in reclaim_actor],
                "台账说在、关卡里却没了": [r["label"] for r, _ in drifted],
                "改动明细": {r["label"]: w for r, _o, w in changed},
                "人工改过（现状与台账不符）": {m["label"]: m["why"] for m in manual},
            }
        else:
            diff_dry = {
                "全量重摆": True,
                "要删": f"清掉 {OUR_FOLDER_ROOT}/ 下**全部** {len(remove_refs)} 个旧 Actor",
                "要摆": f"指令表**全部** {len(targets)} 行",
                "没动": 0,
                "人工改过（现状与台账不符）": {m["label"]: m["why"] for m in manual},
                "台账解释不了的活 Actor": unknown_refs,
            }
        dry_warns = [
            f"演练：当前 `{OUR_FOLDER_ROOT}/` 下有 {len(live_refs)} 个 Actor"
            "（全量会把它们全清掉重摆；增量只动差异那几行）。",
            (f"⚠ 演练的是**全量重摆**（{mode_why or 'mode=full'}）：真跑会被**拒收**，"
             "除非显式传 `force_full=true`。只想改几行就别传 `mode`（默认 auto 走增量）。"
             if mode == "full" and ledger_by_uid else
             f"演练模式：**{('增量' if mode == 'incremental' else '全量')}**"
             f"（{mode_why or mode}）。"),
        ]
        _tgt_ans = _load_build_target().get("answer")
        if not (isinstance(_tgt_ans, dict) and _tgt_ans):
            dry_warns.append(
                "⚠ **真跑会被拒收**：还没拿到用户对**「搭哪张图」**的答复 —— 先 "
                "`check_build_target()`（只读地问）→ **停下等用户打字** → 带他的原话调 "
                "`check_build_target(decision=…, user_quote=…)` 把答复记下来。")
        if traces:
            dry_warns.append(
                (f"⚠ **真跑会被拒收**：有 {len(traces)} 处人工痕迹会被这次操作删掉，而你没传 "
                 "`accept_user_edits=true`（默认就是保护它们）—— 演练里一个 Actor 都没动。"
                 if not accept_user_edits else
                 f"⚠ 你传了 `accept_user_edits=true`：真跑会把这 {len(traces)} 处人工痕迹"
                 "**删掉重摆**（演练里没动）。"))
        return BuildReport(
            stage=f"阶段三 · 批量落关卡（演练 · {mode}）",
            level=level, dry_run=True, refused=False,
            reason="dry_run：只校验 + 算差异，**没动手**",
            plan_hash=gate["plan_hash"], planned=len(rows),
            mode=mode, ledger_path=str(BUILD_STATE_PATH), ledger_written=False,
            diff=diff_dry,
            removed=0, placed=0, verified=0, groups={}, rows=[],
            official_calls=calls,
            next_step=(f"演练：这次会删 {len(remove_refs)} 个、摆 {len(targets)} 个"
                       f"（指令表一共 {len(rows)} 行）。要真做就去掉 `dry_run` 重调 —— "
                       "那一次**只动上面『要删 / 要摆』里列出的行**，其余行一个 Actor 都不碰。"),
            warnings=warns + dry_warns,
        )

    removed = 0
    for ref in remove_refs:
        calls += 1
        try:
            await call_official(ctx, "remove_from_scene", {"actor": {"refPath": ref}}, toolset=TS_SCENE)
            removed += 1
        except ToolError as exc:
            warns.append(f"清旧 Actor 失败：{ref}（{exc}）")

    # ---------- ② 按表落 ----------
    results: list[BuildRowResult] = []
    for r in targets:
        xform = {
            "location": {"x": r["loc_cm"][0], "y": r["loc_cm"][1], "z": r["loc_cm"][2]},
            "rotation": dict(r["rot"]),
            "scale": {"x": r["scale"][0], "y": r["scale"][1], "z": r["scale"][2]},
        }
        actor, err = "", ""
        try:
            if r["kind"] == "asset":
                calls += 1
                got = await call_official(
                    ctx, "add_to_scene_from_asset",
                    {"asset_path": r["asset_path"], "name": r["name"], "xform": xform},
                    toolset=TS_SCENE)
            else:
                calls += 1
                got = await call_official(
                    ctx, "add_to_scene_from_class",
                    {"actor_type": {"refPath": ACTOR_CLASS_PATH}, "name": r["name"], "xform": xform},
                    toolset=TS_SCENE)
                spawned = _ref_path(got)
                if not spawned:
                    raise ToolError("官方没返回 Actor 引用（spawn 失败）")
                dim = r["size_cm"]
                calls += 1
                await call_official(
                    ctx, "add_cube",
                    {"actor": {"refPath": spawned}, "name": "cube",
                     "dimensions": {"x": dim[0], "y": dim[1], "z": dim[2]}},
                    toolset=TS_PRIM)
                got = {"refPath": spawned}
            actor = _ref_path(got)
            if not actor:
                raise ToolError("官方没返回 Actor 引用")
            calls += 1
            await call_official(
                ctx, "set_actor_folder",
                {"actor": {"refPath": actor}, "folder_path": r["folder"]},
                toolset=TS_SCENE)
        except ToolError as exc:
            err = str(exc)
        except Exception as exc:                       # noqa: BLE001 —— 一行失败别把整批带崩
            err = f"{type(exc).__name__}: {exc}"
        results.append(BuildRowResult(
            index=r["index"], label=r["label"], kind=r["kind"],
            actor=actor, loc_cm=list(r["loc_cm"]), scale=list(r["scale"]),
            yaw=r["rot"]["yaw"], ok=(err == ""), error=err,
        ))

    # ---------- ③ 读回对账 ----------
    mismatches: list[str] = []
    verified = 0
    verified_uids: set[str] = set()      # **真的读回来过**的行（台账的 readback 标记只认它）
    if verify:
        for res, r in zip(results, targets):
            if not res.actor:
                continue
            calls += 1
            try:
                got = await call_official(
                    ctx, "get_actor_transform", {"actor": {"refPath": res.actor}}, toolset=TS_ACTOR)
            except ToolError as exc:
                mismatches.append(f"#{r['index']} {r['label']}：读回失败（{exc}）")
                continue
            got = got if isinstance(got, dict) else {}
            loc = got.get("location") or {}
            rot = got.get("rotation") or {}
            scl = got.get("scale") or {}
            try:
                back = [num(float(loc.get("x", 0.0))), num(float(loc.get("y", 0.0))),
                        num(float(loc.get("z", 0.0)))]
                back_yaw = num(float(rot.get("yaw", 0.0)))
                back_scale = [num(float(scl.get("x", 0.0))), num(float(scl.get("y", 0.0))),
                              num(float(scl.get("z", 0.0)))]
            except (TypeError, ValueError):
                mismatches.append(f"#{r['index']} {r['label']}：读回的变换解析不了（{got!r}）")
                continue
            res.loc_cm, res.yaw, res.scale = back, back_yaw, back_scale
            verified_uids.add(r["uid"])
            bad: list[str] = []
            if any(abs(a - b) > 0.05 for a, b in zip(back, r["loc_cm"])):
                bad.append(f"位置 {back} != 指令 {r['loc_cm']}")
            if not _angle_close(back_yaw, r["rot"]["yaw"]):
                bad.append(f"yaw {back_yaw} != {r['rot']['yaw']}（按角度差比，差 "
                           f"{(back_yaw - r['rot']['yaw'] + 180.0) % 360.0 - 180.0:.3f}°）")
            if any(abs(a - b) > 1e-4 for a, b in zip(back_scale, r["scale"])):
                bad.append(f"缩放 {back_scale} != {r['scale']}")
            if r["kind"] == "whitebox":
                # ⚠ 白膜**尺寸**不在 Actor 变换里（它在组件的 `RelativeScale3D` 上）——
                #   必须单独读，否则"位置对了、尺寸不对"这种错永远报不出来
                #   （客户 agent 自评：「它只管按 plan 摆，不管摆的对不对」）。
                #   官方 `get_actor_bounds` 对这类 Actor 恒返回 ±128 的**假包围盒**（实测），不能用它。
                dim, cost = await _read_cube_size_cm(ctx, res.actor)
                calls += cost
                if dim is None:
                    warns.append(f"⚠ 「{r['label']}」的白膜尺寸**没读回来** —— 这一行的尺寸没复核。")
                elif r.get("size_cm") and [round(float(x), 2) for x in dim] != [
                        round(float(x), 2) for x in r["size_cm"]]:
                    bad.append(f"白膜尺寸 {dim} != 指令 {r['size_cm']}")
            if bad:
                mismatches.append(f"#{r['index']} {r['label']}：" + "；".join(bad))
            else:
                verified += 1

    placed = sum(1 for res in results if res.ok)
    groups: dict[str, int] = {}
    for res, r in zip(results, targets):
        if res.ok:
            groups[r["folder"]] = groups.get(r["folder"], 0) + 1

    after = 0
    try:
        found = await call_official(
            ctx, "get_actors_in_folder",
            {"folder_path": OUR_FOLDER_ROOT, "recursive": True}, toolset=TS_SCENE)
        calls += 1
        after = len(found or [])
    except ToolError as exc:
        warns.append(f"落完复核 `{OUR_FOLDER_ROOT}/` 数量失败（{exc}）")

    if after != len(rows):
        failed = [r["label"] for r, res in zip(targets, results) if not res.ok]
        warns.append(f"⚠ 落完 `{OUR_FOLDER_ROOT}/` 下是 {after} 个，指令表是 {len(rows)} 个 —— "
                     "差额要查（这次没落成的行：" + ("、".join(failed) if failed else "无") + "）。")
    if verify:
        warns.append("白膜**尺寸**已逐行按组件 `RelativeScale3D`（×100 = 厘米）复核 —— 官方 "
                     "`get_actor_bounds` 对这类 Actor 恒返回 ±128 的**假包围盒**（实测），不能用它；"
                     "对不上的已列进 `mismatches`。")
    else:
        warns.append("⚠ `verify=false`：**没读回对账** —— 位置 / 朝向 / 缩放 / 白膜尺寸都没核实，"
                     "台账里 `readback=false`（记的是**指令值**，不是实测值）。")
    warns.append("**全程未存盘** —— 关卡里有没有变脏，请你在 UE 里看标题栏的未保存标记。")

    # ---------- ④ 写台账（下次增量全靠它；**这是我们自己的 JSON，不是 UE 存盘**）----------
    res_by_uid = {r["uid"]: res for r, res in zip(targets, results)}
    new_ledger_rows: list[dict] = []
    for r in rows:
        res = res_by_uid.get(r["uid"])
        if res is not None:
            # 这一行这次动过：记它落成的 Actor。
            # ⚠ `readback` 只认**真的读回来过**的行（`verified_uids`）——
            #   传 `verify=false` 时 `res.loc_cm` 里装的是**指令值**，不是实测值，
            #   那时只能记 `readback=false`（硬规则 6：预估值不许伪装成实测值）。
            ok_read = bool(res.actor) and r["uid"] in verified_uids
            new_ledger_rows.append(_ledger_row(
                r, res.actor,
                res.loc_cm if ok_read else None, res.yaw if ok_read else None,
                res.scale if ok_read else None, readback=ok_read))
            continue
        if r["uid"] in reclaim_actor:
            old = ledger_by_uid.get(r["uid"]) or {}
            new_ledger_rows.append(_ledger_row(
                r, reclaim_actor[r["uid"]], old.get("loc_cm"), old.get("yaw"),
                old.get("scale"), readback=bool(old.get("readback"))))
            continue
        old = ledger_by_uid.get(r["uid"])
        # 没动过的行：台账里原来那条**原样保留**（连 Actor 引用一起）—— 这就是"没碰它"的凭据
        new_ledger_rows.append(old if old else _ledger_row(r, ""))
    ledger_path = _save_build_state(level, gate["plan_hash"], mode, new_ledger_rows)

    if mode == "incremental":
        diff_summary = {
            "要删": [old.get("label") for old in gone]
                    + [r["label"] for r, _o, _w in changed],
            "要摆": [r["label"] for r in targets],
            "没动": len(same),
            "认领回来的": [orders[u]["label"] for u in reclaim_actor],
            "台账说在、关卡里却没了": [r["label"] for r, _ in drifted],
            "改动明细": {r["label"]: w for r, _o, w in changed},
            "人工改过（现状与台账不符）": {m["label"]: m["why"] for m in manual},
        }
        warns.append(f"增量：没动的 {len(same)} 行**一个 Actor 都没碰**（台账里那些行原样保留）。")
        warns.append(f"本次模式：**增量**（{mode_why or 'mode=incremental'}）—— 只动了 "
                     f"{len(targets)} 行、官方调用 {calls} 次。**下次改几行也不用传参数**（默认就是这条）。")
    else:
        diff_summary = {
            "全量重摆": True, "要删": len(remove_refs), "要摆": len(targets), "没动": 0,
            "人工改过（现状与台账不符）": {m["label"]: m["why"] for m in manual},
            "台账解释不了的活 Actor": unknown_refs,
        }
        warns.append(
            f"⚠ 本次模式：**全量重摆**（{mode_why or 'mode=full'}）—— 删了 {removed} 个、摆了 {placed} 个、"
            f"官方调用 {calls} 次。**下次只改几行时别传 `mode`**：默认 `auto` 只会动变动的那几个。")
    if manual:
        # 客户原话：「它不会告诉我『用户手动改了地皮你别删』」—— 这一条就是那句"告诉"。
        warns.append(
            (f"⚠ 有 {len(manual)} 行**人工改过**（现状与台账不符），本次按 `accept_user_edits=true` "
             "**按 plan 覆盖**（已删掉重摆）："
             if accept_user_edits else
             f"⚠ 有 {len(manual)} 行**人工改过**（现状与台账不符）—— 本次**没动它们**（默认保护）：")
            + "；".join(f"「{m['label']}」{'；'.join(m['why'])}" for m in manual[:6])
            + ("…" if len(manual) > 6 else "")
            + ("" if accept_user_edits else
               "。要让 plan 覆盖它们：回阶段二把改动写进 plan（`generate_plan(patch=[...])`）"
               "→ 重画图 → 用户确认 → 增量落；或跟用户确认过之后传 `accept_user_edits=true`。"))
    if unknown_refs and mode == "full":
        warns.append(f"⚠ 全量里**顺手清掉了 {len(unknown_refs)} 个台账解释不了的 Actor**（你传了 "
                     "`accept_user_edits=true`）：" + "、".join(unknown_refs[:8])
                     + ("…" if len(unknown_refs) > 8 else ""))
    warns.append(f"台账已更新（`{ledger_path}`）—— 我们自己的 JSON，**不是 UE 存盘**。")

    return BuildReport(
        stage=f"阶段三 · 批量落关卡（{mode}）",
        level=level, dry_run=False, refused=False, reason="",
        plan_hash=gate["plan_hash"], planned=len(rows), removed=removed, placed=placed,
        verified=verified, mismatches=mismatches, groups=groups, rows=results,
        mode=mode, ledger_path=ledger_path, ledger_written=True, diff=diff_summary,
        official_calls=calls,
        next_step=(
            (f"增量完成：这次动了 {len(targets)} 行（落成 {placed}、删掉 {removed}），"
             f"**没动的 {len(same)} 行原样留着**。① 在 UE 里看这几处对不对"
             "（`rows` 里 `ok=false` 的就是没落成的）；② `mismatches` 非空就逐条查；"
             "③ 还要改就回阶段二：改 plan → **重画图（写新指纹 + 本轮变更集那几行）** → "
             "让用户看图确认 → "
             "`generate_build_orders()` → 再 `execute_build(mode=\"incremental\")`；"
             "④ 存不存盘由你在 UE 里决定（阶段三自己绝不存）。")
            if mode == "incremental" else
            (f"① 在 UE 里看：outliner 的 `{OUR_FOLDER_ROOT}/` 下应当有 {len(rows)} 个 Actor"
             f"（分 {len(groups)} 组）—— 位置/朝向对不对以**你的眼睛**为准；"
             "② `mismatches` 非空就逐条查；③ ⚠ 房子『正门相对还是背对背』取决于"
             "**资产自身在 rot 0 时朝哪边**，这条**仍未实测**（docs/阶段三 §11.2）—— "
             "用视口截图看一眼再定要不要给房子 ±180°；"
             "④ 确认无误后**由你在 UE 里决定要不要存盘**（阶段三自己绝不存）。")
        ),
        warnings=warns,
    )


# --- [完工-06] 工具 2：确认元素清单 ---
# 实测 2026-09-23T10:26:36Z：catalog/elements.json（14 个元素）由它落盘。

@mcp.tool()
async def confirm_elements(
    elements: Annotated[
        list[ElementItem], Field(description="从参考图提取的、**已经过用户确认**的元素清单")
    ],
    source_image: Annotated[str, Field(description="参考图路径（留档用）")] = "",
) -> ElementList:
    """记录**用户已确认**的元素清单 —— 阶段一的第一步。

    为什么要有这一步：用户的要求是"根据上传图片提取所需资产**让用户确认**"。
    把确认结果落盘有两个好处：
      ① 后面 plan_assets() 不用再传一遍关键词，直接读这份清单
      ② 有据可查：到底确认过哪些元素，不会中途被悄悄改掉

    ⚠ 调用前必须先让用户确认过这张表。**没确认就别调**。
    ⚠ **阶段一的流程（2026-09-24 整改）**：拿用户上传的图 → 提取画面信息 → **填进表里对应的大类**
      → 有数量的填**预估数量** → 表里那两个**场景项**（地图大小 / 地图对应时间）也要填
      → 交用户确认 → **然后才**去找资产。
      ① 表 = `config/asset_categories.json`：11 个资产大类（Fab 的 3D 分类树，用户截图原文）
         + 2 个**场景项**（`kind=scene`）；
      ② 每个元素填一个 `category` key —— 这一步就是"根据参考图把表填好"；
         表里没有的 key 会被**拒收**（拒收信息里列出可用的 key），不许自己造大类；
         没把握就填 `uncategorized` 并在 note 里写明原因；
      ③ **有数量的要填 `count`**，并用 `count_source` 写明是估的还是数的；
         材质 / 面这类确实没有『个数』的可以留空，但要在 note 里写明为什么；
      ④ **两个场景项必须填**：地图大小 → `size_m: [X, Y]`（米，预估）；
         地图对应时间 → `time_of_day`（如 sunset 黄昏 / blue_hour 蓝调）—— 没填会被拒收；
      ⑤ ⚠ 场景项**不是资产**：`plan_assets` 不会去搜它们，`confirm_assets` 也不许写进资产清单。
      ⚠ 大类**不是官方的搜索参数**（find_assets 只按资产名/文件夹名/类路径过滤）——
        它的用处是分组确认、逐类核对有没有漏，**不许**假装它能过滤搜索结果。
    ⚠ 元素粒度由**资产库**定，不由画面部件数定：屋顶 / 石材基座 / 路缘石这类通常
      **并进主体资产**，拆出来只会给 plan_assets 喂搜不到的词、制造假缺口。
      同一 element 可以**多行**（同关键词在多处出现）；覆盖判定按关键词集合算，不按条数算。
    ⚠ 图上**看不清**的：留在清单 + 写「⚠ 待核实」+ 给备用关键词；**不许凭空添一条，也不许删**。
      清单是给用户**逐条确认**的 —— 塞进猜测会污染他的确认，删掉该留的会丢信息。
    """
    table = load_categories()
    warnings: list[str] = []

    # 表里没有的 key 当场拒收 —— 不然"先有表再填表"就是句空话
    known = set(table["by_key"])
    bad = sorted({
        str(e.category).strip() for e in elements
        if str(e.category).strip() and str(e.category).strip() not in known
    })
    if bad:
        raise ToolError(
            f"大类 key 不在表里：{bad}。可用的 key：{sorted(known)}"
            f"（表在 {CATEGORY_PATH}）。实在没把握就填 {table['fallback_key']}，"
            "并在 note 里写明为什么 —— **不许自己造一个大类**。"
        )

    # 空大类 → 未分类：照实登记 + 报警，不替它编一个
    filled = [
        e.model_copy(update={"category": str(e.category).strip() or table["fallback_key"]})
        for e in elements
    ]
    n_uncat = sum(1 for e in filled if e.category == table["fallback_key"])
    if n_uncat:
        warnings.append(
            f"有 {n_uncat} 个元素**没填大类**，已照实记成「{table['fallback_cn']}」—— "
            "这份表没填全，请用户确认时重点看这几个。"
        )
    if table["defined"] == 0:
        warnings.append(
            f"读不到大类表（{CATEGORY_PATH}）—— 全部只能记成「{table['fallback_cn']}」。"
            "先确认那个文件在不在，别就这么往下走。"
        )

    # 场景项校验（表里 kind=scene 的行）：必须在表里、且值必须填。
    # 值填在哪个字段由表决定（value_field），代码不写死 key —— 以后往表里加第三、
    # 第四个场景项，只要在表里写清 value_field 就行。
    _present_scene = {e.category for e in filled if is_scene_category(e.category, table)}
    _absent_scene = [table["by_key"][k] for k in table["scene_keys"]
                     if k not in _present_scene]
    if _absent_scene:
        raise ToolError(
            "表里**少了场景项**：" + "、".join(_absent_scene) + "。"
            "它们和资产大类一样是这张表的一部分（2026-09-24 用户要求新增）—— "
            "地图大小填 `size_m`（米，预估）、地图对应时间填 `time_of_day`（如 sunset / blue_hour）；"
            "少了它们就不是一张填好的表。"
        )
    _missing_scene: list[str] = []
    for e in filled:
        if not is_scene_category(e.category, table):
            continue
        _vf = table["value_field"].get(e.category, "")
        _cn = table["by_key"].get(e.category, e.category)
        if _vf == "size_m":
            if (not e.size_m or len(e.size_m) < 2
                    or min(float(e.size_m[0]), float(e.size_m[1])) <= 0):
                _missing_scene.append(f"{_cn}（要填 size_m: [X, Y]，单位米）")
        elif _vf == "time_of_day":
            if not str(e.time_of_day).strip():
                _missing_scene.append(f"{_cn}（要填 time_of_day，如 sunset / blue_hour）")
    if _missing_scene:
        raise ToolError(
            "场景项没填值：" + "；".join(_missing_scene) + "。"
            "这两项是 2026-09-24 用户要求加进表里的（地图大小 / 地图对应时间）—— "
            "它们**不是资产**，但**必须填**：后面的世界范围和灯光都靠它们，不填就没有依据。"
        )

    scene, scene_size, scene_time = scene_from_rows(
        [e.model_dump() for e in filled], table
    )

    # 缺数量的（2026-09-24 用户要求：有数量的就要填预估数量）
    no_count = [
        e.element for e in filled
        if not is_scene_category(e.category, table) and not (e.count and e.count >= 1)
    ]
    if no_count:
        warnings.append(
            f"有 {len(no_count)} 个元素**没填预估数量**：{'、'.join(no_count)}。"
            "用户 2026-09-24 要求『有数量的还要填预估数量』—— "
            "材质 / 面这类确实没有个数的，请在该行 note 里写明；其余的请补 count。"
        )

    result = ElementList(
        confirmed_at=datetime.now(timezone.utc).isoformat(),
        source_image=source_image,
        total=len(filled),
        elements=filled,
        groups=group_elements_by_category([e.model_dump() for e in filled], table),
        categories_defined=table["defined"],
        scene=scene,
        scene_map_size_m=scene_size,
        scene_time_of_day=scene_time,
        no_count=no_count,
        next_step=(
            "元素清单已记录（按大类填好了，含地图大小 / 地图对应时间两个场景项）。"
            "下一步调 plan_assets()（不传参数即可）去找资产 —— "
            "⚠ **场景项不参与找资产**（它们不是资产），会在报告的 scene 里原样带出。"
            "找到就是找到，没找到就直接告诉用户缺什么，"
            "并请用户给出【路径 + 名字】—— 禁止猜疑似的。"
        ),
        warnings=warnings,
    )
    save_json(ELEMENTS_PATH, result.model_dump())
    return result


# --- [完工-07] 工具 3：找资产（阶段一主工具）---
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   本轮白膜整改新增的两条断言都绿 ——「找不到的元素带出 placeholder_hint（要求登记白膜占位）」
#   与「找不到元素时不再说『跳过这个元素』」。
# 2026-09-24 改过本块逻辑（阶段一白膜整改）：
#   ① `ElementPlan` 新增 `placeholder_hint`（缺失 / 只有材质实例顶着的元素，
#      要带上"必须登记成白膜占位"的提示 —— confirm_assets 会拒收没登记的白膜）；
#   ② 新增 warning：点出哪几个元素只命中非网格资产；
#   ③ 提问文案不再说「跳过这个元素」（用户口径是登记成白膜，不是跳过）。
# 实测 2026-09-23 12:07（不传参读元素清单）、12:12（keywords=["grass"]）两次调用。

@mcp.tool()
async def plan_assets(
    ctx: Context[AppContext],
    keywords: Annotated[
        list[str] | None,
        Field(description="要查的元素名。不传 = 用 confirm_elements 记录的那份清单"),
    ] = None,
    max_per_element: Annotated[
        int, Field(ge=1, le=20, description="每个元素最多列几个候选（默认 4）")
    ] = 4,
) -> PlanReport:
    """按名字找资产 → 报告**找到 / 没找到**，并对每个元素给一句要问用户的话。

    查两条路（缺一不可）：
      ① **按资产名** —— 官方 find_assets 的常规能力
      ② **按文件夹名** —— ⚠ 官方只匹配资产名、**不匹配文件夹名**。所以哈希名资产
         （MI_sjfnch0a）靠①永远搜不到，但它所在文件夹叫 Fine_American_Road。
    ②很便宜：每类资产只要 1 次枚举调用，之后所有关键词都在本地匹配。

    ⚠ **本工具不猜、不找"疑似"资产**（用户明确要求的硬规则）。
      名字对得上就是找到；对不上就是没找到。
      **命中多个时，把命中的逐个列出来（最多 max_per_element 个）交给用户确认用哪一个**；
      用户也可以明确让模型挑最匹配的 —— 但**绝不拿名字对不上的资产顶替**。
      为什么：我给"名字是否规范"做过两版判据，两版都在实测里误报
      （v1 把 M_Weapon / SM_Pistol / GlassJar 判错，还建议把 SM_Pistol 改名成 SM_Bush；
        v2 把 QuarterCylinder / FlashlightBeam 判错）。
      根因是**没有词典时，随机哈希和英文单词拼接在字符层面无法区分**。猜不准就不猜。

    没找到时：直接告知缺什么，并请用户把"存在但没被找到"的资产的【路径 + 名字】给你；
    用户确认「确实没有」的，**登记成白膜占位**（不是"跳过" —— 跳过会让这个元素静默消失）。

    ⚠ **每个元素都带 `placeholder_hint`**（2026-09-24 用户要求）：非空 = 这个元素**没有可用资产**
      （没找到，或命中的全是材质实例这种摆不出实体的）。这类**必须先在 confirm_assets 里
      登记成白膜占位**（`is_placeholder=true` + `placeholder_shape` + **预估** `size_cm`）
      再让用户确认清单 —— **不许当资产行交出去**（路径验不过会被当场拒收）。
      命中的只有材质、但用户说"就用它当表面"的，那是用户拍板，占位提示以用户答复为准。

    ⚠ 本工具**不改动任何东西**，`needs_user_confirmation` 恒为 true。
    """
    calls = 0
    warnings: list[str] = []

    stored = load_json(ELEMENTS_PATH)
    _scene_rows: list[dict] = []          # 场景项（地图大小 / 地图对应时间）—— 不是资产
    if keywords:
        elements_kw = [k for k in keywords if k and k.strip()]
        source = "本次传入的关键词"
    elif stored:
        _tbl = load_categories()
        elements_kw = []
        for _e in (stored.get("elements") or []):
            if not (isinstance(_e, dict) and _e.get("element")):
                continue
            # 场景项不参与找资产：去搜「地图大小」这种词没有意义
            if is_scene_category(str(_e.get("category") or ""), _tbl):
                _scene_rows.append(_e)
            else:
                elements_kw.append(_e["element"])
        source = f"用户确认过的元素清单（{stored.get('confirmed_at', '?')}）"
    else:
        raise ToolError(
            "没有元素清单：既没传 keywords，也没有 confirm_elements 记录过。"
            "请先读参考图列出元素、让用户确认，然后调 confirm_elements。"
        )
    if not elements_kw and not _scene_rows:
        raise ToolError("元素清单是空的，没什么可查。")

    # 每类资产枚举一次，之后都在本地匹配（枚举逻辑收敛在 library_inventory() 一处）
    inventory, enum_calls = await library_inventory(ctx)
    calls += enum_calls

    if sum(len(v) for v in inventory.values()) == 0:
        warnings.append(
            "资产库枚举返回 0 条 —— 可能官方 find_assets 的用法变了，"
            "先用 official_status 确认链路再重试。"
        )

    elements: list[ElementPlan] = []
    found_count = 0

    for kw in elements_kw:
        kw_l = kw.lower().strip()
        found: list[FoundAsset] = []

        for type_name, paths in inventory.items():
            for p in paths:
                name = p.rsplit("/", 1)[-1]
                matched_by, seg = "", ""
                if token_match(kw_l, name):
                    matched_by = "资产名"
                else:
                    for part in p.split("/"):
                        if part and token_match(kw_l, part):
                            matched_by, seg = "文件夹名", part
                            break
                if matched_by:
                    found.append(
                        FoundAsset(
                            name=name, path=p, asset_type=type_name,
                            matched_by=matched_by, matched_segment=seg,
                        )
                    )

        for f in [x for x in found if x.asset_type in SIZE_QUERY_TYPES][:max_per_element]:
            try:
                box = await call_official(
                    ctx, "get_bounds", {"mesh": {"refPath": to_object_path(f.path)}},
                    toolset="editor_toolset.toolsets.static_mesh.StaticMeshTools",
                )
                calls += 1
                f.size_cm = size_from_box(box)
            except ToolError as exc:
                calls += 1
                warnings.append(f"查 {f.name} 尺寸失败：{exc}")

        found.sort(key=lambda a: (a.matched_by != "资产名", len(a.path)))

        # "只有材质实例顶着" = 这个元素摆不出实体（材质没有包围盒、量不出尺寸）。
        # 不能自作主张替用户判定：材质是真的不够用、还是本来就当表面用，得用户拍板 ——
        # 这里只把事实摆出来 + 给出白膜该怎么办。
        mesh_hits = [f for f in found if f.asset_type in SIZE_QUERY_TYPES]
        only_material = bool(found) and not mesh_hits
        hint = ""
        if not found:
            hint = (
                "找不到资产 → **登记成白膜占位**（先给预估尺寸，再让用户确认清单）："
                "`is_placeholder=true`、`asset_path` 留空、"
                "`placeholder_shape` 按它是什么填 cube（体）/ plane（面）、"
                f"`size_cm` 给 [X, Y, (Z)]、`size_source` 写 {SIZE_SOURCE_ESTIMATED}。"
            )
        elif only_material:
            types = "、".join(sorted({f.asset_type for f in found}))
            hint = (
                f"{MATERIAL_ONLY_MARK}（{types}）—— **材质没有包围盒、摆不出实体**，"
                "等于没资产。2026-09-24 用户要求：这类元素**先给预估尺寸、登记成白膜占位**"
                f"（`is_placeholder=true`、`placeholder_shape` 填 cube/plane、"
                f"`size_cm` 给预估、`size_source` 写 {SIZE_SOURCE_ESTIMATED}），"
                "**再让用户确认清单**。"
                "⚠ 但**要不要把它当资产用，由用户拍板** ——"
                "若用户确认「就用这个材质当表面」，那才是普通资产行；"
                "本工具不替你决定，也不许拿它顶替实体。"
            )

        if found:
            found_count += 1
            names = "、".join(f.name for f in found[:max_per_element])
            question = (
                f"「{kw}」找到 {len(found)} 个候选：{names}。"
                f"请确认用哪一个（或明确让我挑最匹配的）。"
            )
            if only_material:
                question += (
                    " ⚠ 这几个都是**非网格资产**（没有包围盒、摆不出实体）："
                    "请用户明确 —— 是就用它当**表面**，还是**登记成白膜占位**？"
                )
        else:
            # 不猜、不找疑似的 —— 直接说缺，请用户给路径
            question = (
                f"「{kw}」按名字没找到（资产名和文件夹名都试过了）。"
                f"**如果它其实存在、只是名字对不上，请把它的【路径 + 名字】告诉我，我来改名。**"
                f"如果确实没有，请告诉我：**登记成白膜占位**（先给预估尺寸），"
                f"而不是把它当资产行交出去。"
            )

        elements.append(
            ElementPlan(
                element=kw, status="found" if found else "missing",
                assets=found[:max_per_element],
                placeholder_hint=hint,
                question=question,
            )
        )

    missing = len(elements) - found_count

    # 白膜提醒（2026-09-24 用户要求：没有可用资产的元素，先给预估尺寸、登记白膜）
    # _none_found：按名字一个都没找到；_only_mat：只命中材质/材质实例（算 found，
    # 但摆不出实体）。两类原因不同、对策一样：登记成白膜占位，而不是"跳过"。
    _none_found = [p.element for p in elements if not p.assets and p.placeholder_hint]
    _only_mat = [p.element for p in elements if MATERIAL_ONLY_MARK in p.placeholder_hint]

    if _none_found or _only_mat:
        _parts: list[str] = []
        if _none_found:
            _parts.append(
                f"{len(_none_found)} 个**按名字一个都没找到**（{'、'.join(_none_found)}）"
            )
        if _only_mat:
            _parts.append(
                f"{len(_only_mat)} 个**只命中非网格资产**（材质/材质实例 —— "
                f"没有包围盒、摆不出实体：{'、'.join(_only_mat)}）"
            )
        warnings.append(
            "有 " + "；".join(_parts) + "。**禁止猜疑似的** —— 把事实如实告诉用户："
            "存在但名字对不上的，请用户给【路径 + 名字】；"
            "用户确认「确实没有」的，**登记成白膜占位**（`is_placeholder=true` + "
            "`placeholder_shape` + **预估** `size_cm`）再让用户确认清单 —— "
            "**不许当资产行交出去**（路径验不过会被 confirm_assets 当场拒收），"
            "也**不许「跳过」了事**（那会让这个元素在清单里静默消失）。"
            "详见各元素的 `placeholder_hint`。"
        )

    # 按大类分组（2026-09-24 用户要求：报告也按类给）
    # 元素 → 大类 来自 elements.json；本次显式传 keywords 时，清单里没记过的词落「未分类」。
    _cat_by_element = {
        str(e.get("element") or ""): str(e.get("category") or "")
        for e in ((stored or {}).get("elements") or []) if isinstance(e, dict)
    }
    _cat_table = load_categories()
    by_cat: dict[str, dict[str, list[str]]] = {}
    for p in elements:
        _cn = category_cn(_cat_by_element.get(p.element, ""), _cat_table)
        _bucket = by_cat.setdefault(_cn, {"found": [], "missing": []})
        _bucket["found" if p.status == "found" else "missing"].append(p.element)
    by_cat = {cn: by_cat[cn] for cn in order_category_names(set(by_cat), _cat_table)}

    scene_out, _scene_size, _scene_time = scene_from_rows(_scene_rows, _cat_table)
    if _scene_rows:
        warnings.append(
            f"清单里有 {len(_scene_rows)} 个**场景项**（" + "、".join(scene_out.keys())
            + "）—— 它们**不是资产**，本次没有去搜；值见返回里的 `scene`，"
            "后面的世界范围 / 灯光要用它们。"
        )

    return PlanReport(
        stage="阶段一 · 资产确认",
        needs_user_confirmation=True,
        source=source,
        total_elements=len(elements),
        found=found_count,
        missing=missing,
        elements=elements,
        by_category=by_cat,
        scene=scene_out,
        official_calls=calls,
        next_step=(
            "把每个元素的 question **原样逐条问用户**："
            "找到的问用哪个（**连预估数量一起报上去**，用户要按数量判断够不够）；"
            "**缺的请用户给出【路径 + 名字】**。"
            "⚠ 每个元素还带 `placeholder_hint`：**非空 = 它没有可用资产**"
            "（没找到，或命中的全是材质实例这种摆不出实体的），"
            "这类**必须登记成白膜占位**（`is_placeholder=true` + `placeholder_shape` + "
            "**预估** `size_cm`）再让用户确认清单 —— **不许当资产行交出去**"
            "（confirm_assets 会当场拒收一条验证不过的路径）。"
            "⚠ 用 `by_category` **逐类核对有没有漏**（哪个大类还缺哪些元素）——"
            "但大类**不是搜索参数**，缺了仍然是按名字找 + 请用户指路。"
            "⚠ `scene` 里那两个场景项**不是资产**，别去问用户『用哪个资产』；"
            "它们是地图大小 / 地图对应时间，后面摆场景时才用。"
            "拿到用户答复后：路径 → rename_assets 改名；"
            "用户说「确实没有」 → 按白膜登记；"
            "全部齐了 → confirm_assets 交付清单。"
        ),
        warnings=warnings,
    )


# --- [完工-10] 工具 4：改名（用户指路之后）----------------------------------------------
# 实测 2026-09-23 晚：check_tools 4 条全绿 —— 默认 dry_run / 一个都没真改 /
# 拦下带斜杠的非法名（本地就挡住，不发去 UE）/ 给出了改名前后路径。
# 它只测预览路径（confirm=False），绝不真改用户资产。

@mcp.tool()
async def rename_assets(
    ctx: Context[AppContext],
    items: Annotated[
        list[RenameItem], Field(description="要改名的资产（路径来自用户提供）")
    ],
    confirm: Annotated[
        bool, Field(description="false = 只预览改名前后路径（默认，安全）；true = 真的改")
    ] = False,
) -> RenameReport:
    """把用户指出的资产改成规范名 —— **默认只预览，不真改**。

    用在阶段一第 5 步：用户说了"存在但你没找到的那个资产在 XX 路径"，就用它改名，
    以后不会再有人认不出它。

    为什么必须两步（预览 → 确认）：
      - 改的是**用户工程里的资产**，`move` 会改变资产的包路径
      - UE 一般会自动更新引用，但那是"一般"，不是保证
      - 所以每次都先查 `get_referencers`（谁引用了它），把影响面摆给用户看

    走官方 `AssetTools.move(path, new_path)` —— 同目录内换个名字就是"重命名"。
    """
    report = RenameReport(
        dry_run=not confirm, requested=len(items), renamed=0, failed=0, items=[],
        note=(
            "改名前已查引用者。UE 通常会跟随更新引用，但**这里不做保证** —— "
            "若该资产被蓝图/关卡引用，改名后请重新打开确认一次。"
        ),
    )

    for item in items:
        old_path, new_name = item.path.strip(), item.new_name.strip()
        entry = RenameResult(old_path=old_path, new_path="", referencers=[], ok=False)

        # 本地合法性检查 —— 不合法就不必去打扰官方
        if "/" in new_name or not new_name:
            entry.error = f"new_name 只能是纯名字（不能有斜杠），收到 {new_name!r}"
            entry.new_path = "(未计算)"
            report.failed += 1
            report.items.append(entry)
            continue
        if old_path.rsplit("/", 1)[-1] == new_name:
            entry.error = "新名字和旧名字一样，没必要改"
            entry.new_path = old_path
            report.failed += 1
            report.items.append(entry)
            continue

        entry.new_path = f"{old_path.rsplit('/', 1)[0]}/{new_name}"

        # 两种路径形式都试：实测裸包路径会报 "Asset does not exist"
        refs, last_err = None, ""
        for candidate in (old_path, to_object_path(old_path)):
            try:
                refs = await call_official(
                    ctx, "get_referencers", {"asset_path": candidate}, toolset=TS_ASSET
                )
                break
            except ToolError as exc:
                last_err = str(exc)
        entry.referencers = (
            [r for r in (refs or []) if isinstance(r, str)]
            if refs is not None
            else [f"(查引用失败：{last_err})"]
        )

        if not confirm:
            entry.ok = True          # 预览：能改就算通过
            report.items.append(entry)
            continue

        try:
            await call_official(
                ctx, "move", {"path": old_path, "new_path": entry.new_path}, toolset=TS_ASSET
            )
            entry.ok = True
            report.renamed += 1
        except ToolError as exc:
            entry.error = f"改名失败：{exc}"
        report.items.append(entry)

    return report


# --- [完工-08] 工具 5：确认并交付资产清单（阶段一收尾）---
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   ① 纯逻辑那 11 条白膜校验断言全绿（带路径 / 没形状 / 形状写错 / 没尺寸 / cube 少一个数 /
#      来源写成实测 → 都拒收；plane 两个数、旧文案、空 size_source → 都算合格）；
#   ② 经 MCP 端到端两条拒收断言绿：「拒收路径验证不过的行（不再当 invalid_paths 交付）」
#      与「拒收没写 placeholder_shape 的白膜行」；
#      走通的那一批绿：1 个真资产 / 2 个白膜占位、`invalid_paths` 恒空、清单里点明了
#      "摆不出实体"、`note` 里点名了只拿材质顶着的元素、白膜行标成 ◻ 白膜且不带路径。
# 2026-09-24（二）再次整改（阶段一白膜契约收紧，逻辑改动不是文案）：
#   ① `placeholder_errors()` 四道校验（带路径 / 没形状 / 没尺寸 / 来源不是预估 → 拒收）；
#   ② 路径验证不通过不再记进 invalid_paths 交付，改为整表拒收 + 给出改法；
#   ③ 新增"只拿材质/材质实例顶着"的点名（只点名，不替用户改）；
#   ④ 拒收发生在写盘之前 —— catalog/ 不会被写到一半。
# 实测 2026-09-23 12:12（6/6 exists + 指纹签字）、12:24（4 个网格实测尺寸 + 重签）。
# 实测 2026-09-23 晚：复跑 check_tools —— 原先失败的 3 条全绿，
#   且末尾 [还原] 行列出了 asset_list.json / elements.json / library_snapshot.json，
#   证明函数体真跑到了写盘那一步。
# 2026-09-23 晚（二）：新增 unresolved_elements（未落位元素），尚无实测证据。

@mcp.tool()
async def confirm_assets(
    ctx: Context[AppContext],
    items: Annotated[
        list[AssetListItem],
        Field(description="用户确认过的「元素 → 资产」对照表（exists 字段由本工具回填）"),
    ],
) -> AssetListDelivery:
    """**阶段一收尾 + 交付**：验证资产是否真的存在 → 实测尺寸 → 落盘 → 签字 → 输出清单。

    做七件事：
      ① 逐个调官方 `exists()` **验证路径**（不是形式主义，见下）
      ② **实测尺寸**：网格调官方 `get_bounds`，把包围盒 X×Y×Z 与体积**回填进表**
         （调用方填的尺寸一律被实测值覆盖 —— 理由见 measure_asset 的说明）
      ③ 落盘到 `catalog/asset_list.json`（这是清单文件，不是 UE 资产，不违反"不许存盘"）
      ④ **给表签字**：记下当时的资产库指纹到 `catalog/library_snapshot.json`，
         之后 `get_asset_list()` 才判定得了这张表过没过期
      ⑤ 生成 `deliverable` —— 一段**给人看的清单正文**（带尺寸/体积两列），直接贴给用户确认
      ⑥ 列出**未落位元素**（元素清单里有、本表里没有对应资产）到 `unresolved_elements` ——
         免得它静默消失：读表的人必须一眼看出"这份清单不完整"，而不是以为一共就这么多
      ⑦ **白膜占位**：下面这两类元素**先给预估尺寸、登记成白膜**，再让用户确认清单（见下）

    ⚠ **第 ⑦ 步：什么元素要登记白膜占位**（2026-09-24 用户要求）
      ① 找不到资产的（`plan_assets` 报 missing）、或用户确认"这个没有"的元素；
      ② **现在只有材质实例顶着**的元素（如 road / grass）—— 材质没有包围盒、摆不出实体，
         等于没资产。
      两类都填：`is_placeholder=true`、`asset_path` 留空、
      `placeholder_shape` 填 `cube`（有体积的，如窗/车道）/ `plane`（覆盖面，如路面/草坪）、
      `size_cm` 给**预估尺寸**、`size_source` 写明 `预估（参考图目测，待核实）`。
      ⚠ 四样**缺一不可**，填错**当场拒收**（不是警告）：带路径的白膜（自相矛盾）、
      没写形状（阶段六没法实例化）、没给尺寸（等于没占位）、
      尺寸来源写成"实测"（预估值伪装成实测值 —— 硬规则 6）。

    ⚠ **路径验证不通过的行，本工具现在直接拒收**（2026-09-24 整改，理由如下）：
      以前它把这种行记进 `invalid_paths` 照常交付，于是"元素没有资产"这件事
      只在备注里出现，清单本身照样带着一条**解析不到的路径**往下走。
      按用户的要求（`docs/阶段一-资产确认.md` 第 9 步）：**没有资产 = 登记成白膜占位**。
      所以现在二选一 —— 要么给对路径（`exists()` 通过），要么登记成白膜；
      **拒收时 catalog/ 一个字节都不写**，不会把上一次交付物覆盖成半新半旧。

    ⚠ **白膜只是"清单登记"，不是"往关卡里摆东西"**：
      `docs/阶段一-资产确认.md` 硬规则 4 —— 用户确认资产列表前不许摆放任何东西；
      规划图闸门也一样。真正生成白膜是**阶段六**（官方 PrimitiveTools 往 Actor 上加 Cube/Plane
      图元就行，**不用新建任何 UE 资产、不用存盘**）。
    ⚠ **预估值不许伪装成实测值**：白膜行没有东西可测，它的 size_cm 就是你填的那个数；
      必须在 size_source 里写明是预估、待核实 —— 用户确认清单时要能一眼看出哪个是估的。
      `plane`（面）类要额外说明：它的覆盖面**阶段二会用参数几何重算**，这里的预估值只是占位。

    ⚠ 每行的 `element_key` 请填**元素关键词**（与 elements.json 里的元素名一致）：
      `get_asset_list()` 靠它算"还有哪些元素没落位"。不填就只能按标签首词推断，
      而那只是推断 —— 返回值里会明说，不会假装是事实。

    ⚠ 为什么必须逐个验证存在性（实测价值）：
      2026-09-23 实测：`/Game/Fab/Urban_Street_Pack` 整个文件夹在我工作期间消失了
      （材质实例总数 58 → 56，exists() = False），而我此前一直以为人行道材质还在用它的
      Material_002。有这一步就会立刻暴露。
      **"我以为它在"和"它真的在"是两回事。**

    ⚠ **只拿材质 / 材质实例顶着的行**：本工具**只点名、不替用户改**
      （`note` 里列出来）—— 到底"就用这个材质当表面"还是"登记成白膜"，得用户拍板；
      替用户决定就是猜（硬规则 1）。
    """
    results: list[AssetListItem] = []
    stored = load_json(ELEMENTS_PATH) or {}

    # 大类（2026-09-24 用户要求：资产清单也要分大类）
    # 调用方填了就用它；没填就从 elements.json 那张表里按关键词取；
    # 两边都没有 = 未分类。中文名一律查表回填 —— 表是唯一来源。
    _cat_table = load_categories()
    _cat_by_key: dict[str, str] = {}
    for _e in (stored.get("elements") or []):
        if isinstance(_e, dict):
            _k = str(_e.get("element") or "").strip().lower()
            if _k and str(_e.get("category") or "").strip():
                _cat_by_key.setdefault(_k, str(_e["category"]).strip())

    def _cat_of(it: AssetListItem) -> str:
        """这一行归哪个大类：调用方填的 → elements.json 里记的 → 空（记成未分类）。"""
        given = str(it.category).strip()
        if given:
            return given
        for probe in (str(it.element_key or "").strip().lower(),
                      str(it.element or "").strip().split(" ")[0].lower()):
            if probe and probe in _cat_by_key:
                return _cat_by_key[probe]
        return ""

    measured = 0        # 量到包围盒的网格数
    no_size = 0         # 本来就没有包围盒的（材质/材质实例等）
    size_failed = 0     # 想量却没量到的
    placeholders = 0    # 白膜占位几行（没有可用资产的元素）
    bad_rows: list[str] = []   # 不合格的行（白膜填错 / 路径验不过）—— 收齐再判，见循环里那段说明

    for item in items:
        # 场景项（地图大小 / 地图对应时间）不是资产 —— 不许写进资产清单
        if is_scene_category(_cat_of(item), _cat_table):
            raise ToolError(
                f"{item.element!r} 是**场景项**（{category_cn(_cat_of(item), _cat_table)}），"
                "不是资产 —— 资产清单里不该有它。它的值已经记在 catalog/elements.json 里了。"
            )

        # 白膜占位行：没有资产可验、没有东西可量 —— 校验填得合不合规矩。
        # 2026-09-24 用户要求：找不到资产的、用户确认没有的、只有材质实例顶着的元素，
        # 都要先给预估尺寸、登记成白膜，再让用户确认清单。只是清单登记，不往关卡里摆东西。
        # 校验不过的收进 bad_rows、等整表走完再一次性拒收（别探到第一个坏行就抛）。
        if item.is_placeholder:
            bad_rows += placeholder_errors(item)
            vol = None
            if item.size_cm and len(item.size_cm) >= 3:
                vol = num(float(item.size_cm[0]) * float(item.size_cm[1])
                          * float(item.size_cm[2]))
            placeholders += 1
            _cat = _cat_of(item)
            results.append(item.model_copy(update={
                "exists": False,          # 没有路径可验 —— 不许写成"存在"
                "bbox_volume_cm3": vol,
                "asset_type": item.asset_type or "whitebox",
                "size_source": item.size_source or SIZE_SOURCE_ESTIMATED,
                "category": _cat,
                "category_cn": category_cn(_cat, _cat_table),
            }))
            continue

        ok = False
        err = ""
        try:
            exists = await call_official(
                ctx, "exists", {"path": item.asset_path}, toolset=TS_ASSET
            )
            ok = exists is True or (isinstance(exists, str) and exists.lower() == "true")
        except ToolError as exc:
            err = str(exc)
        if not ok:
            # 2026-09-24（二）：不再记进 invalid_paths 一路交付出去。
            # 路径验不过的元素 = 没有可用资产 = 该登记成白膜；
            # 先收着，等整表走完一起拒收（带上"怎么改"的原文）。
            bad_rows.append(
                f"{item.element!r}：路径验证不通过"
                + (f"（{err}）" if err else "（官方 exists() 返回否）")
                + f" —— `asset_path` = {item.asset_path!r}。"
                "请二选一：① 用户给出正确路径 → 改成那一行重交；"
                "② 用户确认「确实没有」→ 改成**白膜占位行**"
                f"（`is_placeholder=true`、`asset_path` 留空、`placeholder_shape` 填 "
                f"{' / '.join(PLACEHOLDER_SHAPES)}、`size_cm` 给**预估**尺寸、"
                f"`size_source` 写 {SIZE_SOURCE_ESTIMATED}）。"
                "**不许当资产行交出去** —— 否则下一阶段会挂上一个解析不到的材质/网格。"
            )

        size: list[float] | None = None
        volume: float | None = None
        size_src = "路径不存在，没量"
        if ok:
            size, volume, size_src = await measure_asset(
                ctx, item.asset_path, item.asset_type
            )
        if size:
            measured += 1
        elif "没有包围盒" in size_src:
            no_size += 1
        else:
            size_failed += 1

        _cat = _cat_of(item)
        results.append(item.model_copy(update={
            "exists": ok,
            "size_cm": size,
            "bbox_volume_cm3": volume,
            "size_source": size_src,
            "category": _cat,
            "category_cn": category_cn(_cat, _cat_table),
        }))

    # 只拿材质 / 材质实例顶着的行：摆不出实体，要点名（2026-09-24 用户要求）。
    # 只点名、不替用户改 —— 当表面用还是登记白膜，得用户拍板（硬规则 1「不猜」）。
    mat_only = [
        r.element for r in results
        if not r.is_placeholder
        and str(r.asset_type or "").strip().lower() in ("material", "material_instance")
    ]

    # 不合格的行：拒收，一个都不许落盘（白膜填错 / 路径验不过）。
    # 一次列全再抛（一个一个抛，用户得改一轮试一轮）；且在写盘之前抛 ——
    # 写盘在函数末尾，在这里抛 = catalog/ 一个字节都没动。
    if bad_rows:
        raise ToolError(
            f"资产清单**拒收**：有 {len(bad_rows)} 行不合格 —— 先改掉，清单没落盘。\n"
            "  - " + "\n  - ".join(bad_rows)
        )

    # 未落位元素：元素清单里有、交付表里没有的 —— 不许静默消失。
    # note 原样带出元素清单里那一句，不推断原因
    # （例：sky 写着"按【光照环境】处理…不按资产找（用户已拍板）"）。
    delivered_keys, _cov_mode = element_keys_from_items([r.model_dump() for r in results])
    _notes_by_key: dict[str, list[str]] = {}
    for _e in (stored.get("elements") or []):
        if not isinstance(_e, dict):
            continue
        _k = str(_e.get("element") or "").strip().lower()
        if _k:
            _notes_by_key.setdefault(_k, []).append(str(_e.get("note") or ""))
    unresolved = [
        UnresolvedElement(
            element_key=_k,
            occurrences=len(_ns),
            note=" / ".join(n for n in _ns if n),
        )
        for _k, _ns in sorted(_notes_by_key.items())
        if _k not in delivered_keys
    ]

    lines = ["资产清单（阶段一交付）", ""]
    lines.append(f"参考图：{stored.get('source_image') or '(未记录)'}")
    lines.append(
        f"元素数：{len(results)}    路径验证通过：{sum(1 for r in results if r.exists)}"
        + (f"    白膜占位：{placeholders}（尺寸为**预估**，见该行 size_source）"
           if placeholders else "")
    )
    lines.append(
        f"尺寸实测：{measured} 个网格量到包围盒，{no_size} 个非网格本来就没有，"
        f"{size_failed} 个没量到（原因见该行下方）"
    )
    lines.append("")
    _mat_set = set(mat_only)          # 只拿材质/材质实例顶着的行（下面打印时点名）
    def _emit_rows(rows: list[AssetListItem]) -> None:
        lines.append(f"{'元素':<16} {'状态':<6} {'尺寸 X×Y×Z (cm)':<28} {'包围盒体积 (cm³)':>18}  资产路径")
        lines.append("-" * 122)
        for r in rows:
            size_txt = "×".join(f"{v:.1f}" for v in r.size_cm) if r.size_cm else "—"
            vol_txt = f"{r.bbox_volume_cm3:,.0f}" if r.bbox_volume_cm3 is not None else "—"
            status = ("◻ 白膜" if r.is_placeholder else ("✓ 存在" if r.exists else "✗ 不存在"))
            where = r.asset_path or f"(白膜占位 {r.placeholder_shape or 'cube'}，无资产)"
            if r.element in _mat_set:
                where += "（⚠ 只有材质实例，摆不出实体 —— 见下方点名）"
            lines.append(
                f"{r.element:<16} {status:<6} {size_txt:<28} {vol_txt:>18}  {where}"
            )
            if r.note:
                lines.append(f"{'':<16} {'':<6} └ {r.note}")
            if r.size_cm is None:
                lines.append(f"{'':<16} {'':<6} └ 无尺寸原因：{r.size_source or '(未记录)'}")

    # 按大类分组打印（2026-09-24 用户要求：资产清单要分大类，能逐类看）
    _grouped: dict[str, list[AssetListItem]] = {}
    for r in results:
        _grouped.setdefault(r.category_cn or "未分类", []).append(r)
    for _cn in order_category_names(set(_grouped), _cat_table):
        lines.append("")
        lines.append(f"## {_cn}（{len(_grouped[_cn])} 项）")
        _emit_rows(_grouped[_cn])
    if _grouped.get("未分类"):
        lines.append("")
        lines.append(
            "⚠ 上面「未分类」那些：`elements.json` 里也没给它们分类 —— "
            "先用 confirm_elements 把大类表填全，再交付更清楚。"
        )
    _scene_recap, _, _ = scene_from_rows(stored.get("elements", []) or [], _cat_table)
    if _scene_recap:
        lines.append("")
        lines.append(
            "场景项（**不是资产**，已记在 catalog/elements.json）："
            + "；".join(f"{k}：{v}" for k, v in _scene_recap.items())
        )
    lines.append("")
    lines.append(
        "⚠ 口径：尺寸/体积都是**官方 get_bounds 实测的包围盒**（体积 = X×Y×Z），"
        "**不是网格实际体积**；材质/材质实例没有包围盒，记 —。"
        "⚠ 标 `◻ 白膜` 的行**例外**：那是没有可用资产、用**预估尺寸**登记的白膜占位，"
        "尺寸不是实测 —— 请重点确认；`plane`（面）类的覆盖面阶段二会用参数几何重算。"
    )
    # ⚠ **「尺寸这一列怎么读」**（2026-09-26 加；客户反馈实测）：客户那头的 agent 看到
    #   「house1 实测包围盒只有 89×70×50 cm」，就去问用户「要不要换个房子模型 / 是不是被缩放过」——
    #   而答案本来就在工具链里：**阶段二的 `scale` 就是干这个的**（实测 house1 scale=16 → 14.25 m）。
    #   所以把这条"怎么读这一列"的规则钉在**表下面**（表是它必看的地方），不指望它记得文档。
    if measured:
        lines.append("")
        lines.append(
            "⚠ **尺寸这一列是「资产自身」的大小，不是「场景里该有多大」** —— "
            "两者差几倍、几十倍都是**正常**的（实测例：house1 89 cm、tree 16 m）。"
            "阶段二按参考图给 `scale` 换算：**占地（`footprint_m`）= 实测包围盒 × `scale`**"
            "（89 cm 的房子要摆成 12 m 宽 → `scale` ≈ 13.5）。"
            "**资产偏小 / 偏大是常态，用 `scale` 解决 —— 不要为它换资产，更不要拿这个去问用户。**"
        )
    if mat_only:
        lines.append("")
        lines.append(
            "⚠ 下面这些元素**只拿材质 / 材质实例顶着** —— 材质能做表面覆盖（路面 / 草坪），"
            "但**没有包围盒、量不出尺寸，摆不出实体**："
        )
        for _name in mat_only:
            lines.append(f"  - {_name}")
        lines.append(
            "  用户 2026-09-24 的要求是：这类元素**先给预估尺寸、登记成白膜占位**，"
            "再确认清单。**到底当表面用还是登记白膜，请用户拍板** —— "
            "本工具不替他决定（不猜是硬规则）。"
        )

    if unresolved:
        lines.append("")
        lines.append(
            "⚠ 以下元素**在元素清单里有、但本表里没有对应资产** —— 不是被删了，是没落位："
        )
        for u in unresolved:
            lines.append(f"  - {u.element_key}（元素清单里 {u.occurrences} 处）")
            if u.note:
                lines.append(f"      └ 元素清单原话：{u.note}")
        lines.append(
            "  ⚠ 本工具**不推断**原因。可能是：找不到名字对得上的资产 / "
            "本来就按光照环境处理不走资产。**要原因，得问用户。**"
            "（路径验证不通过的行走不到这里 —— 它们在交付前就被拒收了。）"
        )

    base_note = (
        "资产清单已生成并落盘（catalog/asset_list.json）。"
        + (f"其中 **{placeholders} 行是白膜占位、尺寸为预估** —— 请用户重点确认这些尺寸。"
           if placeholders else "")
        + (f"⚠ 另有 {len(mat_only)} 行**只有材质/材质实例顶着**（摆不出实体）："
           + "、".join(mat_only)
           + " —— 请用户拍板：当表面用，还是登记成白膜占位。"
           if mat_only else "")
        + "⚠ 表里的「尺寸」是**资产自身**的包围盒，**不是**场景目标尺寸：偏小 / 偏大用阶段二的 `scale` 换算"
          "（`footprint_m` = 实测 × `scale`）—— **不许拿「这个资产只有 89 cm」去问用户要不要换资产**"
          "（那是**你**该算的，不是让用户拍的）。"
        + "**请把 deliverable 贴给用户做最终确认。**"
    )
    delivery = AssetListDelivery(
        delivered_at=datetime.now(timezone.utc).isoformat(),
        source_image=stored.get("source_image", ""),
        total=len(results),
        verified=sum(1 for r in results if r.exists),
        placeholders=placeholders,
        # invalid_paths 恒为空：路径验不过的行在上面就被拒收了，走不到这里。
        invalid_paths=[],
        items=results,
        unresolved_elements=unresolved,
        deliverable="\n".join(lines),
        note=base_note,
    )
    # 给这张清单「签字」：记下当时的资产库指纹（best-effort —— 指纹只是"下次判定过期"
    # 的依据，不该因为它失败就把整次交付判死；但失败必须说出来，不许默默吞掉）。
    fingerprint_note = ""
    try:
        inventory, fp_calls = await library_inventory(ctx)
        digest, counts = library_fingerprint(inventory)
        save_json(LIBRARY_PATH, {
            "captured_at": delivery.delivered_at,
            "hash": digest,
            "counts": counts,
            "total": sum(counts.values()),
            "note": "confirm_assets 落盘时记的资产库指纹；只覆盖路径层面（哪些资产存在）",
        })
        fingerprint_note = (
            f"资产库指纹已记录（{sum(counts.values())} 个资产 / {fp_calls} 次枚举）—— "
            "之后 get_asset_list() 才判定得了这张表过没过期。"
        )
    except Exception as exc:
        # 这里刻意接 Exception（比 ToolError 宽一档）：交付本身已经落盘了，
        # 指纹只是"下次判定过期"的依据。而 Exception 接不住 CancelledError
        # （BaseException 子类）—— 这正是我们要的：关机/取消要能正常往外抛。
        fingerprint_note = (
            f"⚠ 资产库指纹记录失败（{type(exc).__name__}: {exc}）—— "
            "这张表下次取用时会报『没有指纹』。"
        )

    delivery = delivery.model_copy(
        update={"note": f"{delivery.note} {fingerprint_note}"}
    )
    save_json(ASSET_LIST_PATH, delivery.model_dump())
    return delivery


# --- [完工-09] 工具 6：取清单（读）---
# 实测 2026-09-23 12:12（stale=false；bush 从"还缺的元素"里消失）、12:24（items 带尺寸）。
#
# 为什么需要它（用户 2026-09-23 拍板加）：工具 5 是写表，本工具是读表 + 判定这张表
# 还作不作数。没有它，宿主只能自己去读 catalog/asset_list.json，那就绕过了 MCP，
# 等于把"用哪张表"交回给模型自觉。

@mcp.tool()
async def get_asset_list(
    ctx: Context[AppContext],
    verify_paths: Annotated[
        bool,
        Field(description="true = 逐条调官方 exists() 验活（默认）；false = 只比指纹，省调用"),
    ] = True,
    max_per_element: Annotated[
        int,
        Field(ge=1, le=20, description="每个还没落位的元素最多列几个新候选（默认 5）"),
    ] = 5,
) -> AssetListStatus:
    """取当前**权威资产清单**，并判定它**还作不作数**。动任何东西之前先调它。

    它回答四个问题：
      ① 有没有交付过清单 —— 没有就别往下走，先用 confirm_assets 落一份；
      ② 这张表还是不是签字时的那张 —— 用**资产库指纹**比（哈希 + 每类数量）；
      ③ 表里的路径**逐条**还活着吗 —— verify_paths=True 时调官方 exists() 验；
      ④ 还没落位的元素，现在出现候选了吗 —— 实况枚举后按【资产名/文件夹名】两条路匹。

    顺带把**整张表原样带出**（`items` 字段）：每行的元素、路径、类别，以及交付时
    **实测的包围盒尺寸与体积** —— "列出表"用这一个调用就够，不必去读 catalog 里的文件。

    ⚠ **只读**：不改 asset_list.json、不碰关卡、**不猜**。第 ④ 步只报"名字对得上"的候选，
      找不到就是空 —— 禁止拿别的资产顶替。
    ⚠ 指纹只覆盖**路径层面**（哪些资产存在），覆盖不了"同一个路径内容变了"
      （你把某个材质实例的贴图换了，路径没变、exists() 仍是 true）。
    ⚠ **开场先查状态**：讲流程 / 给方案 / 报进度**之前**先调本工具 —— 不是「动东西之前」，
      是「**开口之前**」。状态只认本工具的**返回值**，不认文件里叙述性的旧措辞
      （例：`plan_v1.json` 里那句「参数或几何均未变，沿用上一次确认」——
      实际参数后来改过，那行文案早已过期）。
    ⚠ 宿主**不许**用上下文里记得的旧表；每次开工都必须重新调本工具。
    """
    # ⚠ 这次调用本身要留痕（2026-09-26 加）：`execute_build` 落关卡前会核对"开场动作做过没有"，
    #   见 `_session_prereq_guard()`。**在入口就记**（不看返回值）—— "清单还没交付"这类
    #   正常结果也算调过，否则预检没走完时就变成死锁（越没表越被拦、越被拦越没法推进）。
    _mark_session_prereq("get_asset_list")
    delivery = load_json(ASSET_LIST_PATH)
    elements_doc = load_json(ELEMENTS_PATH) or {}
    elements = [
        e.get("element", "")
        for e in elements_doc.get("elements", [])
        if isinstance(e, dict) and e.get("element")
    ]
    # 场景项不是资产、永远不会出现在资产清单里 —— 不许算成"未落位元素"（假缺口）
    _tbl_all = load_categories()
    _scene_names = {
        str(e.get("element") or "")
        for e in elements_doc.get("elements", [])
        if isinstance(e, dict) and is_scene_category(str(e.get("category") or ""), _tbl_all)
    }
    elements = [e for e in elements if e not in _scene_names]
    _scene_out, _scene_size, _scene_time = scene_from_rows(
        elements_doc.get("elements", []) or [], _tbl_all
    )
    warnings: list[str] = []
    calls = 0

    # 情况 0：压根没交付过清单 —— 这不是错误，是一种明确状态
    if not delivery:
        return AssetListStatus(
            has_list=False,
            stale=None,
            missing_elements=elements,
            next_step=(
                "还没有交付过资产清单：先 confirm_elements 记元素、plan_assets 找资产，"
                "再用 confirm_assets 落一份表（它会顺手给表记上资产库指纹）。"
                "**在这之前没有任何『权威清单』可用 —— 禁止凭上下文里的旧表干活。**"
            ),
            warnings=["catalog/asset_list.json 不存在。"],
        )

    items = delivery.get("items", []) or []
    # 表里每一行原样带出（含交付时实测的尺寸/体积），不做二次加工
    rows = [
        AssetListRow(
            element=str(it.get("element") or ""),
            element_key=str(it.get("element_key") or ""),
            category=str(it.get("category") or ""),
            category_cn=str(it.get("category_cn") or ""),
            asset_path=str(it.get("asset_path") or ""),
            asset_type=str(it.get("asset_type") or ""),
            is_placeholder=bool(it.get("is_placeholder")),
            placeholder_shape=str(it.get("placeholder_shape") or ""),
            size_cm=it.get("size_cm"),
            bbox_volume_cm3=it.get("bbox_volume_cm3"),
            size_source=str(it.get("size_source") or ""),
            note=str(it.get("note") or ""),
        )
        for it in items
    ]

    inventory, calls = await library_inventory(ctx)
    live_hash, live_counts = library_fingerprint(inventory)

    signed = load_json(LIBRARY_PATH)
    if signed:
        signed_hash = signed.get("hash", "")
        signed_counts = signed.get("counts", {}) or {}
        stale = signed_hash != live_hash
    else:
        signed_hash, signed_counts, stale = "", {}, None
        warnings.append(
            "这张清单**没有指纹**（是旧版本 confirm_assets 落的，或指纹文件被删了）。"
            "重跑一次 confirm_assets 就能给它签字，之后才判定得了『还作不作数』。"
        )

    changed = describe_count_changes(signed_counts, live_counts) if signed else []

    checks: list[PathCheck] = []
    if verify_paths:
        for it in items:
            if it.get("is_placeholder"):
                continue      # 白膜占位没有路径 —— 不许拿空串去 exists()
            path = it.get("asset_path", "")
            entry = PathCheck(element=it.get("element", ""), asset_path=path, ok=False)
            try:
                exists = await call_official(
                    ctx, "exists", {"path": path}, toolset=TS_ASSET
                )
                calls += 1
                entry.ok = exists is True or (
                    isinstance(exists, str) and exists.lower() == "true"
                )
            except ToolError as exc:
                calls += 1
                entry.error = str(exc)
            checks.append(entry)
    dead = [c.asset_path for c in checks if not c.ok]

    covered, mode = element_keys_from_items(items)
    missing = [e for e in elements if e.lower().strip() not in covered]
    found: dict[str, list[str]] = {}
    for kw in missing:
        cands = candidates_for(kw, inventory, max_per_element)
        if cands:
            found[kw] = [c.path for c in cands]

    # 缺失再按大类分一次组（2026-09-24 用户要求分大类）
    _cat_table = load_categories()
    _cat_by_element = {
        str(e.get("element") or ""): str(e.get("category") or "")
        for e in elements_doc.get("elements", []) if isinstance(e, dict)
    }
    _miss_cat: dict[str, list[str]] = {}
    for kw in missing:
        _miss_cat.setdefault(category_cn(_cat_by_element.get(kw, ""), _cat_table), []).append(kw)
    missing_by_cat = {cn: _miss_cat[cn]
                      for cn in order_category_names(set(_miss_cat), _cat_table)}

    # 按优先级给出下一步（死路径 > 过期 > 有新候选 > 可以用）
    if dead:
        next_step = (
            f"⚠ 表里有 {len(dead)} 条路径**已经不存在**（见 dead_paths）。"
            "**先让用户处理掉**（重新给路径，或明确确认跳过），再往下走 —— "
            "否则下一阶段会挂上一个解析不到的材质/网格。"
        )
    elif stale:
        next_step = (
            f"资产库指纹变了（{'；'.join(changed) or '数量未变，路径集合变了'}），"
            "**这张表已不是签字时的那张**。把差异摆给用户，让他决定："
            "是重跑 confirm_assets 出新表，还是先查清这次变化。"
        )
    elif found:
        names = "、".join(found)
        next_step = (
            f"清单本身是活的，但发现了**新候选**（{names}）。"
            "把候选原样报给用户确认用哪一个，确认后再 confirm_assets 更新表 —— **不许自己挑**。"
        )
    else:
        _ph = sum(1 for it in items if it.get("is_placeholder"))
        next_step = (
            "清单 fresh、路径全部存活，可以用。"
            + (f"⚠ 表里有 {_ph} 行**白膜占位**（尺寸是**预估**、不是实测）—— "
               "用之前要让用户确认过这些尺寸。" if _ph else "")
            + "⚠ 照实说明：指纹只保证**路径有效**，不保证**同名资产的内容没被改过**。"
        )

    # ⚠ 「尺寸这一列怎么读」（2026-09-26 加；客户反馈）：agent 拿「house1 实测 89 cm」去问用户
    #   「要不要换资产」—— 而 `scale` 就是干这个的。挂在**每次都要读的清单返回**上。
    if any(isinstance(r.size_cm, list) and r.size_cm for r in rows):
        warnings.append(
            "⚠ 清单里的「尺寸」是**资产自身**的包围盒，**不是**场景里该有多大的目标尺寸"
            "（实测例：house1 89 cm、tree 16 m）。阶段二用 `scale` 换算："
            "`footprint_m`（米）= 实测包围盒（cm）÷ 100 × `scale`。"
            "**偏小 / 偏大是常态 —— 用 `scale` 解决，不要为它换资产、更不要拿这个去问用户。**"
        )

    return AssetListStatus(
        has_list=True,
        delivered_at=delivery.get("delivered_at", ""),
        source_image=delivery.get("source_image", ""),
        total=len(items),
        placeholders=sum(1 for it in items if it.get("is_placeholder")),
        items=rows,
        stale=stale,
        signed_at=signed.get("captured_at", "") if signed else "",
        signed_hash=signed_hash,
        signed_counts=signed_counts,
        live_hash=live_hash,
        live_counts=live_counts,
        changed_types=changed,
        path_check=checks,
        dead_paths=dead,
        missing_elements=missing,
        missing_by_category=missing_by_cat,
        scene=_scene_out,
        new_candidates=found,
        coverage_mode=mode,
        official_calls=calls,
        next_step=next_step,
        warnings=warnings,
    )


# --- 阶段二辅助：参数合并 / 摘要 / 闸门取数 -------------------------------------

_PLANNING = None


def _planning_modules():
    """取规划层模块（plan）—— 惰性导入，带两种启动方式的兜底。

    为什么不在文件顶部 import（2026-09-23 血账，两次炸 server 的第二次）：
      ① 启动方式不兼容：宿主是按脚本方式起这个文件的
         （`python F:\\MCP_Server\\src\\mcp_server\\main.py`），这时 `__package__` 是空的，
         顶部写 `from .planning import ...` 会直接抛
         `ImportError: attempted relative import with no known parent package`
         —— 整个 server 起不来（宿主侧表现为 mcp-client(mine) 重连 7 次全败）。
      ② 不该连坐：规划层出任何问题，都不该把阶段一那 6 个工具一起带崩。
    """
    global _PLANNING
    if _PLANNING is not None:
        return _PLANNING

    errors: list[str] = []
    try:
        from .planning import plan as p
    except ImportError as exc:
        errors.append(f"相对导入失败：{exc}")
        # 脚本方式下 __package__ 为空，相对导入必失败 —— 自己把本文件所在目录放进
        # sys.path 再按顶层包导入。别依赖"宿主会把脚本目录加进 sys.path"（runpy 就不加）。
        here = str(Path(__file__).resolve().parent)
        if here not in sys.path:
            sys.path.insert(0, here)
        try:
            from planning import plan as p
        except ImportError as exc2:
            errors.append(f"顶层导入失败：{exc2}")
            # 两个错误都带上：只报第一个会让人查错方向
            raise ToolError("阶段二规划层导入失败（阶段一工具不受影响）："
                            + "；".join(errors)) from exc2
    _PLANNING = p
    return _PLANNING


def _planning_warnings(previous: dict) -> list[str]:
    """阶段二开工时的**提示**：清单读没读到、有没有元素"阶段一记过、但清单里没有"。

    ⚠ 2026-09-25 改（用户指令「阶段二不要这个自检阶段了，跟它有关的都记得改」）：
      本函数原来叫 `_planning_classify`，返回 `(known, no_asset, 来源说明, 判没判出来)` ——
      那四样只有 11 项自检在消费；自检删了，它们就没有下游了，一并去掉，只留对人的警告。

    留下的这条为什么值得留：它让"阶段一记过、阶段二却没落位"的元素在报文里**显形**
      （实测例子：`sky` / `map_size` / `time_of_day` —— 它们本来就不走资产，
       但读报文的人得知道，否则会以为阶段二漏了）。
    """
    known = {str(e.get("element") or "").strip().lower()
             for e in (previous.get("rows") or []) if e.get("element")}
    warnings: list[str] = []

    delivered = load_json(ASSET_LIST_PATH) or {}
    rows = [it for it in (delivered.get("items") or []) if isinstance(it, dict)]
    delivered_keys = {str(it.get("element_key") or "").strip().lower() for it in rows}
    delivered_keys.discard("")
    # 交付清单里的 `element_key` 才是**权威关键词**（`elements.json` 的 element 字段带中文后缀，
    # 形如 "trash_bin 红色垃圾桶"，拿它跟放置表的 element_key 比会全线对不上）。
    known |= delivered_keys

    if not rows:
        warnings.append("读不到 catalog/asset_list.json —— 阶段一交付清单没读到，请留意。")
        return warnings
    if not any("is_placeholder" in it for it in rows):
        warnings.append(
            "catalog/asset_list.json 还是**旧格式**（行里没有 is_placeholder 字段）—— "
            "重跑一次阶段一的 confirm_assets 会补上这个字段。"
        )
    not_delivered = sorted(known - delivered_keys)
    if not_delivered:
        warnings.append(
            "这些元素**在阶段一记过、但交付清单里没有**：" + "、".join(not_delivered)
            + "。它们可能本来就不走资产（如 sky 按光照环境处理）—— "
            "**要摆它们之前先向用户确认**，别当成漏了。"
        )
    return warnings


def _sync_scene_map_size(new_size, why: str) -> str:
    """把阶段二定下来的世界大小**回填**进阶段一的 `catalog/elements.json`（场景项「地图大小」）。

    为什么必须由**代码**干这件事（2026-09-24 用户要求 #6）：阶段一记的「地图大小」是从参考图
    **目测**来的，阶段二把确认过的元素一排，常常发现装不下（实测：记 120×30，实际进深要
    38.7 m → 120×40）。以前这件事只能**靠人手工回填** —— 换个 agent 就会忘，于是阶段一 /
    阶段二两份交付物**永久对不上**（`plan.world` 说自己被"调用方覆盖"、`elements.json` 还写着旧值）。
    现在由 `generate_plan` 在"调用方覆盖了 `world.size`"时**自动同步**，谁都不需要记得。

    只动 `map_size` 那一行 + 两个派生字段（`scene` / `scene_map_size_m`），其余原样保留；
    回填写进该行 `note`（谁改的、什么时候、原值多少 → 新值多少）。返回一句人话（没改则空串）。
    """
    doc = load_json(ELEMENTS_PATH) or {}
    rows = doc.get("elements")
    if not isinstance(rows, list):
        return ""
    target = None
    for e in rows:
        if isinstance(e, dict) and str(e.get("category") or "") == "map_size":
            target = e
            break
    if target is None:
        return ""
    try:
        old = [float(v) for v in (target.get("size_m") or [])][:2]
    except (TypeError, ValueError):
        old = []
    new = [float(new_size[0]), float(new_size[1])]
    if old == new:
        return ""                       # 已经一致：什么都不做（幂等 —— 重复调用不会刷出多条备注）
    old_txt = "×".join(f"{v:g}" for v in old) if old else "没记"
    target["size_m"] = new
    target["note"] = (str(target.get("note") or "").rstrip()
                      + f"\n【由阶段二回填】{datetime.now(timezone.utc).isoformat()}："
                        f"阶段一原记 {old_txt} m，{why} → 回填为 {new[0]:g}×{new[1]:g} m。")
    scene = dict(doc.get("scene") or {})
    scene["地图大小"] = f"{new[0]:g}×{new[1]:g} m（预估）"
    doc["scene"] = scene
    doc["scene_map_size_m"] = new
    save_json(ELEMENTS_PATH, doc)
    return (f"阶段一记的『地图大小』（{old_txt} m）与这版世界 {new[0]:g}×{new[1]:g} m 不一致 —— "
            "**已由代码回填**进 catalog/elements.json 的 map_size 行（免得两份交付物对不上；"
            "这种事不许靠人记得）。")


def _planning_snapshot_check() -> list[str]:
    """查「交付清单和资产库指纹是不是**同一次签字**」→ 警告列表（只读、离线）。

    ⚠ **照实说清它查不出什么**：本工具是**离线**的（刻意的 —— 阶段二不依赖 UE，编辑器关着
    也能跑），所以"资产库**后来**变了"这件事它查不出来 —— 那要调 `get_asset_list()`
    （只有它会实况枚举 + 判过期）。这里只保证两份交付物**互相对得上**：
    `asset_list.json` 的 `delivered_at` 应当 == `library_snapshot.json` 的 `captured_at`。
    """
    warnings: list[str] = []
    delivered = load_json(ASSET_LIST_PATH) or {}
    if not delivered.get("items"):
        return warnings                      # 还没交付过清单：由阶段一那边去管，这里不喊
    snapshot = load_json(LIBRARY_PATH) or {}
    if not snapshot:
        warnings.append(
            "读不到 catalog/library_snapshot.json —— 这份交付清单**没有资产库指纹**，"
            "『清单没过期』这件事**没验**（要验请调 get_asset_list()）。"
        )
        return warnings
    d_at = str(delivered.get("delivered_at") or "")
    s_at = str(snapshot.get("captured_at") or "")
    if d_at and s_at and d_at != s_at:
        warnings.append(
            f"交付清单与资产库指纹**不是同一次签字**（清单 {d_at} / 指纹 {s_at}）—— "
            "要么清单被手改过、要么指纹被单独换过。用之前先调 get_asset_list() 查实况。"
        )
    if not snapshot.get("hash"):
        warnings.append("catalog/library_snapshot.json 里没有 hash —— 指纹不可用。")
    return warnings


def _summarize(plan: dict) -> PlanSummary:
    """从放置数据里数几个数出来。

    ⚠ 2026-09-25：原来还会数"自检几项、没过几项" —— 阶段二自检已整段删除（用户指令），
      这里不再读 `plan["checks"]`；旧 `plan_v1.json` 里残留的该字段被**忽略**。
    """
    world = plan.get("world", {}) or {}
    return PlanSummary(
        world_center=world.get("center", []) or [],
        world_size=world.get("size", []) or [],
        assets=len(plan.get("assets", []) or []),
        whiteboxes=len(plan.get("whiteboxes", []) or []),
    )


def _gate_model(g: dict) -> PlanGate:
    """把 planning.gate_check() 的字典转成模型（显式取字段，不吃多余键）。"""
    return PlanGate(
        confirmed=bool(g.get("confirmed")),
        params_hash_ok=bool(g.get("params_hash_ok")),
        plan_hash_ok=bool(g.get("plan_hash_ok")),
        confirmed_by=g.get("confirmed_by", "") or "",
        confirmed_at=g.get("confirmed_at", "") or "",
        params_hash=g.get("params_hash", "") or "",
        plan_hash=g.get("plan_hash", "") or "",
    )


def _readback_guard() -> None:
    """**「改完必须回读」这道闸**（2026-09-26 用户要求：文档是软约束，要更强的）。

    谁调它：`generate_plan`（写之前）与 `execute_build`（碰 UE 之前）。
    不通过就抛 `ToolError`，并把**这一版到底改了什么**原样摆出来 —— 即使 agent 想跳步，
    也得先把事实读进上下文。**清掉它的唯一途径是调 `get_plan()`**（只读工具，改不了数据）。
    为什么要有它：以前"改完必须回读核对"只写在 AGENTS.md / docs 里 —— 实测被漏过一次，
    结果一条该删的行残留在 plan 里，直到下一次偶然 `get_plan()` 才发现。
    ⚠ 台账读不动时**放行**（不拿基础设施故障拦人）；拦不拦都不改任何几何。
    """
    planning = _planning_modules()
    try:
        pend = planning.pending_readback()
    except Exception:                       # noqa: BLE001 —— 台账读不动不拦人
        return
    if not pend:
        return
    cs = pend.get("change_set") if isinstance(pend.get("change_set"), dict) else {}
    bits: list[str] = []
    for key, word in (("added", "新增"), ("changed", "改动"), ("removed", "删除")):
        vals = cs.get(key) or []
        if vals:
            head = "、".join(str(x) for x in vals[:6])
            tail = f" 等 {len(vals)} 行" if len(vals) > 6 else ""
            bits.append(f"{word} {len(vals)} 行：{head}{tail}")
    detail = "；".join(bits) if bits else "（与上一版几何相同）"
    raise ToolError(
        "拒收：**这一版你还没回读核对** —— 先调 `get_plan()`（只读，看一眼那几行）再回来继续。\n"
        f"· 待核对的几何指纹：{str(pend.get('plan_hash') or '')[:10]}…（写于 {pend.get('at') or '?'}）\n"
        f"· 它相对上一版的变化：{detail}\n"
        "（这道闸为什么存在：以前「改完要回读」只写在文档里，实测被漏过 —— 一条该删的行残留到"
        "下一次偶然 `get_plan()` 才发现。现在由代码强制：不调 `get_plan()`，`generate_plan` 与 "
        "`execute_build` 都不放行。）"
    )


# --- 阶段三 · 「开场动作」的登记与闸（2026-09-26 加；**尚未实测**）---------------------
# 客户 agent 交付后自评里「写在描述里但代码不拦的」两条：
#   · 「开场先调 get_asset_list」—— **没调**（开场只调了 get_plan）；
#   · 「依赖官方前先 official_status」—— **没调**（直接 list_tools 就开干了）。
# ⚠ 这是**纪律闸**，不是正确性闸：它保证不了"你读懂了返回内容"，只保证"你调过"。
#   敢拦的理由：两个都是**只读、各一次就够**的开场动作，代价极低；
#   而它们的返回正是"要不要继续往下走"的判断依据（链路通不通 / 清单过没过期、还有谁没落位）。
# ⚠ 只记**本 server 进程内**的调用（服务重启就清零）—— 如实写清楚，不假装是永久记录。

_SESSION_PREREQ_DONE: set[str] = set()


def _mark_session_prereq(name: str) -> None:
    """记下"本进程里调过某个开场工具了"。只加不减。"""
    _SESSION_PREREQ_DONE.add(str(name))


def _session_prereq_guard() -> None:
    """**碰关卡之前，先做过开场动作** —— 只认本 server 进程内的调用记录。

    谁调它：`execute_build()`（真跑之前；`dry_run` 与 `adopt` 不拦 —— 一个只看、一个只读现状）。
    缺哪个就点名哪个，并把"它给的是什么"写清楚 —— 拒绝要能教会人，不然只是添堵。
    """
    need = ["official_status", "get_asset_list"]
    missing = [n for n in need if n not in _SESSION_PREREQ_DONE]
    if not missing:
        return
    raise ToolError(
        "拒收：**开场动作还没做** —— 一个 Actor 都没动。缺："
        + "、".join(f"`{n}()`" for n in missing) + "\n"
        "为什么要它们（都只读、各一次就够）：\n"
        "· `official_status()` —— 先确认官方链路（协议版本 / 工具集数）；链路不通时，"
        "后面每一步都会以更难懂的方式失败；\n"
        "· `get_asset_list()` —— 你正要摆的东西的账本：这份清单**过没过期**、"
        "还有哪些元素**没落位** —— 搭建之前就该知道，而不是搭完才发现。\n"
        "（客户 agent 自评原话：「开场只调了 get_plan，没调 get_asset_list」、"
        "「依赖官方前没调 official_status，直接 tools/list 就开干了」。"
        "这道闸只认**本 server 进程内**调过没有 —— 服务重启后要再调一次。）"
    )


def _change_request_guard(planning, plan: dict) -> None:
    """**「改一份"已经被确认过"的规划之前，先留下『改什么 / 谁要的』」这道闸**（2026-09-26 加）。

    为什么要有它（客户 agent 交付后自评的原话）：「用户提改动要调 `request_plan_change` ——
      **一次都没调过** —— 你每次说要改，我直接 patch，没走变更台账」。
    后果不是几何错，而是台账回答不了「用户说了什么 ↔ 数据变成什么」——
      而那份台账存在的**全部意义**就是那个对应关系（他自己也写了：「这是我流程纪律的问题」）。
    判据（三条**同时**成立才拦）：
      ① 这一版与盘上那版**指纹不同**（真的一次内容变更；原样重发 / 只重算一遍不算）；
      ② 之前**确认过至少一版**（台账里有 `accepted_rows`）—— 第一次排表不受影响；
      ③ 台账的**改动窗口是关着的**（`change_window_open`）——
         由 `request_plan_change()` 打开、由 `confirm_plan()` 关闭，一轮里可以改多次。
    出路（**不是要你等用户开口，是要你留下对应关系**）：
      · 用户提的 → `request_plan_change(items=[他的原话], by="用户")`；
      · 你自己发现要修 → `request_plan_change(items=["自查：…"], by="agent 自查")`。
    ⚠ 台账读不动 → **放行**（与 `_readback_guard` 同口径：基础设施故障不拦人）。
    ⚠ 位置说明：本闸在 `_sync_scene_map_size()`（阶段一世界大小回填）**之后**跑 ——
      "同一次调用里既覆盖了世界大小、又被本闸拒收"这一种情况下，阶段一那份文件**已经**回填过。
      如实写在这里，不假装整条路径是原子的（要同时满足两个罕见条件才遇上）。
    """
    try:
        acc = planning.load_acceptance()
    except Exception:                       # noqa: BLE001 —— 台账读不动不拦人
        return
    if not isinstance(acc, dict) or not acc.get("accepted_rows"):
        return                              # 从没确认过 → 第一次排表，自由
    if acc.get("change_window_open"):
        return                              # 已经记过"要改什么 / 谁要的" → 窗口开着，放行
    new_hash = planning.plan_geometry_hash(plan)
    old: dict | None = None
    try:
        if planning.OUT_JSON.exists():
            old = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        old = None
    if isinstance(old, dict) and planning.plan_geometry_hash(old) == new_hash:
        return                              # 一模一样地重发 → 不拦（它连上次确认都不会丢）
    raise ToolError(
        "拒收：**这一版要改内容，但台账里没有「改什么 / 谁要的」的记录** —— 一个字节都没写。\n"
        "· 这份规划**已经被用户确认过**（台账里有确认基线）—— 改动会把那次确认**作废**；\n"
        "· 「用户说了什么 ↔ 数据变成什么」的对应关系，就靠 `request_plan_change()` 那一条记录留住"
        "（客户 agent 自评：他直接 patch，一次都没调过它）。\n"
        "先调一次 `request_plan_change(items=[...], by=...)`：\n"
        "· 用户提的改动 → `items` 用**他的原话**，`by=\"用户\"`；\n"
        "· 你自己发现要修的 → `items=[\"自查：…\"]`，`by=\"agent 自查\"`。\n"
        "记完就能改（窗口一直开到下一次 `confirm_plan()`，所以一轮里可以连着改好几次）。"
    )


def _acceptance_model(plan: dict) -> PlanAcceptance:
    """取**阶段二验收**状态 —— 交给 `planning.acceptance_view()`（**现算**，不写盘）。

    为什么现算而不是读 `views/acceptance.json` 里的 `state` 字段：图常常是**落盘之后**
    才画好的，读快照就会拿着"等出图"的旧字样去回答"走到哪了"。
    （与 `status` 不落盘是同一条口径。）
    """
    planning = _planning_modules()
    try:
        view = planning.acceptance_view(plan)
    except Exception as exc:        # noqa: BLE001 —— 台账读不动不该把读工具带崩
        return PlanAcceptance(
            state="unknown",
            state_cn=f"验收台账没读成（{type(exc).__name__}: {exc}）",
        )
    return PlanAcceptance(
        stage=view.get("stage", "阶段二验收"),
        round=int(view.get("round") or 0),
        state=view.get("state", "") or "",
        state_cn=view.get("state_cn", "") or "",
        plan_hash=view.get("plan_hash", "") or "",
        figures=list(view.get("figures") or []),
        pending_changes=list(view.get("pending_changes") or []),
        change_window_open=bool(view.get("change_window_open")),
        change_set=dict(view.get("change_set") or {}),
        awaiting_readback=dict(view.get("awaiting_readback") or {}),
        updated_at=view.get("updated_at", "") or "",
        ledger_path=view.get("ledger_path", "") or "",
        history=list(view.get("history") or []),
    )


def _stage2_next_step(plan: dict, acc: PlanAcceptance, empty: bool = False) -> str:
    """「下一步做什么」的**唯一处**（generate_plan 与 get_plan 共用，免得两处话术漂移）。

    按验收状态给话术 —— 这就是"阶段二验收"这个阶段在人眼前的样子。
    """
    if empty:
        return (
            "**当前是初始化状态**（两张表都空）：结构已按新口径立好，但没有任何坐标 —— "
            "**因为坐标的依据是参考图，图还没来**。下一步：拿到用户上传的图、"
            "过完阶段一（提元素 → 用户确认 → 找资产 → 交付清单）之后，"
            "你按图规划每件东西的 `pos` / `footprint_m`，再调本工具填进去。"
            "**别在没图的时候编坐标**（编了就是替用户决定，且违反『不猜』）。"
        )
    head = f"第 {acc.round} 轮 · 几何指纹 {acc.plan_hash[:10]}… · "
    if acc.state == "accepted":
        return (
            f"**阶段二验收通过**（{head}确认人已留痕）—— 闸门已开。"
            "下一步进第三阶段：**⓪ 先做两个开场动作**（都只读、各一次）：`official_status()` "
            "（确认官方链路）+ `get_asset_list()`（清单过没过期 / 还有谁没落位）—— "
            "没做过，`execute_build()` 会拒收。"
            "**第一步是问清「搭哪张图」** `check_build_target()`"
            "（先只读地问一遍 → **把问题交给用户、停下等他打字** → 带他的原话再调一次把答复记下来；"
            "官方没有『新建关卡』的工具），⚠ 现在这是**代码闸**：没拿到答复就调 `execute_build()` "
            "会被拒收。"
            "**第二步是批量搭建**：`generate_build_orders()` 先把放置表翻成指令表"
            "（米→厘米、补 Z、plane 压成薄 cube），再 `execute_build()` —— 它整批校验"
            "（闸门/指纹/路径 exists/行数）→ 清掉 `UEMCP/` 下的旧 Actor → **按表一次性全落** → "
            "读回 `get_actor_transform` **与白膜组件尺寸**对账。想先看不动手就传 `dry_run=true`。"
            "⚠ **搭之前会先过回读闸**：这一版若还没 `get_plan()` 过，`execute_build` 会拒收 —— "
            "先看一眼再搭。⚠ 清场 / 重摆前还会**逐行读关卡现状与台账比**（位置 / 朝向 / 缩放 / "
            "白膜厚薄）：人工改过的行与台账解释不了的 Actor **默认拒收**（要按 plan 覆盖才传 "
            "`accept_user_edits=true`）；**没有台账却有旧 Actor 时不许悄悄全量清场**"
            "（先 `adopt=true` 认领现状）。⚠ 这一版**要想再改**：先 "
            "`request_plan_change(items=[...], by=...)` 留一条「改什么 / 谁要的」，"
            "否则 `generate_plan` 会拒收（客户 agent 自评：他一次都没调过它）。"
            "⚠ 全程**不存盘**。口径见 `docs/阶段三-资产布局生成.md`。"
        )
    if acc.state == "changes_requested":
        return (
            "**当前在【阶段二验收】，状态 = 用户提了要改的地方**（"
            + (f"{head}还没落到数据里：" + "；".join(acc.pending_changes)
               if acc.pending_changes else head + "台账里有改动记录")
            + "）。下一步：按这些改动改 `pos` / `footprint_m` / `scale` → **重调本工具**"
            "（几何一变自动进新一轮、上一版自动留档）→ **重画图**（图内写新指纹）"
            "→ 再把图交付成卡片给用户。循环到他说无误为止。"
            "⚠ **只改动的行才要重画**：改完调 `get_plan()` 看 `acceptance.change_set.required_labels` —— "
            "那就是这一轮图里**只需**出现的那几行（用户要求：局部改就全局部，不要全部重做）。"
        )
    if acc.state == "awaiting_user":
        figs = "、".join(acc.figures) if acc.figures else "（没有认这份数据的图）"
        return (
            f"**阶段二已结束，当前在【阶段二验收】—— 等待用户看图确认**（{head}图：{figs}）。"
            "下一步**只做三件事，然后停下**："
            "① 把 `acceptance.figures` 里的图**交付成用户能点开看的卡片**"
            "（MCP 自己弹不出卡片，交给宿主交付）；"
            "② 附一张**验收清单**：图里哪几处是他要判断的（如「车列位置」「树的疏密」）；"
            "③ **停下等他打字** —— 不要再往问题框里塞「确认吗」。"
            "他说改哪儿 → 调 `request_plan_change` 记下来；他说行 → `confirm_plan`。"
        )
    if acc.state == "awaiting_figure":
        cs = acc.change_set if isinstance(acc.change_set, dict) else {}
        req = [str(x) for x in (cs.get("required_labels") or [])]
        shown = "、".join(req[:8]) + ("…" if len(req) > 8 else "")
        if not cs:
            scope = "⚠ 变更集读不到（验收台账没读成）—— 按**全量**画：图里要出现**每一行**的 label。"
        elif cs.get("local"):
            scope = (f"⚠ 这是**局部一轮**（基线：{cs.get('baseline')}）—— 图里**只要**出现本次改动的 "
                     f"{len(req)} 行：{shown}；另外 {cs.get('same')} 行**没动、不必重画**"
                     "（用户要求：局部改就全局部，不要全部重做）。")
        else:
            scope = (f"⚠ 还没有『确认过的基线』→ 这一版按**全量**画：图里要出现**每一行**的 label"
                     f"（共 {len(req)} 行），一行都不能漏。")
        return (
            f"**当前在【阶段二验收】的「等出图」**（{head}views/ 里没有认这份数据的图）。"
            "下一步**先 `get_plan()`**（只读，过**回读闸** —— 这一版写完之后你还没回读，"
            "不调它，下一次 `generate_plan` / `execute_build` 都会被拒收），"
            "② 再拿 `data_path`（views/plan_v1.json）**自己画一张** —— "
            f"图内必须写明当前几何指纹 `{acc.plan_hash[:10]}…`（否则确认时会被判成「图不认数据」），"
            + scope + "再交付给用户。**没有图不许让用户确认。**"
        )
    return (
        "现在**没有任何坐标**：先去拿用户上传的图，走完阶段一（提元素 → 用户确认 → "
        "找资产 → 交付清单），再按图规划每件东西的 `pos` 填进来。**别在没图时编坐标。**"
    )


def _write_plan(plan: dict) -> dict:
    """落盘计划数据 —— 交给 `planning.write_plan()`（**全工程唯一写入点**）。

    为什么改成委托（2026-09-24 收尾清单 #4 / #8）：写盘之外还要**给上一版留档**、
    还要**清除不认这份数据的图**，而 CLI 的 `--confirm` 也走同一份逻辑 —— 写入点只能有一个，
    否则两条路迟早写出不一样的文件。返回它的结果字典（留档名 / 清掉的图 / 留下的图）。
    （净化 `-0.0` / 禁用 NaN 都在 `write_plan` 里，行为与原先逐字一致。）
    """
    planning = _planning_modules()
    return planning.write_plan(plan)


_PATCH_ASSET_FIELDS = {"label", "element_key", "asset_path", "pos", "footprint_m",
                       "rot_deg", "scale", "note"}
_PATCH_BOX_FIELDS = {"label", "element_key", "shape", "pos", "footprint_m",
                     "rot_deg", "height_m", "size_source", "note"}
"""补丁里**允许改**的字段（按行类型分）。白名单是刻意的：
给资产行写 `height_m`、给白膜行写 `scale`/`asset_path` 都是**类型不对**的改法，
不该被静默接受（它们会被 `normalize_*` 或后续阶段当成有效数据读走）。"""


def _apply_plan_patch(cur_plan: dict, patch: list) -> tuple[list[dict], list[dict], list[str]]:
    """按 `label` 给**现有**放置表打补丁 → `(资产行, 白膜行, 说明)`。不合规 → 抛 `ToolError`。

    为什么要它（2026-09-26 用户要求：「用户想局部改，**所有都局部改，不要全部重做**」）：
    原来改一行也得把**整张表**（89 行）重新发一遍 —— 数据没被局部对待，"全部重做"只是从
    "重画图"挪到了"重发数据"上。现在只发改动的那几行 + 一条指令。

    四种操作（`op` 字段）：
      · `set`          `{"op":"set","label":"住宅 #1（house1）","set":{"pos":[-53,-32]}}`
      · `add_asset`    `{"op":"add_asset","row":{...整行...}}`
      · `add_whitebox` `{"op":"add_whitebox","row":{...整行...}}`
      · `remove`       `{"op":"remove","label":"..."}`

    ⚠ 定位**只认 `label`**（阶段二的规则：同类多个必须能区分）——必须**唯一命中**；
      命中 0 行（要用 add_*）或命中多行（先把 label 改得互不相同）都**拒收**。
    ⚠ 全程在**内存副本**上做：任何一条不合规 → 整个调用拒收，**一个字节都不写** ——
      不会留下"半新半旧"的放置表（与 `confirm_assets` 拒收时同一条纪律）。
    ⚠ 打完之后**仍走原来的整表校验**（`normalize_asset` / `normalize_whitebox`）——
      补丁没有自己的"宽松通道"。
    """
    asset_rows = [dict(r) for r in (cur_plan.get("assets") or []) if isinstance(r, dict)]
    box_rows = [dict(r) for r in (cur_plan.get("whiteboxes") or []) if isinstance(r, dict)]

    def _hits(label: str) -> list[tuple[str, int]]:
        out = [("asset", i) for i, r in enumerate(asset_rows)
               if str(r.get("label") or "") == label]
        out += [("whitebox", i) for i, r in enumerate(box_rows)
                if str(r.get("label") or "") == label]
        return out

    def _find(label: str, op_name: str) -> tuple[str, int]:
        if not label:
            raise ToolError(f"补丁里有一条（{op_name}）没给 `label` —— 定位只认 label。")
        hits = _hits(label)
        if not hits:
            raise ToolError(
                f"补丁（{op_name}）要动的行 `{label}` 在**当前放置表里找不到** —— "
                "补丁只能动**已有**的行；要加新行用 `add_asset` / `add_whitebox`。")
        if len(hits) > 1:
            raise ToolError(
                f"补丁（{op_name}）要动的行 `{label}` 在当前表里**有多行同名** —— 认不出是哪一个。"
                "请先把这几行的 label 改得互不相同（阶段二允许同类多行，但每行要有区别）。")
        return hits[0]

    notes: list[str] = []
    for k, op in enumerate(patch or [], 1):
        if not isinstance(op, dict):
            raise ToolError(f"补丁第 {k} 条不是对象：{op!r}")
        kind = str(op.get("op") or "").strip()
        if kind == "set":
            where, idx = _find(str(op.get("label") or "").strip(), "set")
            changes = op.get("set")
            if not isinstance(changes, dict) or not changes:
                raise ToolError(f"补丁第 {k} 条（set）没给 `set` —— 空补丁没有意义。")
            allowed = _PATCH_ASSET_FIELDS if where == "asset" else _PATCH_BOX_FIELDS
            bad = sorted(f for f in changes if f not in allowed)
            if bad:
                raise ToolError(
                    f"补丁第 {k} 条（set）里 {bad} 不是"
                    f"{'资产' if where == 'asset' else '白膜'}行能改的字段 —— 可改：{sorted(allowed)}")
            row = asset_rows[idx] if where == "asset" else box_rows[idx]
            before = {f: row.get(f) for f in changes}
            row.update(changes)
            notes.append("改 " + str(row.get("label")) + "："
                         + "、".join(f"{f} {before[f]} → {changes[f]}" for f in changes))
        elif kind in ("add_asset", "add_whitebox"):
            row = op.get("row")
            if not isinstance(row, dict) or not row:
                raise ToolError(f"补丁第 {k} 条（{kind}）没给 `row`（整行内容）。")
            label = str(row.get("label") or "").strip()
            if not label:
                raise ToolError(f"补丁第 {k} 条（{kind}）的 `row` 没写 `label`。")
            if _hits(label):
                raise ToolError(f"补丁第 {k} 条要加的行 `{label}` **已经存在** —— "
                                "加行必须用新 label；改已有的行请用 `set`。")
            (asset_rows if kind == "add_asset" else box_rows).append(dict(row))
            notes.append(f"新增{'资产' if kind == 'add_asset' else '白膜'}行：{label}")
        elif kind == "remove":
            where, idx = _find(str(op.get("label") or "").strip(), "remove")
            gone = (asset_rows if where == "asset" else box_rows).pop(idx)
            notes.append(f"删除：{gone.get('label')}"
                         f"（{'资产' if where == 'asset' else '白膜'}行）")
        else:
            raise ToolError(f"补丁第 {k} 条的 `op` 是 `{kind or '空'}` —— "
                            "只认 `set` / `add_asset` / `add_whitebox` / `remove`。")
    return asset_rows, box_rows, notes


# --- [完工-12] 工具 7：generate_plan（阶段二 · 记放置表；写）---
# ⚠ 2026-09-25：**本工具已不自检**（用户指令：「阶段二不要这个自检阶段了，跟它有关的都记得改」）——
#   11 项自检 + `build_checks()` + `_planning_measured()` + 摘要里的 checks_* 字段全部删除。
#   **下面这些 2026-09-23/24 的实测记录如实保留**（它们记的是"当时那版有自检时验过什么"），
#   但**不再描述当前行为** —— 读的时候请对照上面这条。碰撞检测归第四阶段。
# 实测 2026-09-23（旧版几何骨架）：改地块面宽 12→15 时自检全过、几何指纹可复现。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   工具面仍是 9 个、本工具经 MCP 端到端调用正常；confirm_assets 两条"该拒就拒"的断言也绿。
# ⚠ 指纹计算必须内部净化 -0.0（内存对象带 -0.0、落盘是 0.0，两边哈希就不等，
#   于是对着刚写进去的数据喊"文件被改过"）—— 预检第 ⑤ 项就是这条的回归检查。
# ⚠ 2026-09-24（四）按用户新规格整段换掉（只记元素放置，路网/地块骨架删除）。
# ✅ 2026-09-24（六）实测：「空表落盘」这条分支已验（generate_plan() 不带参数 → 两张表空、
#   自检 7/0；同 payload 重跑后指纹逐位回到 6674990729…）。
# ⚠ 2026-09-24（八）收尾清单 #1/#2/#3/#4/#6 落地：新增对账三条 + cube 高度一条自检（7 → 11 项）、
#   白膜 `height_m`、清单与指纹同源检查、**落盘改为 `write_plan()`（唯一写入点 + 上一版留档
#   + 自动清除不认账的图）**、**覆盖 world.size 时自动把新值回填进阶段一的 map_size 行**
#   （回填放在两份表校验通过之后），**初始化态（两张表都空）下覆盖类自检标"不适用"**，
#   保证 `generate_plan()` 空跑依旧全绿。
# ✅ 2026-09-24（八）实测（新代码上线后经 MCP 调用观察到）：
#   · 自检 **11 项 0 失败**在真数据上跑通（含 ⑧⑨⑩ 对账、⑪ cube 高度）；
#   · **自动回填阶段一**生效：catalog/elements.json 的『地图大小』= 100×60 m，
#     且数据里 `previous_elements.scene` 也是 100×60（回填后"重读阶段一"的直接证据）；
#   · **自动留档 + 自动清图**生效：views/archive/ 里 6 份 plan_v1_* 数据 + 4 张被清走的旧图；
#   · 新写入的数据里**没有 `status` 字段**（#5 生效）；
#   · 交付清单与资产库指纹快照**同一次签字**（captured_at == delivered_at = 12:17:50.970736Z）→ #3 无告警。
# ⚠ **仍未实测**：`confirm_plan`（MCP / CLI）改完后没被调过 —— "图不认数据就拒收"那条闸
#   与"确认时留档 / 清图"等第一次真确认再补证据。

# --- 工具 7：记录平面放置表（阶段二 · 写）--------------------------------------
# 本工具不依赖 UE：纯 2D 几何校验，编辑器关着也能跑。

@mcp.tool()
async def generate_plan(
    assets: Annotated[
        list[dict] | None,
        Field(description=(
            "**已有资产**的放置表（一物一行）。每行："
            "`element_key`（要与阶段一的元素名一致）、`label`（同类多个要能区分，如「行道树 #7」）、"
            "`asset_path`、`pos`（平面中心坐标 [X, Y]，米）、`footprint_m`（占地 [宽, 深]，米）、"
            "`rot_deg`（绕 Z 逆时针，度）、`scale`（模型缩放倍率）、`note`。"
            "⚠ **没有 count 字段**：摆 20 栋就写 20 行 —— 一条记录只能有一个 pos。"
        )),
    ] = None,
    whiteboxes: Annotated[
        list[dict] | None,
        Field(description=(
            "**白膜占位**的放置表（一物一行）。每行："
            "`element_key`、`label`、`shape`（cube / plane）、`pos`、`footprint_m`、"
            "`rot_deg`、`size_source`（**必须写明是「预估」**）、`note`；`asset_path` 留空。"
            "⚠ `shape=cube` 的**必须再给 `height_m`**（高度，米）—— 阶段一的白膜本来就有第三维"
            "（`size_cm` 的 Z），阶段六要靠它把 cube 实例化出来；缺了这一维，阶段六只能靠人读 note。"
            "`plane`（覆盖面）不用给高度。"
            "⚠ 只许放**阶段一里没有可用资产**的元素（没找到的 / 只有材质实例顶着的）。"
            "⚠ **必须等已有资产放完之后再填这张表** —— 先占位，才知道白膜剩哪儿、该多大。"
        )),
    ] = None,
    world: Annotated[
        dict | None,
        Field(description=(
            "覆盖世界信息（一般不用传）：`center`（平面中心坐标，默认 **[0, 0]**）、"
            "`size`（[X, Y] 米，默认取阶段一记录的「地图大小」）。"
            "不传 = 用默认。传送了会在数据里标成「调用方覆盖」。"
        )),
    ] = None,
    params: Annotated[
        dict | None,
        Field(description=(
            "**这一版是怎么定的**（自由文本，记进数据的 `params` 段，用于留痕与复现）："
            "如 `{\"依据\": \"参考图纵深/沿街长估计\", \"用户意见\": \"主楼再往左 3 m\"}`。"
            "⚠ 改它会让几何指纹变化 → 上一版确认自动作废。"
        )),
    ] = None,
    patch: Annotated[
        list[dict] | None,
        Field(description=(
            "**局部改（推荐用于「只改几行」）**：只发改动的那几行 + 一条指令，**不用重发整张表**。"
            "每项一个操作："
            "`{\"op\":\"set\",\"label\":\"住宅 #1（house1）\",\"set\":{\"pos\":[-53,-32]}}`（改已有行）/ "
            "`{\"op\":\"add_asset\",\"row\":{...整行...}}` / "
            "`{\"op\":\"add_whitebox\",\"row\":{...整行...}}` / "
            "`{\"op\":\"remove\",\"label\":\"...\"}`。"
            "⚠ 定位只认 `label`，必须**唯一命中**（找不到 / 多行同名都拒收，不猜）；"
            "字段有白名单（资产行不能写 `height_m`，白膜行不能写 `scale`/`asset_path`）。"
            "⚠ 与整表（`assets`/`whiteboxes`）**不能同时给**；第一版（还没有 plan_v1.json）只能整表给。"
            "⚠ 补丁改完**照样**过原来的整表校验 + 落盘 + 归档 —— 没有「宽松通道」。"
        )),
    ] = None,
) -> PlanResult:
    """把**平面放置表**落盘成 `views/plan_v1.json` —— 阶段二主工具（记录，不是规划）。

    三件事：
      ① 校验并规整：一物一行、每行必须有 `pos` 与 `footprint_m`（米）；
      ② 落盘 + 钉**几何指纹**（除 `confirmation` 外全部内容，`params` 也算进去）
         + **给上一版留档**（`views/archive/`）。
      ⚠ **不再自检**（2026-09-25 用户指令：「阶段二不要这个自检阶段了」）：原来那 11 项具名自检
        （两两不重叠 / 边界 / 元素归属 / 阶段一对账 / cube 高度）连同 `build_checks()` 整段删除，
        `plan_v1.json` 里不再写 `checks`。**碰撞检测与布局修正归第四阶段**（原文分工）。

    ⚠ **本工具不规划坐标** —— 坐标由**你**看图+按用户要求规划好再传进来。
    ⚠ **本工具不出图**（2026-09-24 用户拍板：别用定死的模板画）。`image_path` 恒为空；
      要给人看，**你自己拿 `data_path` 里的数据画** —— 每条记录就是「中心 + 占地 + 朝向」，
      画法由你定，不写死在代码里。画完记得**图内写上当前几何指纹**：`confirm_plan` 会拿它
      核对"图认不认这份数据"（收尾清单 #8）。
    ⚠ **单位是米**（到 UE / Blender 那层才 ×100 转厘米）。
    ⚠ **顺序不能反**：先放**已有资产**（占地大小 = 阶段一实测包围盒 × `scale`，是**定的**），
      再放**白膜**（占地要等资产占完位在剩余空间里**重新估**）。
    ⚠ **一个物体一行**：摆多少写多少行。用一条记录 + 数量代表多个不同位置的物体 =
      报文里**看不见**那些没记录的物体（数据全绿、实际重叠）。
    ⚠ **谁能进白膜表**：`plan_assets` 报 missing 的、或只有材质实例顶着的元素
      （`placeholder_hint` 非空的那些）。
    ⚠ **本工具不联网、不碰 UE**（离线是刻意的）：所以"资产库**后来**变过没有"它查不出来 ——
      它只保证交付清单与资产库指纹**是同一次签字**；要查实况请调 `get_asset_list()`。
    ⚠ **覆盖 `world.size` 会顺手回填阶段一**：阶段一记的『地图大小』是目测值，装不下时你覆盖
      世界大小 —— 本工具会把新值**自动写回 `catalog/elements.json`** 的 `map_size` 行（并在
      `warnings` 里报出来），免得阶段一 / 阶段二两份交付物对不上。**这件事不许靠人记得。**
      （顺序上：两份放置表**校验通过之后**才回填 —— 负载被拒收时一个字节都不动。）
    ⚠ **落盘会顺手清除不认这份数据的图**（别的版本的图移进 `views/archive/`）：图是"用户确认过
      那一版"的凭据，数据一改旧图就没人认过 —— 留在 `views/` 只会误导人。**同样不许靠人记得。**

    **局部改：`patch`（2026-09-26 用户要求：「所有都局部改，不要全部重做」）**：
    改一行不必重发整张表 —— 用 `patch=[{"op":"set","label":"住宅 #1（house1）","set":{"pos":[...]}}]`
    只发改动的那几行（`set` / `add_asset` / `add_whitebox` / `remove` 四种操作）。
    补丁与整表走**同一条**校验 + 落盘 + 归档路径（不存在"补丁通道"），
    并在 `params` 里自动记一条"这一版打了哪几条补丁"，方便追溯。
    ⚠ 定位只认 `label` 且必须唯一命中；⚠ 与整表不能同时给；⚠ 第一版必须整表给。
    ⚠ 改完先看 `get_plan().acceptance.change_set` —— 那告诉你**图里只需画哪几行**。
    """
    planning = _planning_modules()

    # ⚠ 第 1 道闸：**上一版还没回读** → 先拒收（把文档里的软约束变硬，见 _readback_guard）
    _readback_guard()

    # ⚠ 第 2 道闸：阶段一没走完不许规划 —— 没有**签过字**的资产清单就直接拒收（堵"跳步"）。
    #    为什么：放置表里的 `asset_path` 与占地都来自那份清单；跳过阶段一等于**凭空编资产**。
    #    空表（初始化态）仍放行 —— 那是"先把结构立起来"，不涉及任何资产。
    if (assets or whiteboxes or patch) and not ASSET_LIST_PATH.exists():
        raise ToolError(
            "拒收：还没有阶段一签过字的资产清单（`catalog/asset_list.json`）。"
            "顺序是：`plan_assets()` 找资产 → `confirm_assets()`（**并让用户确认清单**）→ 再规划。"
        )

    # --- 读阶段一：世界大小从这儿来，元素的"合法性"也按它判 ---
    previous = planning.load_previous_elements()
    if not previous["rows"]:
        raise ToolError(
            "读不到阶段一的元素清单（catalog/elements.json）—— "
            "世界大小与『元素是否来自阶段一』都要靠它。请先在阶段一 confirm_elements。"
        )

    # --- 局部补丁：把"只发改动的那几行"解析成**完整的**两份表（2026-09-26 用户要求）------
    # 补丁不是另一条通道：它只是"拿当前表当底稿、把改动盖上去"，之后**照走原来的整表路径**
    # （normalize → 校验 → 落盘 → 归档 → 清图 → 进验收）。
    if patch is not None and not patch:
        raise ToolError(
            "`patch` 是**空表** —— 没有要改的东西。要么给至少一条补丁，要么整表重发。"
            "⚠ 提醒：不带任何参数（也不给 patch）调用本工具，会把放置表写成**空的初始化态**。"
        )
    patch_mode = bool(patch)
    patch_notes: list[str] = []
    cur_world: dict = {}
    patched_params: dict | None = None
    if patch_mode:
        if assets or whiteboxes:
            raise ToolError(
                "`patch` 与整表（`assets` / `whiteboxes`）**不能同时给** —— "
                "要打补丁就别重发整张表（这正是补丁的意义），要重发整表就别给 patch。"
            )
        if not planning.OUT_JSON.exists():
            raise ToolError("还没有 `views/plan_v1.json` —— 补丁只能改**已有**的放置表；"
                            "第一版请整表给（`assets` / `whiteboxes`）。")
        try:
            cur_plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise ToolError(f"读不动 views/plan_v1.json（{exc}）—— 补丁要有底稿才能打。") from exc
        if not (cur_plan.get("assets") or cur_plan.get("whiteboxes")):
            raise ToolError("当前放置表是**空的**（初始化状态）—— 没有行可以打补丁；"
                            "第一版请整表给（`assets` / `whiteboxes`）。")
        try:
            assets, whiteboxes, patch_notes = _apply_plan_patch(cur_plan, patch)
        except ToolError:
            raise
        except Exception as exc:                     # noqa: BLE001 —— 补丁解析异常一律拒收
            raise ToolError(f"补丁拒收（{type(exc).__name__}: {exc}）—— 一个字节都没写。") from exc
        cur_world = dict(cur_plan.get("world") or {})
        if params is None:
            patched_params = dict(cur_plan.get("params") or {})
            patched_params["本版变更（补丁）"] = (
                f"按 label 打了 {len(patch)} 条补丁，几何只动了这几处：" + "；".join(patch_notes))

    try:
        world_full, world_changed = planning.normalize_world(world, previous["scene"], previous)
    except ValueError as exc:
        raise ToolError(f"世界信息不成立：{exc}") from exc
    if patch_mode and world is None and cur_world:
        # 补丁没动世界 → **原样沿用当前这份**。不许让 normalize_world 从阶段一"重新推导"：
        # 阶段一那个『地图大小』是目测值，推导回来等于**悄悄改了世界大小**，
        # 还会误报"世界被覆盖"（进而在阶段一那份文件里做一次不必要的回填）。
        world_full, world_changed = cur_world, []

    # --- 规整两份放置表（不合规当场拒收，一个都不落盘）---
    norm_assets: list[dict] = []
    norm_boxes: list[dict] = []
    try:
        for raw in (assets or []):
            norm_assets.append(planning.normalize_asset(raw))
        for raw in (whiteboxes or []):
            norm_boxes.append(planning.normalize_whitebox(raw))
    except ValueError as exc:
        raise ToolError(f"放置表拒收：{exc}") from exc

    # --- 世界被覆盖过 → **顺手把新大小回填进阶段一**（2026-09-24 收尾清单 #6）---
    # 为什么放在"两份表校验通过之后"：负载要是被拒收，就**一个字节都不该动** ——
    #   包括阶段一那份文件（之前放在 normalize_world 后面，等于被拒的调用也改了阶段一）。
    # 为什么由代码做：不这么做，阶段一的『地图大小』永远停在目测值上，而阶段二的世界是另一个数 ——
    #   两份交付物对不上，且**只能靠人手改**（换个 agent 就忘）。
    # 回填之后重新读一次阶段一，好让本版数据里的「阶段一记录」跟着更新（别留一个假来源）。
    sync_note = ""
    if world_changed and "world.size" in world_changed:
        try:
            sync_note = _sync_scene_map_size(
                world_full["size"],
                why=f"generate_plan 按确认过的元素把世界覆盖为 "
                    f"{world_full['size'][0]:g}×{world_full['size'][1]:g} m")
        except OSError as exc:
            sync_note = (f"⚠ 想把新世界大小回填进阶段一（catalog/elements.json）但写不进去：{exc}"
                         " —— 阶段一那份表还是旧值，两份交付物暂时对不上。")
        else:
            if sync_note:
                previous = planning.load_previous_elements()

    # --- ⚠ 允许两份表都空（2026-09-24 用户要求）---
    # 为什么允许：结构要能"先立起来、内容是空的" —— 图还没来的时候，坐标根本没有依据
    # （pos 的依据就是参考图）。所以空表不是错误，它是**初始化状态**。
    # 但它**不是可确认的规划**：`confirm_plan` 会拒收（空表），`get_plan` 报 status=initialized
    # 依然不许在没给用户看过图的情况下确认（见那边的 docstring）。
    empty = not norm_assets and not norm_boxes

    # 「阶段一记过、但交付清单里没有」这类**提示**（见 _planning_warnings）
    # ⚠ 2026-09-25：原来这里还取 `known` / `no_asset` / 实测尺寸给 11 项自检用 —— 自检删了，
    #   那三样也就没有下游了（`_planning_measured()` 整个函数一起删掉）。
    warnings = _planning_warnings(previous)

    # 清单与资产库指纹是不是同一次签字（收尾清单 #3；本工具离线，查不了"库后来变过没有"）
    warnings.extend(_planning_snapshot_check())

    plan = planning.build_plan(
        norm_assets, norm_boxes, world_full,
        params=(patched_params if patched_params is not None else (params or {})),
        previous=previous)

    # ⚠ **改几何之前先有"改什么 / 谁要的"的记录**（2026-09-26 加，把软约束变硬）——
    #   见 `_change_request_guard()`：拒收时**一个字节都没写**（本闸放在 `_write_plan()` 之前）。
    _change_request_guard(planning, plan)

    if patch_mode:
        warnings.append(
            f"**这是补丁版**（{len(patch)} 条，只改了这几处）：" + "；".join(patch_notes)
            + "。⚠ 补丁与整表走同一条校验/落盘路径 —— 它没绕过任何闸门。"
        )
    if world_changed:
        warnings.append(f"世界信息被覆盖过：{world_changed}（已在数据里标成『调用方覆盖』）。")
    if sync_note:
        warnings.append(sync_note)
    if empty:
        warnings.append(
            "这是**初始化状态**（两张表都空）：`assets` / `whiteboxes` 里没有任何 pos —— "
            "坐标的依据（参考图）还没来。填完内容之后它就是一份 draft（`status` 由 get_plan "
            "现算，文件里不再写这个字段），那时才谈得上确认。"
        )
    elif not norm_boxes:
        warnings.append(
            "白膜表是空的：如果阶段一里还有『没找到资产 / 只有材质实例顶着』的元素，"
            "它们**还没落位** —— 别当成「摆完了」。"
        )
    # 一物一行：同类多个时提醒 agent 报的是个体数，不是阶段一的目视个数
    from collections import Counter as _Counter
    _by_key = _Counter(a["element_key"] for a in norm_assets)
    if any(c > 1 for c in _by_key.values()):
        warnings.append(
            "同类资产有多条（个体级放置）："
            + "、".join(f"{k}×{c}" for k, c in sorted(_by_key.items()) if c > 1)
            + "。⚠ 阶段一的 `count` 是**画面目视估计**，跟这里的个体数不是一回事 —— "
            "数字对不上是允许的，但要请用户确认过。"
        )

    # 几何一模一样 → 沿用上次确认（重算一遍不该把确认弄丢）
    if planning.OUT_JSON.exists():
        old_conf = (json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
                    .get("confirmation", {}) or {})
        if (old_conf.get("confirmed")
                and old_conf.get("plan_hash") == plan["confirmation"]["plan_hash"]):
            plan["confirmation"].update({
                "confirmed": True,
                "confirmed_by": old_conf.get("confirmed_by", ""),
                "confirmed_at": old_conf.get("confirmed_at", ""),
                "note": "几何未变，沿用上一次确认。",
            })
        elif old_conf.get("confirmed"):
            warnings.append(
                "这一版与上一次确认的**不是同一版**：上次确认**已作废**，"
                "必须重新拿给用户/客户确认。"
            )

    planning.VIEWS_DIR.mkdir(parents=True, exist_ok=True)
    written = _write_plan(plan)

    # 落盘时**代码自动清除**了不认这份数据的图（收尾清单 #8 加码）—— 报出来，别静默
    if written.get("removed_figures"):
        warnings.append(
            "已自动清除**不认这份数据**的图（移进 views/archive/）："
            + "；".join(written["removed_figures"])
            + "。要拿去让用户确认，请**按当前数据重画一张**（图内写明几何指纹 "
            + f"{plan['confirmation']['plan_hash'][:10]}…）。"
        )
    if written.get("archived"):
        warnings.append(f"上一版 plan_v1.json 已留档：views/archive/{written['archived']}。")

    # --- 阶段二验收（2026-09-25）：落盘那一步已自动把这一版记进台账，这里只**现算**状态 ---
    # 「生图 = 阶段二结束」：数据落盘时通常图还没画，所以状态多半是 awaiting_figure ——
    # 这不是错误，是提醒"该出图了"（等 AI 画完，get_plan 会自己变成 awaiting_user）。
    acceptance = _acceptance_model(plan)
    if acceptance.state == "awaiting_figure":
        warnings.append(
            "**阶段二（数据部分）已结束，现在在【阶段二验收】的「等出图」**："
            "views/ 里还没有认这份数据的图 —— 拿 `data_path` 自己画一张，"
            f"图内写明几何指纹 {acceptance.plan_hash[:10]}…，再交付给用户"
            "（**没有图不许让用户确认**）。"
        )
        cs = acceptance.change_set if isinstance(acceptance.change_set, dict) else {}
        req = [str(x) for x in (cs.get("required_labels") or [])]
        if cs.get("local"):
            warnings.append(
                f"**这一轮是局部一轮**（基线：{cs.get('baseline')}）：新增 {len(cs.get('added') or [])} / "
                f"改动 {len(cs.get('changed') or [])} / 删除 {len(cs.get('removed') or [])} —— "
                f"图里**只要**出现这 {len(req)} 行："
                + "、".join(req[:8]) + ("…" if len(req) > 8 else "")
                + f"；另外 {cs.get('same')} 行**没动、不必重画**（用户要求：局部改就全局部）。"
                  "要画哪些行也可以跑 `python -m mcp_server.planning.plan --figure-checklist`。"
            )
        else:
            warnings.append(
                "**还没有『确认过的基线』** → 这一版按**全量**画：图里要出现**每一行**的 label"
                f"（共 {len(req)} 行），一行都不能漏。"
            )
    elif acceptance.state == "awaiting_user":
        warnings.append(
            "**阶段二已结束，现在在【阶段二验收】：图与数据一致，可以交付给用户了**"
            "（图：" + "、".join(acceptance.figures) + "）。"
            "⚠ 交付方式：把图做成**用户能点开的卡片**、附一张验收清单，然后**停下等他打字** —— "
            "不要往问题框里塞「确认吗」。"
        )

    return PlanResult(
        stage="阶段二 · 平面放置规划",
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=_summarize(plan),
        gate=_gate_model(planning.gate_check(plan)),
        acceptance=acceptance,
        changed_params=world_changed,
        next_step=_stage2_next_step(plan, acceptance, empty=empty),
        warnings=warnings,
    )


# --- [完工-11] 工具 8：get_plan（阶段二 · 读）---
# ⚠ 2026-09-25：本工具**不再报自检**（用户指令，11 项自检 + `build_checks()` 整段删除）——
#   下面的实测记录如实保留，但不再描述当前行为。
# 实测 2026-09-23（重启后经 MCP 调用）：has_plan=true、自检 14 项 0 失败、
# gate.confirmed=false（闸门正确拦着）；预检 ⑤ 绿。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：工具面 9 个、本工具在链上正常。
# ⚠ 2026-09-24（三、四）改过本块逻辑与文案（闸门只剩几何指纹一道；不再有图；新增 status 判断
#   `initialized` / `draft` / `confirmed`）。其中 **status=initialized 那条分支尚未实测**。
# ⚠ 2026-09-24（五）更正本工具参数说明书里残留的旧口径（原先写着「这份几何只是等宽骨架 /
#   地块按固定面宽等宽剖分」—— 那套几何已删除，本数据是放置表）。**纯注释，不影响行为**。
# ✅ 2026-09-24（八）实测（新代码上线后经 MCP 调用观察到）：
#   · 三值由本工具**现算**：文件里已经**不写 `status`**，本工具照样报 draft / initialized；
#   · 真数据上跑通 `checks_total=11 / failed=0`（比旧版多 4 项：对账三条 + cube 高度）；
#   · 新增的"图认不认这份数据"告警生效：当前那张图内写有当前指纹前 10 位 → **不报警**；
#     初始化态按设计跳过图检查（不喊）。

# --- 工具 8：取规划（阶段二 · 读）----------------------------------------------

@mcp.tool()
async def get_plan(
    include_plan: Annotated[
        bool, Field(description="true = 连完整计划数据一起带出（默认）；false = 只给闸门状态与摘要")
    ] = True,
) -> PlanStatus:
    """取当前规划几何 + 判定**它还作不作数**。**动第三阶段之前必须先调它。**

    回答三件事：
      ① 有没有算过规划；
      ② **确认了没有**；
      ③ 确认之后**几何改过没有**（几何指纹对不对得上 —— 唯一那道闸）。
      （④ 老版还问"几何自检过没过" —— **2026-09-25 起没有自检了**，见下。）
      （⑤ 更老那版还问"几何是否只来自参数、不读那张 PNG" —— 现在没图了，这条自动成立。）

    ⚠ **阶段二不再自检**（2026-09-25 用户指令：「阶段二不要这个自检阶段了，后面阶段再做自检」）：
      原来那 11 项具名自检连同 `build_checks()` 已整段删除，`plan_v1.json` 不再写 `checks`，
      本工具的摘要里也不再报 `checks_failed` / `failed_names`。**碰撞检测与布局修正归第四阶段**。
      旧 `plan_v1.json` 里残留的 `checks` 字段会被**忽略**（不再是判定依据）。

    ⚠ **这份数据是「平面放置表」，不是几何骨架**（2026-09-24 用户重定义）：世界中心 / 大小
      + `assets[]`（已有资产，占地 = 阶段一实测包围盒 × `scale`）+ `whiteboxes[]`（白膜占位，
      占地要等资产占完位在剩余空间里重估），**一个物体一行、每行自带 `pos`**；
      旧版那套路网 / 地块 / 绿化区 / 禁放区的写死几何**已整段删除**，本数据里没有它们的字段。
    ⚠ `status` 三个取值：`initialized`（两张表都空 —— 一份坐标都没有，谈不上确认）/
      `draft`（有内容、还没确认过）/ `confirmed`（闸门放行）。
    ⚠ 客户说「宽窄不一 / 间距不匀 / 错落」时：**那不在阶段二里**（属阶段三的资产尺寸差异 +
      ±5° 抖动、阶段四的换小一号户型 / 微调边界，**这两个阶段都还没实现**），
      **照实说明，别拿「改参数」糊弄**（「错落」没有任何参数能表达）。

    ⚠ **开场先查状态**：任何「走到哪了 / 下一步干什么 / 怎么搭」的回答**之前**先调本工具
      （与 get_asset_list 配套）。
    ⚠ **只读**（**不改几何、不确认、不猜**）—— 唯一例外：它会在**验收台账**里记一条
      「这一版你回读过了」，用来放行**回读闸**（见 `_readback_guard()`）。它**不碰 UE、
      不改 `plan_v1.json`**，所以不会让任何确认作废。
    ⚠ **调本工具 = 回读**：写盘之后不调它，`generate_plan` 与 `execute_build` 都会被拒收。
    ⚠ `gate.confirmed = false` → **一律不许进第三阶段**（AGENTS.md「规划图闸门」）。
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        return PlanStatus(
            has_plan=False,
            next_step=(
                "还没算过规划：先 generate_plan() 算一版，再让用户/客户过目确认。"
                "**没有确认过的规划之前，不许往关卡里摆任何东西。**"
            ),
            warnings=["views/plan_v1.json 不存在。"],
        )

    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    gate = _gate_model(planning.gate_check(plan))
    summary = _summarize(plan)
    status = str(plan.get("status") or ("initialized" if not (
        plan.get("assets") or plan.get("whiteboxes")) else "draft"))
    if gate.confirmed:
        status = "confirmed"

    warnings: list[str] = []
    if status == "initialized":
        warnings.append(
            "**这是初始化状态**（`assets` / `whiteboxes` 都是空的）—— 结构立好了，"
            "但**一份坐标都没有**：坐标的依据（参考图）还没来。此时谈不上确认，也不许进第三阶段。"
        )
    if not gate.confirmed:
        warnings.append("这份规划**还没被确认** —— 不许进第三阶段。")
    if not gate.plan_hash_ok:
        warnings.append("plan_v1.json 的数据被手改过，与写进去时不一致 —— 这份规划作废。")
    # ⚠ 2026-09-25：这里原来会报「自检有 N 项没过」—— 阶段二自检整段删除（用户指令），
    #   碰撞检测与布局修正归第四阶段。旧 plan_v1.json 里残留的 `checks` 字段不再被读。
    # 图与数据一致吗（收尾清单 #8）—— 空规划阶段不谈图，不喊
    if status != "initialized":
        try:
            fig = planning.figure_check(plan)
        except Exception as exc:        # noqa: BLE001 —— 图检查失败不该把读工具带崩
            warnings.append(f"图检查没跑成（{type(exc).__name__}: {exc}）。")
        else:
            if not fig["ok"]:
                warnings.append(
                    "⚠ 图不认这份数据：" + fig["note"]
                    + "（AGENTS：图与数据不一致 = 等于没确认；确认时会被拒。）"
                )

    # --- 「改完必须回读」：**看过就算回读**（这是那道闸唯一的清除途径，见 _readback_guard）------
    # ⚠ 本工具仍然**不碰 UE、不改 plan_v1.json**；它只往验收台账记一条「你回读过了」。
    cleared: dict = {}
    try:
        cleared = planning.mark_readback()
    except Exception as exc:        # noqa: BLE001 —— 台账写不动不该把读工具带崩
        warnings.append(
            f"⚠ 没能在台账里记下「这一次回读」（{type(exc).__name__}: {exc}）—— "
            "回读闸可能还会拦你一次。")
    if cleared:
        cs0 = cleared.get("change_set") if isinstance(cleared.get("change_set"), dict) else {}
        parts: list[str] = []
        for key, word in (("added", "新增"), ("changed", "改动"), ("removed", "删除")):
            vals = cs0.get(key) or []
            if vals:
                parts.append(f"{word} {len(vals)}：" + "、".join(str(x) for x in vals[:6]))
        warnings.append(
            "✅ 已记下「你回读过这一版」（回读闸放行；指纹 "
            + str(cleared.get("plan_hash") or "")[:10] + "…）。"
            + ("该版变化：" + "；".join(parts) + "。" if parts else "")
            + " ⚠ 请逐行核对：**你预期的改动与上面这几行一致吗？**不一致就先查，别接着往下做。"
        )

    # --- 阶段二验收（2026-09-25）：状态**现算**，不读台账里那个旧快照 ---------------
    # 为什么：图常常是"落盘之后"才画好的，读快照就会拿着「等出图」的旧字样回答「走到哪了」。
    acceptance = _acceptance_model(plan)
    if acceptance.state == "changes_requested":
        warnings.append(
            "**用户在【阶段二验收】提了要改的地方**（还没落到数据里）："
            + "；".join(acceptance.pending_changes)
            + "。改完 `pos` / `footprint_m` / `scale` 再调 `generate_plan`"
            "（几何一变自动进新一轮、上一版自动留档）。"
        )
    elif acceptance.state == "awaiting_user":
        warnings.append(
            "**阶段二已结束，现在在【阶段二验收】：图与数据一致，该交付给用户了**"
            "（图：" + "、".join(acceptance.figures) + "）。"
            "交付后**停下等他打字** —— 他说改哪儿就调 `request_plan_change`，他说行就 `confirm_plan`。"
        )
    elif acceptance.state == "awaiting_figure":
        cs = acceptance.change_set if isinstance(acceptance.change_set, dict) else {}
        if cs.get("note"):
            warnings.append("⚠ **还在等出图** —— " + str(cs["note"]))
    elif acceptance.state == "accepted":
        warnings.append(
            "**阶段二验收已通过**（台账 `views/acceptance.json` 有留痕）—— 可以进第三阶段了。"
            "⚠ 第三阶段**第一步是只读检查**：先调 `check_build_target()` 问清搭哪儿，"
            "**拿到用户答复之前不许往关卡里放任何东西**；"
            "第二步是批量搭建：`generate_build_orders()`（翻指令表）→ `execute_build()`"
            "（整批校验 → 清 `UEMCP/` 旧 Actor → 一次性全落 → 读回对账），想先看就传 `dry_run=true`。"
            "⚠ 落关卡前会先过**回读闸**：这一版若还没 `get_plan()` 过，`execute_build` 会拒收 —— "
            "先看一眼再搭。"
        )

    ok = (status != "initialized") and gate.confirmed and gate.plan_hash_ok
    return PlanStatus(
        has_plan=True,
        status=status,
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=summary,
        gate=gate,
        acceptance=acceptance,
        plan=plan if include_plan else None,
        next_step=_stage2_next_step(plan, acceptance, empty=(status == "initialized")),
        warnings=warnings,
    )


# --- 工具 10：request_plan_change（阶段二验收 · 记「用户要改什么」）-------------
# 为什么要有它（2026-09-25 用户要求新增）：
#   原来的工具面里**只有"确认"这一条路** —— 用户在验收阶段说「第 3 栋往左 5 m」，
#   这句话只能留在对话里：会话一长就翻不到，换个 agent 就彻底丢了。
#   本工具把它**落进验收台账**（views/acceptance.json），状态变 `changes_requested`，
#   于是"用户说了什么"和"数据变成什么"两件事各自留痕、事后对得上账。
# ⚠ 它**不改几何、不进指纹**：用户提的是**要求**，不是坐标 —— 改坐标是 generate_plan 的事。

@mcp.tool()
async def request_plan_change(
    items: Annotated[
        list[str],
        Field(description=(
            "用户看图后提出要改的地方，**一条一项、尽量用他的原话**"
            "（如「左侧第 3 栋往 -X 挪 5 m」「树再密一点」「车只要 5 辆」）。至少一条。"
        )),
    ],
    by: Annotated[str, Field(description="谁提的（用户 / 客户的称呼，必填）")] = "用户",
    reason: Annotated[
        str, Field(description="为什么改 / 上下文（选填；能记原话就记原话）")
    ] = "",
) -> PlanResult:
    """记下「用户在 **阶段二验收** 提出要改的地方」—— 验收阶段的入口之一。

    用在哪：`get_plan().acceptance.state == "awaiting_user"` 时，你把图**交付成卡片**给用户
    然后停下；他看完说「这里要改」→ 调本工具把**他要改的点**记下来（别只留在对话里）。

    记完会发生什么：
      · 台账 `views/acceptance.json` 多一条 `change_requested`（带**当时那一版的几何指纹**）；
      · `acceptance.state` → `changes_requested`，`pending_changes` 就是这些条目；
      · 你按条目改 `pos` / `footprint_m` / `scale` → 重调 `generate_plan`
        （**几何指纹一变 = 自动进新一轮**，上一版自动留档）→ **重画图**（图内写新指纹）
        → 再把图交付给用户。**循环到他说无误为止**，那时才 `confirm_plan`。

    ⚠ 本工具**不改几何**：它只记「要求」；改坐标是 `generate_plan` 的事。
    ⚠ 不许拿它当"确认"用 —— 它只会让状态**更远离**验收通过。
    ⚠ **它是「改动窗口」的钥匙（2026-09-26 起，代码硬拦）**：一份规划**被确认过之后**，
      要再改内容**必须先走本工具** —— 否则 `generate_plan` 直接拒收（一个字节都不写）。
      窗口一直开到下一次 `confirm_plan()`，所以一轮里可以连着改好几次。
      ⚠ **自查修正也要记**（`by="agent 自查"`，`items=["自查：…"]`）——
      要的不是"等用户开口"，是留下「**改什么 / 谁要的**」这层对应关系，
      好让台账事后答得了「用户说了什么 ↔ 数据变成什么」。
      （客户 agent 交付后自评原话：「用户提改动要调 request_plan_change —— **一次都没调过**，
      你每次说要改，我直接 patch，没走变更台账」。）
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        raise ToolError("还没有规划数据：先 generate_plan() 记一版、出图给用户看过，再记改动。")

    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    if not (plan.get("assets") or plan.get("whiteboxes")):
        raise ToolError(
            "拒绝记录：这是**初始化状态**（`assets` / `whiteboxes` 都空）—— "
            "还没有任何坐标可看，用户也没法提改动。先按参考图规划 `pos` 并落盘。"
        )
    clean = [str(x).strip() for x in (items or []) if str(x).strip()]
    if not clean:
        raise ToolError("至少要给一条**具体**的改动要求（用户原话最好）；空条目等于没记。")

    planning.record_change_request(plan, clean, by=by, reason=reason)
    acceptance = _acceptance_model(plan)
    return PlanResult(
        stage="阶段二 · 平面放置规划",
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=_summarize(plan),
        gate=_gate_model(planning.gate_check(plan)),
        acceptance=acceptance,
        changed_params=[],
        next_step=_stage2_next_step(plan, acceptance),
        warnings=[
            f"已把 {len(clean)} 条改动记进验收台账（`views/acceptance.json`）—— "
            "**几何一个字节没动**（用户提的是要求，不是坐标）。",
            "下一步：按这些条目改 `pos` / `footprint_m` / `scale` → 重调 `generate_plan` "
            "→ **重画图（图内写新指纹）** → 再把图交付给用户，循环到他说无误为止。",
        ],
    )


# --- [完工-13] 工具 9：confirm_plan（阶段二 · 闸门）---
# 实测 2026-09-23T13:56:45Z（经 MCP 调用，用户本人确认）：
# gate.confirmed=true、confirmed_by="用户本人"、指纹一致、
# next_step 写出"阶段二闭环 —— 可以进第三阶段"；
# 并已核实写进了磁盘（plan_v1.json 的 confirmation 段）。
# 这一条是用真实确认验的，不是伪造的 —— 闸门的意义就在于没人能绕过它。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**）：工具面 9 个、本工具在链上正常。
# ✅ 2026-09-24（六）实测：新增的"**空规划拒收**"一条已验 ——
#   空结构（generate_plan() 不带参数 → status=initialized、两张表都空）落盘后，
#   调本工具 confirm_plan("验收探针") → 被 ToolError 拒（原文：「拒绝确认：这是**初始化状态**
#   （`assets` / `whiteboxes` 都空、一份坐标都没有）…」）；
#   拒收后 plan_v1.json **未被写**（get_plan 复查 plan_hash 未变、confirmed 仍 false），
#   且用**同一份 payload** 重跑 generate_plan 后几何指纹逐位回到探针前的值（6674990729…）。
# ⚠ 2026-09-24（八）本块改了：新增**第三条闸**（图不认这份数据 → 拒收）+ 确认落盘改走
#   `write_plan()`（确认前那一版自动留档、不认账的图自动清走）+ 空规划判据简化为"两张表都空"。
#   **尚未实测** —— 改完之后**没有确认过任何一版**，第一次真确认（用户看图画押）时补证据。

# --- 工具 9：确认规划（阶段二 · 闸门）------------------------------------------

@mcp.tool()
async def confirm_plan(
    confirmed_by: Annotated[str, Field(description="谁确认的（用户/客户的称呼，必填）")],
    user_quote: Annotated[str, Field(
        description=(
            "**用户点头的原话（必填）**：他看过图之后回你的那句，如「行」「可以，就这样」「没问题」。"
            "⚠ 这是**唯一**能证明「人看过了」的东西 —— 图是你画的、确认是你调的，"
            "光有 `confirmed_by` 证明不了有人点过头。**不许自己编**：拿不出原话，就说明你还没问过他。"
        ))],
) -> PlanResult:
    """把「这份规划被确认了」写回 `plan_v1.json`：**谁 / 何时 / 哪一版 / 用户的哪句话**。

    闸门不过就**拒绝确认**（这就是闸门的意义）：
      ① **空规划不许确认**（两张表都空：一份坐标都没有，确认它毫无意义）；
      ② 数据指纹对不上 → `plan_v1.json` 被手改过，与写进去时不一致；
      ③ **图不认这份数据**（`views/` 里没有图 / 图里没有当前几何指纹 / 图没覆盖该覆盖的行）——
         AGENTS：图与数据不一致 = 等于没确认。图由 AI 手绘，**画完把当前指纹写进图里**；
      ④ **证据链**（2026-09-26 加，堵最大的那个洞）：必须给 `user_quote`（用户原话），
         且那张图**出炉至少 `MIN_CONFIRM_DELAY_S` 秒** —— 画完就自己确认 = 没人看过。

    **局部确认（2026-09-26 用户要求：「用户想局部改，所有都局部改，不要全部重做」）**：
    这一版相对**上一次确认过的基线**（验收台账里的 `accepted_rows`）只要改了 N 行，
    图里就**只需**出现那 N 行的 label —— 没动的行不必重画，整张图也不用重做。
    覆盖是**传递**的：第一版全量画过，之后每轮只画改动过的行，并起来就是每一行。
    ⚠ 第一次搭（还没有基线）时仍是**全量**：图里要出现每一行。
    ⚠ 确认成功时会把**这一版的逐行几何签名**记进台账 —— 它就是下一轮算变更集的基线。

    ⚠ 确认是**人的动作**：只有用户/客户**看过图并点头**之后，才准调它。
      你自己看着"差不多"就确认 = 把闸门作废（实测被这么绕过一次，客户当场质问"图都不先让我确认就摆"）。
    ⚠ **必须先给用户看图** —— 他读不懂坐标，图是他唯一能判断的依据。
    ⚠ 确认之后坐标一改，指纹就对不上，本次确认**自动作废**。
    ⚠ 落盘走 `planning.write_plan()`：确认前的那一版会**自动留档**到 `views/archive/`；
      **不认这份数据的图会被代码自动清除**（也移进 `views/archive/`）—— 图这件事不许靠人记得。
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        raise ToolError("还没有规划数据：先 generate_plan() 记一版，让用户过目之后再确认。")

    quote = str(user_quote or "").strip()
    if len(quote) < 1:
        raise ToolError(
            "拒绝确认：**没给 `user_quote`（用户点头的原话）**。\n"
            "· 图是你画的、确认是你调的 —— 光写 `confirmed_by=\"用户\"` 证明不了有人看过。\n"
            "· 正确顺序：**把图交付成用户能点开的卡片 → 停下等他打字 → 把他的原话填进 `user_quote`**。\n"
            "· 他还没回话，就先别确认（也不许接着搭建）。"
        )

    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    if not (plan.get("assets") or plan.get("whiteboxes")):
        raise ToolError(
            "拒绝确认：这是**初始化状态**（`assets` / `whiteboxes` 都空、一份坐标都没有）。"
            "先把放置表填上（先已有资产、后白膜），出图给用户看过，再确认。"
        )
    gate = planning.gate_check(plan)
    if not gate["plan_hash_ok"]:
        raise ToolError("拒绝确认：plan_v1.json 的数据与写进去时不一致（被改过）。")

    # --- ⚠ 图与数据必须一致（2026-09-24 收尾清单 #8；2026-09-25 加严；2026-09-26 改为按变更集）---
    # 判据在 planning.figure_check()：views/ 里要有图，且图认这份数据 ——
    #   **svg**：正文里要有当前几何指纹前 10 位，**且覆盖"这一轮该覆盖的行"**
    #   （有基线 = 本次改动的那几行；第一次搭 = 全部行）；**位图**一律不认账。
    fig = planning.figure_check(plan)
    if not fig["ok"]:
        if fig.get("local"):
            raise ToolError(
                "拒绝确认：图不认这份数据 —— " + fig["note"]
                + " 这是**局部一轮**：拿 views/plan_v1.json 重画一张（图内写明当前几何指纹，"
                  "**且把本次改动的那几行都画进去** —— 共 "
                  + str(len(fig.get("required_labels") or [])) + " 行），没动的行不必重画。"
                  "要画哪些行可跑：python -m mcp_server.planning.plan --figure-checklist"
            )
        raise ToolError(
            "拒绝确认：图不认这份数据 —— " + fig["note"]
            + " 请拿 views/plan_v1.json 重画一张（**图内写明当前几何指纹，"
              "且每一行的 label 都要出现**），再确认。"
              "要画哪些行可跑：python -m mcp_server.planning.plan --figure-checklist"
        )

    # --- ⚠ 证据链：图出炉多久了？（防"画完立刻自己确认" = 没人看过）------------------
    fig_names = [str(x) for x in (planning.accepted_figures(plan) or [])]
    fig_name = fig_names[0] if fig_names else ""
    fig_age: float | None = None
    if fig_name:
        try:
            fig_age = (datetime.now(timezone.utc).timestamp()
                       - (planning.VIEWS_DIR / fig_name).stat().st_mtime)
        except OSError:
            fig_age = None
    if fig_age is not None and fig_age < MIN_CONFIRM_DELAY_S:
        raise ToolError(
            f"拒绝确认：认账的那张图（`{fig_name}`）是 **{fig_age:.0f} 秒前**才画好的 —— "
            f"用户不可能已经看过（这道下限是 {MIN_CONFIRM_DELAY_S:.0f} 秒）。\n"
            "正确顺序：**把图交付给用户（做成他能点开的卡片）→ 停下等他打字 → 带着他的原话回来**。\n"
            "（若你确实刚把图给过他、他也回话了，那就**等够时间再调本工具**。）"
        )

    plan = planning.mark_confirmed(plan, confirmed_by, quote)
    written = planning.write_plan(plan)
    notes: list[str] = [
        f"证据链已留痕：确认人 `{confirmed_by}` ｜ 用户原话「{quote}」"
        + (f" ｜ 图 `{fig_name}`（出炉 {fig_age:.0f} 秒）" if fig_age is not None else "")
        + "。"]
    # --- 阶段二验收台账：记「这一轮通过了」（2026-09-25 用户要求）---------------
    # 为什么 plan_v1.json 的 confirmation 之外还要记一份：confirmation 只说"确认了"，
    #   回答不了「这是第几轮 / 当时用户提过什么 / 验的是哪一版几何」—— 那些在台账里。
    try:
        planning.record_acceptance(plan, confirmed_by, user_quote=quote,
                                   figure=fig_name, figure_age_s=fig_age)
    except OSError as exc:
        notes.append(f"⚠ 验收台账没记上（{exc}）—— 规划数据已落盘，台账可以重记。")
    if written.get("archived"):
        notes.append(f"确认前的那一版已留档：views/archive/{written['archived']}。")
    if written.get("removed_figures"):
        notes.append("已清除不认这份数据的图（移进 views/archive/）："
                     + "；".join(written["removed_figures"]) + "。")
    acceptance = _acceptance_model(plan)
    return PlanResult(
        stage="阶段二 · 平面放置规划",
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=_summarize(plan),
        gate=_gate_model(planning.gate_check(plan)),
        acceptance=acceptance,
        changed_params=[],
        next_step=_stage2_next_step(plan, acceptance),
        warnings=notes,
    )


# --- 启动区 -------------------------------------------------------------------
# 只有"直接运行这个文件"时才启动；被 mcp dev / mcp run / 宿主导入时不启动。
if __name__ == "__main__":
    # 不带参数 = stdio（进程直连），由宿主负责启动这个进程
    mcp.run()

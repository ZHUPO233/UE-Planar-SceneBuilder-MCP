# 交接说明（接手这个工作区的 AI：DSH / 豆包都看这一份）

> 这份文件是**上一位 agent 写的交接**，不是项目规则。**项目规则只认 `AGENTS.md`**；
> 两者冲突时以 `AGENTS.md` 为准（也以用户当面的说法为准）。
> 包里的 `views/` 是**初始化状态**（比上一个包的 draft 更干净），见第 4 节。

## 0. 这是什么

一个 **MCP server（编排层）**，把"参考图 → 场景布局"拆成阶段一到阶段八，逐阶段闭环。
它自己**不碰 UE**：改关卡 / 摆 Actor / 改材质都要经**官方 Unreal MCP**（HTTP `127.0.0.1:8000`）那侧做。

- `src/mcp_server/main.py` —— MCP 工具面（9 个工具）。**宿主是按脚本方式起它的**：
  `python ...\src\mcp_server\main.py`（此时 `__package__` 为空，所以规划层只能**惰性导入**，
  见 `_planning_modules()` 里那段血账）。
- `src/mcp_server/planning/plan.py` —— 阶段二规划层（装配 + **11 项自检** + 闸门 + 落盘留档）。
- `catalog/` —— 阶段一**签过字的交付物**（`elements.json` / `asset_list.json` /
  `library_snapshot.json`）。**不要当"可再生的运行时状态"删掉或重生成**。
- `views/plan_v1.json` —— 阶段二的**平面放置表**（闸门认的就是它）。
- `docs/` —— **读的顺序：`AGENTS.md` → `docs/阶段一-资产确认.md` → `docs/阶段二-平面放置规划.md`
  → `docs/阶段二至八-全流程规划.md`。**

## 1. 先做的事：查状态，别先讲话

**讲流程、给方案、报进度之前，先调只读工具**：

- `get_plan()` —— 阶段二走到哪了（有没有数据 / 确认没有 / 几何改没改 / 自检过没过 / 图认不认数据）。
- `get_asset_list()` —— 阶段一那份清单还在不在、过没过期、路径还活不活。

**状态只认工具返回值**，不认文件里叙述性的旧措辞（文件里的话可能早已过期）。

## 2. 怎么跑（在 DSH 里）

```powershell
# ① 建环境（包里**没带 .venv**，自己建）
uv sync                     # 或： python -m venv .venv; .\.venv\Scripts\pip install -e .

# ② 把它注册成一个 stdio MCP server（DSH 的 mcp client 走 stdio）：
#    command = <仓库根>\.venv\Scripts\python.exe
#    args    = ["<仓库根>\src\mcp_server\main.py"]
#    （你机器上已有 `mine` 那条，照抄一份改路径即可；注册完重启会话）

# ③ 改完代码 → **重启前必跑预检**（它复现宿主的脚本方式启动，绿了才准重启）
& .\.venv\Scripts\python.exe tests\preflight.py; "exit=$LASTEXITCODE"

# ④ 阶段二现状（只读，需要 PYTHONPATH）
$env:PYTHONPATH="$PWD\src"; & .\.venv\Scripts\python.exe -m mcp_server.planning.plan
```

⚠ **预检 / 测试由人跑，不要自己跑**（`AGENTS.md`「执行纪律」）。你写完代码就交出来，
说清"改了哪几处 / 为什么 / 影响面"，然后停下。

## 3. 这个项目的硬规则（摘要，全文见 `AGENTS.md`）

- **不许猜**：资产名字对不上就是没找到 —— 请用户给【路径 + 名字】，不拿"疑似"顶替。
- **不许存盘**：不保存 UE 关卡 / 资产。
- **规划图闸门**：阶段二的放置表**必须经用户确认**才能进第三阶段；确认要落痕（谁 / 何时 / 哪一版）；
  几何一改，上一次确认**自动作废**。
- **图与数据必须一致**：要给人看就得有图（AI 拿 `plan_v1.json` **自己画**，**代码不出图**），
  图里写当前几何指纹；**图不认数据时 `confirm_plan` 会拒收**。
- **不许靠人记得**：能由代码兜住的事（世界大小自动回填阶段一、上一版自动留档、
  不认账的图自动清走）都写在代码里，不用你记。
- 单位：本 server 全用**米**；到 UE 那层才 ×100。

## 4. 打包时的状态（2026-09-24）

- **阶段二 = 初始化状态**：`views/plan_v1.json` 两张表都空（`assets: []` / `whiteboxes: []`）、
  世界取阶段一记的 `100×60 m`、**11 项自检 0 失败**、未确认。
- **阶段一保留着**（`catalog/` 三份都在）：那是**新参考图（夜间街道 · blue hour）**那次
  重做出来的、签过字的清单。它是阶段二的**输入** —— 所以**没有清空**。
  如果你想从零开始试一遍阶段一，就重新 `confirm_elements`（会覆盖）。
- **包里不含 `views/archive/`**：那是上一个 agent 的历史留档（含 1 份 `_confirmed` 与 6 份
  `_draft` 计划、5 张旧图），留在原工作区的 `views/archive/` 和 `backup-*/` 里。
- 接手后的第一步应该是：**拿到用户上传的图 → 走阶段一（提元素 → 用户逐条确认 → 找资产 →
  交付清单）→ 再按图规划 `pos`**（`generate_plan` 填表）。**别在没图的时候编坐标。**
- 阶段三及以后**尚未实现**（`docs/阶段二至八-全流程规划.md` 是原文要求，不是已完成的功能）。

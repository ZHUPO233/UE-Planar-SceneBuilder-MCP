# =============================================================================
# 重启前预检：验「能不能起来 / 规划层能不能导入 / 工具注册对不对 / 阶段二链通不通」
# —— **不启动 server**。
#
# 【为什么要有这个文件】（2026-09-23 两次真实事故，每次白花十几分钟重连）
#   ① `NameError: name 'FoundAsset' is not defined`
#      —— Python 里函数**签名上的注解**是在 def 执行那一刻求值的，定义顺序摆错就炸。
#   ② `ImportError: attempted relative import with no known parent package`
#      —— 宿主是按**脚本方式**起 main.py 的（`python ...\src\mcp_server\main.py`），
#         此时 `__package__` 为空，文件顶部的相对导入 `from .planning import ...` 必然失败。
#   ⚠ ② 之所以漏网，是因为当时的预检用 `import mcp_server.main`（**模块方式**）跑，
#     **没有复现宿主的启动方式**，于是给了个假绿。所以本脚本第一条就是复现它。
#
# 【怎么跑】
#   & F:\MCP_Server\.venv\Scripts\python.exe tests\preflight.py
#   退出码 0 = 全绿 → 可以重启；非 0 = **别重启**，先修。
# =============================================================================

import asyncio
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN_PY = ROOT / "src" / "mcp_server" / "main.py"

# 当前应有的工具（改动工具面时**必须同步这里和 tests/check_tools.py**）
EXPECTED_TOOLS = [
    "confirm_assets", "confirm_elements", "confirm_plan",
    "generate_plan", "get_asset_list", "get_plan",
    "official_status", "plan_assets", "rename_assets",
]

FAILED: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    """打印一条结果。⚠ 细节只在**失败**时打印 —— 那些文案是"失败原因"，
    挂在绿行上会自相矛盾（实测踩过：`[通过] … PNG 没生成`）。"""
    line = f"[{'通过' if ok else '失败'}] {name}"
    if not ok and detail:
        line += f"   {detail}"
    print(line)
    if not ok:
        FAILED.append(name)


def main() -> int:
    # --- ① 按**脚本方式**执行 main.py：复现宿主的启动方式，但不会启动 server ---
    # run_name 不是 "__main__"，所以文件末尾那句 `if __name__ == "__main__": mcp.run()` 不触发。
    # ⚠ 忠实复现：`python ...\main.py` 时 CPython 会把**脚本所在目录**放进 sys.path[0]，
    #   而 runpy.run_path **不会**。所以这里手动补上，否则预检会比真实启动更严（假红）。
    script_dir = str(MAIN_PY.parent)
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)
    try:
        mod = runpy.run_path(str(MAIN_PY), run_name="not_main")
        check("① main.py 能按【脚本方式】执行（宿主就是这么起它的）", True)
    except BaseException as exc:                      # BaseException：连 CancelledError 也接住
        check("① main.py 能按【脚本方式】执行（宿主就是这么起它的）", False,
              f"{type(exc).__name__}: {exc}")
        print("\n**别重启**：先把这个错修掉 —— 它会让整个 server 起不来。")
        return 1

    # --- ② 把阶段二的**惰性导入**也走一遍（上次就是这条路径没被走到） ---
    try:
        planning = mod["_planning_modules"]()
        check("② 规划层惰性导入成功", True)
        print(f"        plan = {planning.__name__}")
    except BaseException as exc:
        check("② 规划层惰性导入成功", False, f"{type(exc).__name__}: {exc}")
        print("\n**别重启**：阶段二工具会报错（阶段一还能用，但不该带病上）。")
        return 1

    # --- ③ 工具注册：个数和名字都要对 ---
    result = mod["mcp"].list_tools()
    if hasattr(result, "__await__"):                  # 这个 SDK 有时返回协程
        result = asyncio.run(result)
    names = sorted(t.name for t in getattr(result, "tools", result))
    check("③ 注册的工具与预期一致", names == EXPECTED_TOOLS, f"实际={names}")
    print(f"        {names}")

    # --- ④ 阶段二那条链：装配 + 自检（全在内存里算，不碰 views/）---
    # ⚠ 2026-09-24（四）**按用户新规格换过**：阶段二只记「元素放置」——
    #   world（中心/大小）+ assets[]（已有资产）+ whiteboxes[]（白膜），**一物一行**。
    #   这里拿两个**假**物体走一遍，验的是"装配 + 自检 + 指纹"这条链，不碰真数据。
    try:
        world = {
            "center": [0.0, 0.0], "size": [100.0, 40.0], "size_source": "预检",
            "bounds": {"min": [-50.0, -20.0], "max": [50.0, 20.0]},
            "coordinate_system": {"handedness": "left"},
        }
        ok_assets = [{"element_key": "building_fake", "label": "假楼",
                      "asset_path": "/Game/Fake", "pos": [0.0, 0.0],
                      "footprint_m": [10.0, 8.0], "rot_deg": 0.0, "scale": 1.0, "note": ""}]
        ok_boxes = [{"element_key": "road_fake", "label": "假路", "shape": "plane",
                     "pos": [0.0, -15.0], "footprint_m": [90.0, 6.0], "rot_deg": 0.0,
                     "size_source": "预估（预检）", "note": ""}]
        plan = planning.build_plan(ok_assets, ok_boxes, world)
        bad = [c.get("name", "?") for c in plan.get("checks", []) if not c.get("ok")]
        check("④ 阶段二放置自检全过（含'白膜不压资产'）", not bad, f"没过的={bad}")

        # 反例：白膜压在资产身上 → 那条自检必须**报坏**
        bad_box = [dict(ok_boxes[0], pos=[0.0, 0.0])]
        plan_bad = planning.build_plan(ok_assets, bad_box, world)
        hit = [c for c in plan_bad["checks"]
               if c.get("name", "").startswith("白膜不压已有资产")]
        check("④b 白膜压到资产时自检会报坏（自检不是摆设）",
              bool(hit) and not hit[0].get("ok"), f"实际={hit}")

        # --- ④c 反例：占地与"阶段一实测 × scale"对不上 → 第⑧项必须报坏 ---
        # ⚠ 2026-09-24（八）新增。为什么值得加：⑧⑨⑩ 是**阶段一↔阶段二的对账**，
        #   而预检以前只走"没传实测尺寸 → 标没验"那支 —— **"该报红"的分支一次都没被验过**。
        #   这里给一份假的实测尺寸（1.0×1.0 m），而放置表填的是 20×16 m → 必须报坏。
        bad_size = [dict(ok_assets[0], footprint_m=[20.0, 16.0])]
        plan_size = planning.build_plan(
            bad_size, [], world, known={"building_fake"}, no_asset=set(),
            expected={"/Game/Fake": (1.0, 1.0)}, asset_keys={"building_fake"},
            measured_ok=True, measured_note="预检（假数据）")
        hit8 = [c for c in plan_size["checks"]
                if c.get("name", "").startswith("已有资产占地")]
        check("④c 占地与实测×scale 对不上时自检会报坏",
              bool(hit8) and not hit8[0].get("ok"), f"实际={hit8}")

        # --- ④d 反例：白膜 cube 没记高度 → 第⑪项必须报坏 ---
        #   （阶段六要用 height_m 把 cube 实例化出来；缺了不许静默放过）
        bad_cube = [{"element_key": "shelter_fake", "label": "假亭", "shape": "cube",
                     "pos": [0.0, -15.0], "footprint_m": [5.0, 1.5], "rot_deg": 0.0,
                     "size_source": "预估（预检）", "note": ""}]
        plan_cube = planning.build_plan(
            [], bad_cube, world, known={"shelter_fake"}, no_asset={"shelter_fake"})
        hit11 = [c for c in plan_cube["checks"]
                 if c.get("name", "").startswith("白膜里的 cube")]
        check("④d cube 白膜缺 height_m 时自检会报坏",
              bool(hit11) and not hit11[0].get("ok"), f"实际={hit11}")

        # --- ④e 初始化态：两张表都空时，覆盖类对账必须标"不适用"、不许报红 ---
        #   （这就是"初始化后别又用不了了"的回归：空跑一次必须 0 失败）
        plan_empty = planning.build_plan(
            [], [], world, known={"building_fake"}, no_asset={"road_fake"},
            expected={"/Game/Fake": (1.0, 1.0)}, asset_keys={"building_fake"},
            measured_ok=True, measured_note="预检（假数据）")
        empty_bad = [c.get("name", "?") for c in plan_empty["checks"] if not c.get("ok")]
        cover = [c for c in plan_empty["checks"]
                 if c.get("name", "").startswith(("交付清单里", "阶段一判成"))]
        check("④e 两张表都空时覆盖类自检标『不适用』、不报红",
              not empty_bad and len(cover) == 2 and all(c.get("ok") for c in cover)
              and all("不适用" in (c.get("note") or "") for c in cover),
              f"没过的={empty_bad} 覆盖类={cover}")

        # --- ⑤ 闸门指纹自洽：刚算出来的数据，不该被判成"被手改过" ---
        # ⚠ 这是 2026-09-23 经 MCP 实测抓到的 bug 的回归检查：
        #   内存对象带 -0.0、落盘的是净化后的 0.0，两边哈希就会不等，
        #   于是对着刚算出的数据喊"文件被改过"。指纹计算必须内部净化。
        gate = planning.gate_check(plan)
        check("⑤ 闸门指纹自洽（刚算出的数据不该被判成'被改过'）",
              bool(gate["plan_hash_ok"]), f"gate={gate}")
    except BaseException as exc:
        check("④ / ⑤ 阶段二装配、自检与闸门指纹能跑通", False,
              f"{type(exc).__name__}: {exc}")

    print()
    if FAILED:
        print(f"预检没过（{len(FAILED)} 项）：{FAILED}")
        print("**别重启**：先修。")
        return 1
    print("预检全绿：可以重启。")
    return 0


if __name__ == "__main__":
    sys.exit(main())

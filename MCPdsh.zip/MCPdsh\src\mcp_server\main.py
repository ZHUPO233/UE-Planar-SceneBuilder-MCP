# =============================================================================
# 本 server 是编排层，自己不碰 UE：
#   宿主(agent) → 本 server → 官方 Unreal MCP（HTTP 127.0.0.1:8000）→ UE 编辑器
#
# 阶段一流程由用户定义、不许改（原文见 docs/阶段一-资产确认.md）：
#   ① 根据上传图片提取所需资产 → 让用户确认
#   ② 寻找资产：名字对得上就是找到了
#   ③ 没找到 → 禁止寻找疑似的，直接告知用户缺少什么资产
#   ④ 要求用户把"存在但是 agent 没找到"的资产的【路径 + 名字】告诉 agent
#   ⑤ 让 agent 重命名
#   ⑥ 确认资产列表，并向用户确认 → 交付资产清单
#
# 为什么"禁止猜"是硬规则：我给"名字是否规范"做过两版判据，两版都在实测里误报
#   （v1 长度+字符集、v2 连续辅音 ≥4）。根因是没有词典时，随机哈希和英文单词拼接
#   在字符层面无法区分。既然猜不准，就不猜 —— 用户指路，模型改名。
#
# 为什么必须支持"按文件夹名找"：官方 find_assets 的名字过滤只匹配资产名、
#   不匹配文件夹名（实测），哈希名资产（MI_sjfnch0a）靠资产名永远搜不到。
# =============================================================================

import hashlib
import json
import logging
import math
import re
import sys
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any

import anyio
from pydantic import BaseModel, Field

from mcp import Client
from mcp.server import MCPServer
from mcp.server.mcpserver import Context
from mcp.server.mcpserver.exceptions import ToolError

# 阶段二·规划层不能在文件顶部 import —— 见 _planning_modules() 里的血账说明：
#   宿主是按脚本方式起本文件（python ...\src\mcp_server\main.py），此时相对导入
#   `from .planning import ...` 会抛 "attempted relative import with no known parent package"。

# --- 常量 ---------------------------------------------------------------------

OFFICIAL_URL = "http://127.0.0.1:8000/mcp"

# 状态文件目录：项目根目录下的 catalog/（parents[0]=mcp_server, [1]=src, [2]=项目根）
STATE_DIR = Path(__file__).resolve().parents[2] / "catalog"
ELEMENTS_PATH = STATE_DIR / "elements.json"       # 用户确认过的元素清单
ASSET_LIST_PATH = STATE_DIR / "asset_list.json"   # 交付给用户的资产清单
LIBRARY_PATH = STATE_DIR / "library_snapshot.json"  # 资产库指纹（给清单"签字"用）

# 官方工具的"地址" = 工具集名 + 工具名
TS_ASSET = "editor_toolset.toolsets.asset.AssetTools"    # 找资产 / 改名 / 验证存在
TS_SCENE = "editor_toolset.toolsets.scene.SceneTools"    # 关卡信息

# 资产类别 → 官方的类路径（find_assets 的 asset_type 要的是类路径）
CLASS_PRESETS: dict[str, str] = {
    "mesh": "/Script/Engine.StaticMesh",
    "material": "/Script/Engine.Material",
    "material_instance": "/Script/Engine.MaterialInstanceConstant",
    "texture": "/Script/Engine.Texture2D",
}
DEFAULT_ASSET_TYPES = ["mesh", "material_instance", "material"]
SIZE_QUERY_TYPES = {"mesh"}


# --- [完工-01] 官方连接（由专用 task 持有，全程复用一条连接）---
# 实测 2026-09-23 12:07 起本会话持续服务：数十次官方调用，无 cancel-scope 崩溃。
#
# 为什么必须是"专用 task"（2026-09-23 实测定案，别改回去）：
#   `mcp.Client.__aenter__` 会把 streamable-http 传输压进一个 AsyncExitStack，
#   而这个传输内部会 `async with anyio.create_task_group()` —— 即进入一个取消域。
#   anyio 的铁律：取消域只能由进入它的那个 task 退出。旧写法在【工具调用的 task】里
#   建连接、却在【lifespan 的 task】里关，跨 task 退出必抛
#   RuntimeError: Attempted to exit a cancel scope that isn't the current tasks's
#   current cancel scope —— 它穿透 SDK 派发器的 task group，整个 server 进程退出。
#   修法：建和关都收进同一个 task（`_connection_loop`），取消域进出同源。
#   ⚠ 别再往 `asyncio.Lock` 上找：去掉锁之后它照样发生，真凶是上面这个"跨 task 关闭"。
#
RETRY_SECONDS = 3.0
"""连不上官方时的重试间隔（秒）。编辑器没开时会一直按这个间隔重试。"""

READY_TIMEOUT = 15.0
"""工具调用等"连接 task 首次表态"的上限（秒）；超时就抛 ToolError，而不是干等。"""


@dataclass
class AppContext:
    """服务器生命周期内共享的状态：一条官方连接 + 两个同步信号。

    所有权约定（**改这个文件时请守住**）：
      - `ue` 只有 `_connection_loop` 这一个 task 会写，其它 task 只读；
      - 谁都不许在工具调用的 task 里创建或关闭官方客户端 —— 那正是炸进程的原因。
    """

    ue: Any = None
    """官方 MCP 客户端。**只能由连接 task 创建和关闭**；工具调用只读它、用它发请求。"""

    ready: Any = None
    """连接 task 首次表态（连上 or 失败）后 set，让工具调用不必干等。"""

    stop: Any = None
    """要求连接 task 断开重连的信号。工具调用发现连接死了就 set 它。"""

    error: str = "尚未连上（连接 task 还在重试）"
    """最近一次连接失败的原因原文，拼进 ToolError 给用户看。"""


async def _connection_loop(app: AppContext) -> None:
    """专用连接 task：**唯一**允许创建/关闭官方客户端的地方。

    循环做三件事：
      ① 建连接（进入 `async with client`）；
      ② 把连接借出去 —— 挂在 `app.stop.wait()` 上不动；
      ③ 被要求重连（`app.stop` 被 set）或连不上时，退出 `async with`
         （**在同一个 task 里关**），歇一会儿回到 ①。

    ⚠ `app.stop` 每轮都换一个新的 `anyio.Event`：Event 一旦 set 就不会自动复位，
      不换的话第二轮会立刻又"被要求重连"，变成死循环。
    ⚠ `except Exception` 接不住 `CancelledError`（它是 `BaseException` 的子类）——
      这正是我们要的：关机时 task group 取消本 task，取消要能正常往外抛；
      而 `finally` 照样会执行。
    """
    log = logging.getLogger(__name__)
    while True:
        app.stop = anyio.Event()
        app.ue = None
        client = Client(OFFICIAL_URL)
        backoff = RETRY_SECONDS
        try:
            async with client:
                app.ue = client
                app.error = ""
                log.info("已连上官方 Unreal MCP：%s", OFFICIAL_URL)
                # 连上就**立刻**表态放行等待者，不能等退出 async with 才表态：
                # 下面要挂在这里把连接借出去、可能挂很久；若只在 finally 里 set，
                # 工具调用会一直等 ready 直到 READY_TIMEOUT 超时 —— 而日志里明明
                # 已经打了"已连上官方 Unreal MCP"（这个坑我实测踩到过）。
                if app.ready is not None:
                    app.ready.set()
                await app.stop.wait()
                backoff = 0.5
        except Exception as exc:
            app.error = f"{type(exc).__name__}: {exc}"
            log.warning("连不上官方 Unreal MCP（%s）：%s", OFFICIAL_URL, exc)
        finally:
            app.ue = None
            if app.ready is not None:
                app.ready.set()
        await anyio.sleep(backoff)


async def official_client(ctx: Context[AppContext]) -> Any:
    """取当前可用的官方客户端；没连上就抛 ToolError（给模型看人话，而不是崩栈）。

    连不上是**可预期**的（编辑器没开），所以这里一律转成 ToolError 原文说明，
    不把底层异常抛给协议层。
    """
    app = ctx.request_context.lifespan_context
    try:
        # 等连接 task 首次表态：server 刚起来时它可能还在握手，直接判失败会误报
        with anyio.fail_after(READY_TIMEOUT):
            await app.ready.wait()
    except TimeoutError:
        raise ToolError(
            f"等官方连接就绪超时（{READY_TIMEOUT:.0f} 秒）：{app.error or '连接仍无结果'}"
        ) from None
    if app.ue is None:
        raise ToolError(
            f"连不上官方 Unreal MCP（{OFFICIAL_URL}）："
            f"{app.error or '连接正在重建，请稍后重试'}。"
            f"请确认 ① UE 编辑器已打开 ② ModelContextProtocol 插件已启用 "
            f"③ 端口 8000 在监听。"
        )
    return app.ue


@asynccontextmanager
async def app_lifespan(server: MCPServer):
    """服务器启动时拉起连接 task，关闭时收回（不留孤儿 task）。

    ⚠ 两处必须"同源"，这是修复的全部要点：
      - task group 在**本 lifespan 的 task** 里进、也在本 task 里出；
      - 官方客户端的进/出都发生在**子 task**（`_connection_loop`）内部。
      两者互不越界，所以不会再出现"取消域跨 task 退出"的 RuntimeError。

    ⚠ 这里**不再吞异常**：旧版在 finally 里 `except BaseException` 把关闭连接的
      错误咽掉，结果只是把崩溃推迟到了 SDK 派发器的 task group（那里没人接），
      照样炸进程。现在关闭动作归连接 task 所有，它自己的收尾由 anyio 的
      task group 负责，不需要这里兜。
    """
    app = AppContext(ready=anyio.Event(), stop=anyio.Event())
    async with anyio.create_task_group() as tg:
        tg.start_soon(_connection_loop, app)
        try:
            yield app
        finally:
            tg.cancel_scope.cancel()


# 顺序很关键：app_lifespan 必须在 MCPServer(...) 之前定义；
# mcp 必须在任何 @mcp.tool() 之前存在（装饰器在"定义时"就执行）。
#
# 为什么没有 instructions=（2026-09-23 实测，别加回来）：本宿主不读 MCP 的
# instructions（dsh-mcp-client 的 connect() 返回值连赋值都没有）。
# 真正到模型眼前的是 tools/list（工具名 + 描述 + schema），
# 所以要求写在各工具的 docstring 里。
mcp = MCPServer("UEMCP-SceneLayout", lifespan=app_lifespan)


# --- [完工-02] 厚函数（纯逻辑，不碰网络，可直接单测）---
# 实测 2026-09-23 12:07–12:24：token_match / num / size_from_box / parse_return /
# to_object_path / load_json / save_json 经 plan_assets、confirm_assets 反复调用。

def parse_return(text: str) -> Any:
    """把官方返回的那段文本解析成 Python 对象。

    官方返回值包在 {"returnValue": ...} 里。解析失败就把原文当字符串返回 ——
    免得因为格式差异整个工具崩掉。
    """
    if not text:
        return None
    try:
        data = json.loads(text)
    except (ValueError, TypeError):
        return text
    if isinstance(data, dict) and "returnValue" in data:
        return data["returnValue"]
    return data


def to_object_path(package_path: str) -> str:
    """包路径 → 对象路径。

    官方有些接口不接受 "/Game/A/B/house1"，要 "/Game/A/B/house1.house1"
    （对象路径 = 包路径 + "." + 资产名）。这条是实测踩出来的。
    """
    name = package_path.rsplit("/", 1)[-1]
    return f"{package_path}.{name}"


def token_match(keyword: str, text: str) -> bool:
    """词边界匹配 —— 专门对冲官方"纯子串"的缺陷。

    官方 find_assets 的名字过滤是纯子串：搜 "Tree" 会命中 "s**tree**t_lamp_01_4k"（路灯）。
    这里把文本切成"词"（按 _ - 空格 以及小写转大写的边界切），
    要求关键词作为**一个完整的词**出现才认；也允许"词 + 数字后缀"（house → house1）。
    """
    kw = keyword.lower().strip()
    if not kw:
        return False

    words: list[str] = []
    for part in text.replace("-", "_").replace(" ", "_").split("_"):
        chunk = ""
        prev_lower = False
        for ch in part:
            if ch.isupper() and prev_lower:
                if chunk:
                    words.append(chunk)
                chunk = ch
            else:
                chunk += ch
            prev_lower = ch.islower()
        if chunk:
            words.append(chunk)

    for word in words:
        low = word.lower()
        if low == kw:
            return True
        # house → house1：允许关键词后面直接跟数字
        if low.startswith(kw) and low[len(kw):].isdigit():
            return True
    return False


def num(value: Any, digits: int = 2) -> float:
    """把官方给的数字变成"能安全穿过 JSON 的数字"。三件事缺一不可：

      ① float()  —— 官方有时把数字包成字符串
      ② round()  —— 去掉浮点噪声
      ③ 负零归一 + 非有限值兜底

    ⚠ 为什么必须管负零（-0.0）：Python 把 -0.0 序列化成 "-0.0"，而 JS 的
      JSON.stringify(-0) 得到 "0"，往返不无损。宿主会据此判定整个工具返回值
      "value is not lossless JSON" 并**整条拒绝** —— 不是丢一个字段，是工具直接不可用。
      实测（2026-09-23）：get_scene_context(limit=6) 结果里 0 个负零 → 成功；
      limit=15/40 各含 1 个负零（actors[7].center_cm[0] = -0.0）→ 宿主报错整条拒收。
      触发条件：某个物体的中心坐标恰好压在某根轴上。
    """
    v = round(float(value), digits)
    if not math.isfinite(v):
        # inf/nan 会让 JSON 写成 Infinity/NaN，同样被宿主整条拒收。
        return 0.0
    return 0.0 if v == 0 else v


def size_from_box(box: Any) -> list[float] | None:
    """把官方包围盒换算成 [X, Y, Z] 尺寸（厘米）。"""
    if not isinstance(box, dict) or not box.get("isValid"):
        return None
    mn, mx = box.get("min"), box.get("max")
    if not isinstance(mn, dict) or not isinstance(mx, dict):
        return None
    return [
        num(float(mx["x"]) - float(mn["x"])),
        num(float(mx["y"]) - float(mn["y"])),
        num(float(mx["z"]) - float(mn["z"])),
    ]


# --- 白膜占位（阶段一「没有资产可用」的元素）------------------------------------
# 2026-09-24 用户要求（原文见 docs/阶段一-资产确认.md 第四节）：
#   「用户确认没有的资产，以及用材质实例顶替的资产都要先预估尺寸并用白膜替代，
#     然后再让用户确认资产清单」。
# 这里只是清单登记 —— 阶段一不许往关卡里摆任何东西（硬规则 4）。

PLACEHOLDER_SHAPES = ("cube", "plane")
"""白膜形状：`cube`（体，如窗户 / 车道）/ `plane`（面，如马路 / 草坪）。

`cube` 要有**体积**（三个数），`plane` 是**覆盖面**（至少 X、Y）。
阶段六按这个形状用官方 PrimitiveTools 往 Actor 上加图元。
"""

SIZE_SOURCE_ESTIMATED = "预估（参考图目测，待核实）"
"""白膜行的标准尺寸来源文案 —— **预估值不许伪装成实测值**（硬规则 6）。"""

SIZE_SOURCE_ESTIMATED_LEGACY = "预估（待核实）"
"""旧写法，同样只表示「这是估的」（`placeholder_errors()` 按 `"预估" in src` 判合格）。"""

MATERIAL_ONLY_MARK = "命中的全是非网格资产"
"""`plan_assets` 的 `placeholder_hint` 里，用来标"这个元素只命中材质"的那句话。

单独拎成常量：生成它的地方和回头筛它的地方各写一份字面量的话，
改一处忘一处就会静默漏报（不报错，只是少一条提醒）。"""


def placeholder_errors(item: Any) -> list[str]:
    """校验**一行白膜占位**填得合不合规矩；返回错误清单（空 = 合格）。

    为什么要有这个函数：白膜行是"没有可用资产"的元素在清单里的**唯一交代**。
    它一旦填得不完整（没写形状 / 没给尺寸 / 尺寸来源不是预估），
    读表的人就会把**预估值当实测值**用 —— 那正是硬规则 6 要挡的事。
    所以宁可当场拒收，也不放一行"看着像资产"的白膜进去。

    四道校验：
      ① `asset_path` 必须**空** —— 白膜就是没有资产，带路径是自相矛盾；
      ② `placeholder_shape` 必须是 `cube` / `plane` 之一（不给就是没形状，阶段六没法实例化）；
      ③ `size_cm` 至少给 X、Y（`cube` 还要 Z，要有体积）；
      ④ `size_source` 必须写明是**预估**（默认值也算）—— 不许让预估值看起来像实测值。
    """
    errs: list[str] = []
    name = str(getattr(item, "element", "") or "?")

    if str(getattr(item, "asset_path", "") or "").strip():
        errs.append(
            f"{name!r}：白膜占位行的 asset_path **必须是空的**（白膜就是「没有可用资产」），"
            f"现在填了 {getattr(item, 'asset_path', '')!r} —— "
            "要么把它改成真资产行（is_placeholder=false），要么把路径清空。"
        )

    shape = str(getattr(item, "placeholder_shape", "") or "").strip().lower()
    if shape not in PLACEHOLDER_SHAPES:
        errs.append(
            f"{name!r}：白膜占位行必须填 placeholder_shape，"
            f"只能是 {' / '.join(PLACEHOLDER_SHAPES)}（现在填的是 {shape!r}）。"
            "cube = 有体积的（窗 / 车道），plane = 覆盖面（马路 / 草坪）——"
            "阶段六要按这个形状加图元。"
        )

    size = getattr(item, "size_cm", None)
    n = len(size) if isinstance(size, (list, tuple)) else 0
    if n < 2:
        errs.append(
            f"{name!r}：白膜占位行必须给**预估尺寸** size_cm（厘米，至少 X、Y）；"
            + ("cube 还要给 Z（要有体积）。" if shape == "cube" else "")
        )
    elif shape == "cube" and n < 3:
        errs.append(f"{name!r}：cube（体）类的白膜要给三个数 [X, Y, Z] —— 现在只有 {n} 个。")

    src = str(getattr(item, "size_source", "") or "").strip()
    if src and "预估" not in src:
        errs.append(
            f"{name!r}：白膜占位行的尺寸是**估的**，size_source 必须写明"
            f"（建议原样写 {SIZE_SOURCE_ESTIMATED!r}），现在写的是 {src!r} —— "
            "预估值不许伪装成实测值。"
        )
    return errs


def load_json(path: Path) -> Any:
    """读状态文件；不存在返回 None（第一次跑本来就没有，不是错误）。"""
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    """写状态文件（目录不存在就先建整条路径）。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# --- 大类表（阶段一「元素 → 大类」的词表）---------------------------------------
# 2026-09-24 用户要求：先有这张大类表（照 Fab 的 3D 分类树），根据参考图把它填好，再去按类找资产。

CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"
CATEGORY_PATH = CONFIG_DIR / "asset_categories.json"
UNCATEGORIZED = "uncategorized"
UNCATEGORIZED_CN = "未分类"


def load_categories() -> dict:
    """读大类表 → `{by_key, order, kinds, scene_keys, value_field, how_to_fill, fallback_*, defined}`。

    - `by_key`      : key → 中文名
    - `kinds`       : key → `asset`（要去资产库找）/ `scene`（场景级信息，**不是资产**）
    - `value_field` : scene 项的值填在 `ElementItem` 的哪个字段（如地图大小 → size_m）
    ⚠ 读不到表**不报错**，退化成"只有未分类一项" —— 缺一张词表不该把阶段一整条链卡死；
      但 `defined` 会如实报出表里原有几项，调用方一眼能看出表丢了。
    """
    doc = load_json(CATEGORY_PATH) or {}
    by_key: dict[str, str] = {}
    order: list[str] = []
    kinds: dict[str, str] = {}
    value_field: dict[str, str] = {}
    how_to_fill: dict[str, str] = {}
    for c in (doc.get("categories") or []):
        if not isinstance(c, dict):
            continue
        k = str(c.get("key") or "").strip()
        if not k or k in by_key:
            continue
        by_key[k] = str(c.get("cn") or k)
        order.append(k)
        kinds[k] = "scene" if str(c.get("kind") or "asset").strip() == "scene" else "asset"
        value_field[k] = str(c.get("value_field") or "")
        how_to_fill[k] = str(c.get("how_to_fill") or "")
    fb_key = str(doc.get("fallback_key") or UNCATEGORIZED)
    fb_cn = str(doc.get("fallback_cn") or UNCATEGORIZED_CN)
    if fb_key not in by_key:
        by_key[fb_key] = fb_cn
        order.append(fb_key)
        kinds[fb_key] = "asset"
    return {
        "by_key": by_key,
        "order": order,
        "kinds": kinds,
        "scene_keys": [k for k in order if kinds.get(k) == "scene"],
        "value_field": value_field,
        "how_to_fill": how_to_fill,
        "fallback_key": fb_key,
        "fallback_cn": fb_cn,
        "defined": len(order) - 1,
    }


def category_kind(key: str, table: dict | None = None) -> str:
    """这个大类是 `asset`（找资产）还是 `scene`（场景级信息，不是资产）；未分类算 asset。"""
    t = table if table is not None else load_categories()
    return t["kinds"].get((key or "").strip(), "asset")


def is_scene_category(key: str, table: dict | None = None) -> bool:
    """是不是"场景项"（地图大小 / 地图对应时间）—— 这类**不许去搜资产、也不许当白膜**。"""
    return category_kind(key, table) == "scene"


def category_cn(key: str, table: dict | None = None) -> str:
    """大类 key → 中文名（查表；空 key = 未分类）。

    ⚠ 查不到就写 `<key>（不在大类表里）`，**不编**一个中文名、也不静默吞成"未分类" ——
      表改过 / 手改过数据时要看得见。
    """
    t = table if table is not None else load_categories()
    k = (key or "").strip()
    if not k:
        return t["fallback_cn"]
    return t["by_key"].get(k, f"{k}（不在大类表里）")


def group_elements_by_category(items: list[dict], table: dict | None = None) -> dict:
    """把带 `category` 的行分组 → `{中文大类名: [元素名, ...]}`，**顺序照表**，未分类排最后。

    键用中文名：这份分组是要**直接给人看**的（"填好的表"），读表的人不该去猜 furniture 是什么。
    表里没有的大类（旧数据 / 手改）放最后 —— **不许丢**。
    """
    t = table if table is not None else load_categories()
    buckets: dict[str, list[str]] = {}
    for it in items:
        if not isinstance(it, dict):
            continue
        cn = category_cn(str(it.get("category") or ""), t)
        buckets.setdefault(cn, []).append(str(it.get("element") or ""))
    ordered: dict[str, list[str]] = {}
    for k in t["order"]:
        cn = t["by_key"][k]
        if cn in buckets:
            ordered[cn] = buckets.pop(cn)
    for cn in sorted(buckets):
        ordered[cn] = buckets[cn]
    return ordered


def order_category_names(names: set[str], table: dict | None = None) -> list[str]:
    """把一组中文大类名按**表里的顺序**排好；表外的（未分类 / 手改过的）放最后 —— **不丢**。"""
    t = table if table is not None else load_categories()
    order = [t["by_key"][k] for k in t["order"]]
    return [cn for cn in order if cn in names] + sorted(cn for cn in names if cn not in order)


def scene_from_rows(rows: list[dict], table: dict | None = None) -> tuple[dict, list, str]:
    """从表里 `kind=scene` 的行抽出场景项。

    返回 `({中文名: 人话值}, 地图大小 [X,Y] 或 None, 时间字符串)`。
    值填在哪个字段由**表**决定（`value_field`）—— 代码不写死 key，
    以后往表里加第三个场景项，只要表里写清 value_field 就能自动带出来。
    """
    t = table if table is not None else load_categories()
    scene: dict[str, str] = {}
    size_m: list[float] | None = None
    tod = ""
    for e in rows:
        if not isinstance(e, dict):
            continue
        cat = str(e.get("category") or "")
        if not is_scene_category(cat, t):
            continue
        cn = t["by_key"].get(cat, cat)
        vf = t["value_field"].get(cat, "")
        raw = e.get("size_m")
        if vf == "size_m" and isinstance(raw, (list, tuple)) and len(raw) >= 2:
            size_m = [float(raw[0]), float(raw[1])]
            scene[cn] = f"{size_m[0]:g}×{size_m[1]:g} m（预估）"
        elif vf == "time_of_day" and str(e.get("time_of_day") or "").strip():
            tod = str(e["time_of_day"]).strip()
            scene[cn] = tod
        else:
            scene[cn] = str(e.get("note") or "(未记录)")
    return scene, size_m, tod


def library_fingerprint(inventory: dict[str, list[str]]) -> tuple[str, dict[str, int]]:
    """把「资产库快照」压成一个 sha256 指纹 + 每类数量。

    为什么需要它：`delivered_at` 只能说明"什么时候确认的"，回答不了"项目变没变"。
    这里**只对路径负责**：同一批路径（与枚举顺序无关）→ 同一个指纹。

    ⚠ 路径没变、资产**内容**变了（换贴图、改材质参数）**测不出来** —— 这是刻意的取舍：
      要覆盖内容得上资产 GUID / 磁盘时间戳，成本高一个量级。
      所以交付文案里要写明：清单承诺的是**路径有效**，不是**内容没变**。
    """
    parts: list[str] = []          # 每一类压成一段字符串，最后整体哈希
    counts: dict[str, int] = {}    # 每类多少个，用于"58 → 56"这种人话差异
    for type_name in sorted(inventory):          # 排序：让指纹与字典顺序无关
        paths = sorted(inventory[type_name])     # 排序：让指纹与官方返回顺序无关
        counts[type_name] = len(paths)
        parts.append(f"{type_name}:{len(paths)}:" + "|".join(paths))
    digest = hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()
    return digest, counts


def describe_count_changes(signed: dict[str, int], live: dict[str, int]) -> list[str]:
    """把「签字时」与「现在」的数量差异说成人话，只报变了的那几类。

    例子：`["material_instance: 58 → 56"]` —— 这正是 2026-09-23 那次
    `/Game/Fab/Urban_Street_Pack` 整个包消失时该出现的信号。
    """
    out: list[str] = []
    for type_name in sorted(set(signed) | set(live)):   # 并集：一方没有的类也要比
        before, after = signed.get(type_name, 0), live.get(type_name, 0)
        if before != after:
            out.append(f"{type_name}: {before} → {after}")
    return out


def element_keys_from_items(items: list[dict]) -> tuple[set[str], str]:
    """从交付表的行里取出「已经落位的元素关键词」，以及**用的是哪种判定方式**。

    优先用 `element_key`（显式标注，最可靠）；旧表没有这个字段，
    退回"标签首词"（如 `"house 主屋"` → `house`）—— 那是**推断**，
    所以把用的哪种方式一起返回，别让推断冒充事实。
    """
    keys: set[str] = set()
    explicit = 0
    for it in items:
        key = str(it.get("element_key") or "").strip().lower()
        if key:
            explicit += 1
            keys.add(key)
            continue
        label = str(it.get("element") or "").strip()
        if label:
            keys.add(label.split()[0].lower())   # split()[0] = 以空白切开取第一个词
    if items and explicit == len(items):
        mode = "element_key 显式标注"
    elif explicit:
        mode = f"混合（{explicit}/{len(items)} 行有 element_key，其余按标签首词推断）"
    else:
        mode = "标签首词推断（表里没有 element_key）"
    return keys, mode


# --- [完工-03] 官方调用与枚举/实测（call_official / library_inventory / measure_asset）---
# 实测 2026-09-23 12:24：confirm_assets 用它量到 4 个网格的包围盒，
# 并对 2 个材质如实报"material_instance 没有包围盒"（没编数字）。


async def call_official(
    ctx: Context[AppContext], tool_name: str, arguments: dict, toolset: str | None = None
) -> Any:
    """调用官方的一个能力，并把结果解析成 Python 对象。

    两种调用方式（实测）：
      - toolset=None   → 直接调官方**元工具**（list_toolsets / describe_toolset / call_tool）
      - toolset=某工具集 → 经元工具 call_tool 转发到具体工具
        （官方 Tool Search 默认开着，具体工具不出现在 tools/list 里，只能这样转发）

    ⚠ 连接由 `_connection_loop` 持有：这里**只借用，不建也不关**
      （原因见本文件顶部"官方连接"那段）。
    """
    if toolset is None:
        mcp_tool, payload = tool_name, arguments
    else:
        mcp_tool = "call_tool"
        payload = {"toolset_name": toolset, "tool_name": tool_name, "arguments": arguments}

    app = ctx.request_context.lifespan_context
    client = await official_client(ctx)

    async def once(target: Any) -> Any:
        result = await target.call_tool(mcp_tool, payload)
        if result.is_error:
            text = result.content[0].text if result.content else "(无内容)"
            raise ToolError(f"官方工具 {tool_name} 返回错误：{text}")
        text = result.content[0].text if result.content else ""
        return parse_return(text)

    try:
        return await once(client)
    except ToolError:
        raise
    except Exception as first_error:
        # 连接可能已经死了（编辑器关了、会话被踢）。不能在这里关连接 ——
        # 只发一个"请重连"的信号，让连接 task 在它自己的 task 里收尾并重建。
        app.stop.set()
        new_client = None
        for _ in range(60):
            await anyio.sleep(0.1)
            if app.ue is not None and app.ue is not client:
                new_client = app.ue
                break
        if new_client is None:
            raise ToolError(
                f"调用官方 {tool_name} 失败，且自动重连没成功：{first_error}"
            ) from first_error
        try:
            return await once(new_client)
        except Exception as second_error:
            raise ToolError(
                f"调用官方 {tool_name} 失败（已重试一次）："
                f"第一次 {first_error}；第二次 {second_error}"
            ) from first_error


async def library_inventory(
    ctx: Context[AppContext]
) -> tuple[dict[str, list[str]], int]:
    """实况枚举项目资产库：**每类一次** find_assets（空名字 = 全都要）。

    返回 `(库存, 调了几次官方)`；库存形如 `{"mesh": ["/Game/..."], ...}`（已排序）。

    ⚠ 这里是**唯一一份**枚举逻辑：`plan_assets` 和 `get_asset_list` 都调它
      （2026-09-23 用户拍板合并）。
    返回的路径已排序：让指纹与枚举顺序无关，也让"截前 N 个"更确定。
    """
    inventory: dict[str, list[str]] = {}
    calls = 0
    for type_name in DEFAULT_ASSET_TYPES:
        class_path = CLASS_PRESETS.get(type_name)
        if class_path is None:
            continue
        paths = await call_official(
            ctx,
            "find_assets",
            {
                "folder_path": "/Game",
                "name": "",                     # 空名字 = 全都要（这就是"枚举"）
                "asset_type": {"refPath": class_path},
                "recursive": True,
            },
            toolset=TS_ASSET,
        )
        calls += 1
        inventory[type_name] = sorted(p for p in (paths or []) if isinstance(p, str))
    return inventory, calls


async def measure_asset(
    ctx: Context[AppContext], asset_path: str, asset_type: str = ""
) -> tuple[list[float] | None, float | None, str]:
    """量一个资产的**包围盒**尺寸与体积，返回 `(尺寸, 体积, 来源说明)`。

    为什么由工具来量、不让调用方填：
      "我以为它多大"和"它真的多大"是两回事 —— 尺寸拿去算缩放倍数，
      填错一个数，摆出来的房子就是错的比例。所以**实测值覆盖**调用方填的值。

    只有网格有包围盒；材质/材质实例一律返回 `(None, None, 原因)`。类别判定三档：
      ① `asset_type` 就在本 server 的类别表 `CLASS_PRESETS` 里 → 直接按它判，省一次调用；
      ② 不在表里（空值或别的写法）→ 问官方 `get_asset_class()` 拿类名再判；
      ③ 量取失败 → **原样带上官方报错，绝不编一个数字**。
    """
    resolved = asset_type
    if resolved not in CLASS_PRESETS:
        try:
            cls_name = await call_official(
                ctx, "get_asset_class", {"asset_path": asset_path}, toolset=TS_ASSET
            )
        except ToolError as exc:
            return None, None, f"类别没查到：{exc}"
        cls_text = str(cls_name or "")
        if "StaticMesh" in cls_text:
            resolved = "mesh"
        else:
            return None, None, f"{cls_text or '类别未知'} 没有包围盒"

    if resolved not in SIZE_QUERY_TYPES:
        return None, None, f"{resolved} 没有包围盒"

    try:
        box = await call_official(
            ctx,
            "get_bounds",
            {"mesh": {"refPath": to_object_path(asset_path)}},
            toolset="editor_toolset.toolsets.static_mesh.StaticMeshTools",
        )
    except ToolError as exc:
        return None, None, f"量取失败：{exc}"

    size = size_from_box(box)
    if size is None:
        return None, None, "官方没给出有效包围盒"
    volume = num(size[0] * size[1] * size[2])
    return size, volume, "官方 get_bounds 实测（包围盒）"


# --- [完工-04] 模型（工具返回结构 = 模型看到的"参数说明书"）---
# 实测 2026-09-23 12:12 / 12:24：confirm_assets 与 get_asset_list 完整序列化往返，
# 含新增的 size_cm / bbox_volume_cm3 / size_source / items。

class OfficialStatus(BaseModel):
    """官方链路自检结果。"""

    reachable: bool = Field(description="能不能连上官方 Unreal MCP")
    protocol_version: str | None = Field(default=None, description="协商出的 MCP 协议版本")
    toolset_count: int = Field(default=0, description="官方一共有多少个工具集")
    error: str | None = Field(default=None, description="连不上时的错误原文")


class ElementItem(BaseModel):
    """参考图里需要的一个元素。"""

    element: str = Field(description="元素名，如 house / road / tree / sidewalk")
    category: str = Field(
        default="",
        description=(
            "**大类 key**（照 `config/asset_categories.json` 那张表填，如 building / nature / "
            "environment / furniture / props）。这是 2026-09-24 用户要求的：先有大类表，"
            "再按参考图把表填好，然后才去找资产。"
            "⚠ 填表里没有的 key 会被**拒收**（表就是词表）；实在没把握就填 uncategorized，"
            "并在 note 里写明为什么"
        ),
    )
    subcategory: str = Field(
        default="",
        description="更细的一层（自由文本，可留空；如 building 下的 house / garage）。**不参与判定**，只给人看",
    )
    count: int | None = Field(
        default=None,
        description=(
            "**预估数量**（画面里能看到几个）。2026-09-24 用户要求：**有数量的就要填**。"
            "⚠ 材质 / 面这种没有『个数』概念的行可以留空，但要在 note 里写明为什么没有数量。"
            "⚠ 场景项（地图大小 / 地图对应时间）不用填。"
        ),
    )
    count_source: str = Field(
        default="",
        description=(
            "数量是怎么来的：`预估（参考图目测）` / `实测（图上数出来的）` 等 —— "
            "**是估的就必须写明是估的**，不许让预估值看起来像实测值"
        ),
    )
    size_m: list[float] | None = Field(
        default=None,
        description=(
            "**只给『地图大小』那一行填**：`[X, Y]`（米，预估）—— 从上传图估的场景范围。"
            "其余行留空；是预估就在 note 里写明依据"
        ),
    )
    time_of_day: str = Field(
        default="",
        description=(
            "**只给『地图对应时间』那一行填**：从图里光线判断的时段，如 sunset（黄昏）/ "
            "blue_hour（蓝调）/ noon（正午）/ night（夜）/ overcast（阴天）。其余行留空"
        ),
    )
    note: str = Field(default="", description="备注：在画面里的位置、为什么没有数量、估的依据等")


class ElementList(BaseModel):
    """**用户确认过**的元素清单（= 按大类填好的那张表）。"""

    confirmed_at: str = Field(description="确认时间")
    source_image: str = Field(description="参考图路径（留档）")
    total: int = Field(description="几个元素")
    elements: list[ElementItem] = Field(description="元素清单")
    groups: dict[str, list[str]] = Field(
        default_factory=dict,
        description=(
            "**按大类分组**：`{中文大类名: [元素名, ...]}`，顺序照大类表，未分类排最后 —— "
            "这就是「根据参考图填好的那张表」，拿它逐类跟用户确认"
        ),
    )
    categories_defined: int = Field(
        default=0, description="大类表里一共定义了几项（读不到表时会是 0 —— 那就该去查表在不在）"
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（表里 `kind=scene` 那两行，**不是资产**）：`{中文名: 人话值}`，"
            "如 `{\"地图大小\": \"80×80 m（预估）\", \"地图对应时间\": \"sunset（黄昏）\"}`"
        ),
    )
    scene_map_size_m: list[float] | None = Field(
        default=None,
        description="场景项『地图大小』的结构化值 `[X, Y]`（米，预估）；没填就是 null",
    )
    scene_time_of_day: str = Field(
        default="", description="场景项『地图对应时间』的值（如 sunset / blue_hour）；没填就是空"
    )
    no_count: list[str] = Field(
        default_factory=list,
        description=(
            "**没填预估数量的元素**。材质 / 面这种没有『个数』概念的可以没有数量 —— "
            "但要在该行 note 里写明；其余的行请补上 count"
        ),
    )
    next_step: str = Field(description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class FoundAsset(BaseModel):
    """按某个元素找到的一个候选资产。"""

    name: str = Field(description="资产名（可能没有语义，如 MI_sjfnch0a）")
    path: str = Field(description="包路径")
    asset_type: str = Field(description="类别：mesh / material / material_instance")
    size_cm: list[float] | None = Field(
        default=None, description="实测尺寸 [X,Y,Z]（厘米）。只有网格有，材质是 null"
    )
    matched_by: str = Field(description="怎么命中的：资产名 / 文件夹名")
    matched_segment: str = Field(
        default="", description="按文件夹命中时，命中的那一段（这就是它的语义来源）"
    )


class ElementPlan(BaseModel):
    """一个元素的查找结果。"""

    element: str = Field(description="元素名")
    status: str = Field(description="found = 名字对得上；missing = 没找到")
    assets: list[FoundAsset] = Field(description="找到的候选（缺失时为空）")
    placeholder_hint: str = Field(
        default="",
        description=(
            "**白膜提示**（2026-09-24 用户要求）：这个元素**没有可用资产**，"
            "必须在 confirm_assets 里登记成**白膜占位**（`is_placeholder=true` + "
            "`placeholder_shape` + **预估** `size_cm`），再让用户确认清单。"
            "空串 = 有可用的网格资产，按普通行登记。"
            "⚠ 有值时**不许**把它当普通资产行交出去（那样清单会带一条不存在的路径）。"
        ),
    )
    question: str = Field(description="**要原样问用户的话**")


class PlanReport(BaseModel):
    """阶段一的查找报告。"""

    stage: str = Field(description="当前阶段")
    needs_user_confirmation: bool = Field(description="恒为 true —— 用户确认前不许往下走")
    source: str = Field(description="元素清单从哪来的：用户确认过的清单 / 本次传入的关键词")
    total_elements: int = Field(description="一共查了几个元素")
    found: int = Field(description="找到了几个")
    missing: int = Field(description="缺了几个")
    elements: list[ElementPlan] = Field(description="逐元素结果")
    by_category: dict[str, dict[str, list[str]]] = Field(
        default_factory=dict,
        description=(
            '**按大类分组的结果**：`{中文大类名: {"found": [...], "missing": [...]}}`（顺序照大类表）'
            " —— 拿它**逐类核对有没有漏**。"
            "⚠ 大类**不是搜索过滤参数**：官方 find_assets 只能按资产名/文件夹名/类路径找，"
            "这里只是把结果归到类里，不许说成『按类搜索』"
        ),
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（表里 `kind=scene` 的那两行，**不是资产**、本次没去搜）："
            "`{中文名: 人话值}`，如 `{'地图大小': '80×80 m（预估）', '地图对应时间': 'sunset'}`"
        ),
    )
    official_calls: int = Field(description="调了几次官方工具")
    next_step: str = Field(description="下一步做什么")
    warnings: list[str] = Field(description="要提醒的坑（不藏着）")


class RenameItem(BaseModel):
    """要改名的一个资产（路径和名字由**用户**提供）。"""

    path: str = Field(description="现在的完整包路径")
    new_name: str = Field(description="新的资产名（**只给名字**，不要带路径和斜杠）")


class RenameResult(BaseModel):
    """一个资产的改名结果。"""

    old_path: str = Field(description="改名前路径")
    new_path: str = Field(description="改名后路径")
    referencers: list[str] = Field(description="谁引用了它（改名前查的，看影响面）")
    ok: bool = Field(description="成功没有")
    error: str = Field(default="", description="失败原因（官方原文）")


class RenameReport(BaseModel):
    """一批改名的结果。"""

    dry_run: bool = Field(description="true = 只预览，**没有真改**")
    requested: int = Field(description="要求改几个")
    renamed: int = Field(description="真改成功几个（dry_run 时恒为 0）")
    failed: int = Field(description="几个不合法或失败")
    items: list[RenameResult] = Field(description="逐个结果")
    note: str = Field(description="说明与风险提示")


class AssetListItem(BaseModel):
    """交付清单里的一行：一个元素用哪个资产。"""

    element: str = Field(description="画面元素名（给人看的标签，可带说明，如 'house 主屋'）")
    element_key: str = Field(
        default="",
        description=(
            "**元素关键词**（如 house / sidewalk），必须和 elements.json 里的元素名一致 —— "
            "get_asset_list 靠它判断哪些元素已经落位；"
            "留空会退回『标签首词推断』（不可靠，会明说是推断）"
        ),
    )
    asset_path: str = Field(
        default="",
        description=(
            "确认使用的资产包路径。⚠ **白膜占位行留空**（见 is_placeholder）—— "
            "那种元素没有可用资产，没有路径可验证"
        ),
    )
    category: str = Field(
        default="",
        description=(
            "**大类 key**（照 `config/asset_categories.json` 那张表，与该元素在 elements.json 里"
            "记的一致）。**不填也行**：本工具会去 elements.json 那张表里按关键词取；"
            "两边都没有才记成 uncategorized。中文名由本工具查表回填，调用方**不用填中文名**"
        ),
    )
    category_cn: str = Field(
        default="",
        description="大类中文名（**本工具查表回填**，调用方不用填）",
    )
    asset_type: str = Field(default="", description="类别：mesh / material_instance / material / whitebox")
    is_placeholder: bool = Field(
        default=False,
        description=(
            "**白膜占位**（whitebox）：这个元素**没有可用资产** —— 找不到、用户确认没有，"
            "或者现在只有**材质实例顶着**（材质没有包围盒、摆不出实体）。"
            "这类行：不做 exists() 验证、尺寸用调用方给的**预估值**（不被实测覆盖）、"
            "asset_type 记 whitebox。⚠ **只是清单登记** —— 阶段一不许往关卡里摆任何东西。"
        ),
    )
    placeholder_shape: str = Field(
        default="",
        description=(
            "白膜形状：`cube`（体，如窗户/车道这种有体积的）/ `plane`（面，如马路/草坪这种覆盖面）。"
            "非白膜行留空。阶段六按这个形状用官方 PrimitiveTools 加图元实例化。"
        ),
    )
    exists: bool = Field(
        # ⚠ `default` 不能删：本字段由工具自己回填（见函数体里的 model_copy），调用方不填。
        #   2026-09-23 曾因缺 default 被 pydantic 判成 required，与下面那句描述自相矛盾 ——
        #   照描述办事的调用方一律被参数校验拒收，工具连函数体都进不去（check_tools 实测复现）。
        default=False,
        description=(
            "官方 exists() 验证结果 —— **必须为 true**（白膜占位行为 false：没有路径可验）。"
            "⚠ 调用方**不用填**：本工具会逐个调官方 exists() 把它覆盖掉"
        ),
    )
    size_cm: list[float] | None = Field(
        default=None,
        description=(
            "**实测**包围盒尺寸 [X, Y, Z]（厘米）—— 由 confirm_assets 调官方 get_bounds 回填，"
            "调用方填什么都会被覆盖；非网格（材质等）为 null。"
            "⚠ **白膜占位行例外**：那种行没有东西可测，必须由调用方给**预估尺寸**（至少 X、Y），"
            "预估值**不会被覆盖** —— 但必须在 size_source 里写明是预估"
        ),
    )
    bbox_volume_cm3: float | None = Field(
        default=None,
        description="**包围盒体积**（厘米³）= X×Y×Z；⚠ 是包围盒，不是网格实际体积",
    )
    size_source: str = Field(
        default="",
        description=(
            "尺寸是怎么来的 / 为什么没有：`官方 get_bounds 实测（包围盒）` / "
            "`<类别> 没有包围盒` / `预估（参考图目测，待核实）` / 量取失败原因"
        ),
    )
    note: str = Field(default="", description="备注（谁改的名、为什么选它、白膜为什么用这个尺寸等）")


class UnresolvedElement(BaseModel):
    """**元素清单里有、交付表里没有**对应资产的元素 —— 免得它静默消失。

    为什么要有这个结构（2026-09-23 实测暴露）：
      `elements.json` 确认了 14 条 / 9 个关键词，交付表只有 6 行 ——
      `window` / `sidewalk` / `driveway` 三个关键词**在交付表里没有任何交代**。
      信息其实没丢（`get_asset_list` 每次都会报 `missing_elements`），
      但**单看交付物本身看不出清单不完整** —— 读表的人会以为一共就 6 个元素。
    """

    element_key: str = Field(description="元素关键词（与 elements.json 里的元素名一致）")
    occurrences: int = Field(default=0, description="该关键词在元素清单里出现几处")
    note: str = Field(
        default="",
        description="元素清单里对它的说明 —— **原样带出，不改写**",
    )


class AssetListDelivery(BaseModel):
    """**最终交付物**：给用户的资产清单。"""

    delivered_at: str = Field(description="交付时间")
    source_image: str = Field(description="参考图路径")
    total: int = Field(description="一共几个元素")
    verified: int = Field(description="路径验证通过几个")
    placeholders: int = Field(
        default=0,
        description=(
            "**白膜占位**几行（没有可用资产的元素 / 只有材质实例顶着的元素）—— "
            "这些行的尺寸是**预估**，请用户重点确认"
        ),
    )
    invalid_paths: list[str] = Field(
        default_factory=list,
        description=(
            "**验证不存在的路径**。⚠ 2026-09-24 整改后**恒为空**："
            "路径验不过的行会被 confirm_assets **当场拒收**（要求改成白膜占位或给对路径），"
            "根本走不到交付这一步。字段保留是为了不破坏交付物结构"
        ),
    )
    items: list[AssetListItem] = Field(description="资产清单")
    unresolved_elements: list[UnresolvedElement] = Field(
        default_factory=list,
        description=(
            "**元素清单里有、本表里没有对应资产**的元素 —— 不许静默消失。"
            "note 是元素清单原话（可能已写明归属，如『按光照环境处理』）。"
            "⚠ 本工具**不推断**没落位的原因：只说事实，要原因得问用户。"
            "⚠ 已经用**白膜占位**登记过的元素**不算未落位**（它已经有交代了）。"
        ),
    )
    deliverable: str = Field(description="给人看的清单正文（直接贴给用户）")
    note: str = Field(description="说明与下一步")


class AssetListRow(BaseModel):
    """交付表里的**一行**（get_asset_list 用）—— 原样带出表里记的尺寸信息。"""

    element: str = Field(default="", description="画面元素标签")
    element_key: str = Field(default="", description="元素关键词（表里显式记的那个）")
    category: str = Field(default="", description="大类 key")
    category_cn: str = Field(default="", description="大类中文名（交付时查表回填的）")
    asset_path: str = Field(default="", description="资产包路径")
    asset_type: str = Field(
        default="", description="类别：mesh / material_instance / material / whitebox"
    )
    is_placeholder: bool = Field(
        default=False, description="**白膜占位**行（没有可用资产；尺寸是**预估**、不是实测）"
    )
    placeholder_shape: str = Field(
        default="", description="白膜形状：cube（体）/ plane（面）；非白膜行留空"
    )
    size_cm: list[float] | None = Field(
        default=None,
        description=(
            "交付时记录的包围盒尺寸 [X, Y, Z]（厘米）。"
            "⚠ 白膜占位行这里是**预估尺寸**（见 size_source），不是实测"
        ),
    )
    bbox_volume_cm3: float | None = Field(
        default=None, description="包围盒体积（厘米³）；⚠ 是包围盒，不是网格实际体积"
    )
    size_source: str = Field(default="", description="尺寸来源 / 为什么没有尺寸")
    note: str = Field(default="", description="交付时的备注")


class PathCheck(BaseModel):
    """清单里**一条路径**的验活结果（get_asset_list 用）。"""

    element: str = Field(default="", description="这一行对应的元素标签")
    asset_path: str = Field(description="清单里记的资产路径")
    ok: bool = Field(description="官方 exists() 是否通过")
    error: str = Field(default="", description="验证失败时的官方原文")


class AssetListStatus(BaseModel):
    """**「当前这张资产清单还作不作数」**的判定结果（get_asset_list 用）。

    字段分成四组，对应它回答的四个问题：
      有没有表   → has_list / delivered_at / source_image / total
      表变没变   → stale / signed_* / live_* / changed_types
      路径还活吗 → path_check / dead_paths
      缺的有着落吗 → missing_elements / new_candidates / coverage_mode
    """

    has_list: bool = Field(description="有没有交付过清单（false 时其余字段无意义）")
    delivered_at: str = Field(default="", description="清单是什么时候交付的")
    source_image: str = Field(default="", description="当初那张参考图")
    total: int = Field(default=0, description="清单里共几条")
    placeholders: int = Field(
        default=0,
        description="其中**白膜占位**几条（这些行的尺寸是**预估**，不是实测 —— 别当实测值用）",
    )
    items: list[AssetListRow] = Field(
        default_factory=list,
        description="表里的**每一行**（含实测尺寸/包围盒体积），原样带出，不做二次加工",
    )
    stale: bool | None = Field(
        default=None,
        description="指纹对不上 = true（表已过期）；没有指纹可比 = null（旧版本落的表）",
    )
    signed_at: str = Field(default="", description="指纹是什么时候记的")
    signed_hash: str = Field(default="", description="签字时的资产库指纹")
    signed_counts: dict[str, int] = Field(
        default_factory=dict, description="签字时每类资产各多少个"
    )
    live_hash: str = Field(default="", description="刚测出来的资产库指纹")
    live_counts: dict[str, int] = Field(
        default_factory=dict, description="刚测出来每类资产各多少个"
    )
    changed_types: list[str] = Field(
        default_factory=list, description="变了的那几类，人话写法，如 'material_instance: 58 → 56'"
    )
    path_check: list[PathCheck] = Field(
        default_factory=list, description="逐条验活结果（verify_paths=false 时为空）"
    )
    dead_paths: list[str] = Field(
        default_factory=list, description="**已经验不存在的路径**（必须处理掉才能往下走）"
    )
    missing_elements: list[str] = Field(
        default_factory=list, description="还没有资产落位的元素关键词"
    )
    missing_by_category: dict[str, list[str]] = Field(
        default_factory=dict,
        description=(
            "**上面那些缺失元素按大类分组**：`{中文大类名: [元素关键词...]}`（顺序照大类表）—— "
            "一眼看出哪一类还缺东西"
        ),
    )
    scene: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "**场景项**（从 `catalog/elements.json` 原样带出，**不是资产**）："
            "`{中文名: 人话值}`，如 `{'地图大小': '80×80 m（预估）', '地图对应时间': 'sunset'}`；"
            "没填过就是空"
        ),
    )
    new_candidates: dict[str, list[str]] = Field(
        default_factory=dict, description="缺的元素在实况库存里**名字对得上**的新候选（元素 → 路径）"
    )
    coverage_mode: str = Field(
        default="", description="『元素已落位』是怎么判的：element_key 显式标注 / 标签首词推断"
    )
    official_calls: int = Field(default=0, description="本次调了几次官方工具")
    needs_user_confirmation: bool = Field(
        default=True, description="恒为 true —— 用户确认前不许往下走"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class PlanGate(BaseModel):
    """规划图的**闸门状态**：这张图还作不作数。"""

    confirmed: bool = Field(description="用户/客户是否已确认这张图")
    params_hash_ok: bool = Field(
        default=True,
        description=(
            "⚠ 2026-09-24 起**恒为 true**：参数文件已删（参数由调用方给），没有"
            "『哪份参数』可比。字段保留只为兼容旧 plan_v1.json（老文件里存过 params_hash）。"
            "闸门现在只有 `plan_hash_ok` 一道。"
        ),
    )
    plan_hash_ok: bool = Field(
        description="几何指纹是否仍与算出来时一致（false = 文件被手改过 → 这张图作废）"
    )
    confirmed_by: str = Field(default="", description="谁确认的")
    confirmed_at: str = Field(default="", description="什么时候确认的（UTC）")
    params_hash: str = Field(default="", description="（已废弃，恒空）")
    plan_hash: str = Field(default="", description="当前几何指纹")


class PlanSummary(BaseModel):
    """放置规模摘要（给人看的几个数）。"""

    world_center: list[float] = Field(default_factory=list, description="平面世界中心 [X, Y]（米）")
    world_size: list[float] = Field(default_factory=list, description="平面世界大小 [X, Y]（米）")
    assets: int = Field(default=0, description="已有资产的放置条数（一物一行）")
    whiteboxes: int = Field(default=0, description="白膜占位的条数（一物一行）")
    checks_total: int = Field(default=0, description="自检项数")
    checks_failed: int = Field(default=0, description="没过的项数（必须为 0）")
    failed_names: list[str] = Field(default_factory=list, description="没过的是哪几项")


class PlanResult(BaseModel):
    """算几何 / 确认的结果。"""

    stage: str = Field(description="阶段二 · 平面放置规划")
    unit: str = Field(default="m", description="单位（米制）")
    data_path: str = Field(description="几何数据文件 —— **后续计算只读它**")
    image_path: str = Field(
        default="",
        description=(
            "⚠ 2026-09-24 起**恒为空**：不再由代码按固定模板画图（用户拍板）。"
            "要图就自己拿 `data_path` 的几何数据去画 —— 画法不写死在代码里。"
        ),
    )
    summary: PlanSummary = Field(description="规模摘要")
    gate: PlanGate = Field(description="闸门状态")
    changed_params: list[str] = Field(
        default_factory=list, description="本次覆盖了哪些参数（点号路径；空 = 没改）"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑（不藏着）")


class PlanStatus(BaseModel):
    """『当前规划图还作不作数』+ 计划本体（get_plan 用）。"""

    has_plan: bool = Field(description="有没有算过规划")
    status: str = Field(
        default="",
        description=(
            "`initialized` = **两张表都空**（结构立好了，但还没有任何坐标 —— 图的依据没来）；"
            "`draft` = 有内容、等着用户确认；`confirmed` = 已确认"
        ),
    )
    data_path: str = Field(default="", description="几何数据文件")
    image_path: str = Field(
        default="", description="（恒空 —— 图由 AI 拿 data_path 自己画，代码不出图）"
    )
    summary: PlanSummary = Field(default_factory=PlanSummary, description="规模摘要")
    gate: PlanGate | None = Field(
        default=None, description="闸门状态；**confirmed=false 时不许进第三阶段**"
    )
    plan: dict | None = Field(
        default=None, description="完整计划数据（include_plan=true 时带出）"
    )
    next_step: str = Field(default="", description="下一步做什么")
    warnings: list[str] = Field(default_factory=list, description="要提醒的坑")


def candidates_for(
    keyword: str, inventory: dict[str, list[str]], limit: int = 5
) -> list[FoundAsset]:
    """在实况库存里按【资产名】+【文件夹名】两条路找候选（与 plan_assets 同一套判据）。

    ⚠ 只返回**名字对得上**的；名字对不上就是空列表 —— **禁止猜"疑似是它"**。
      这是本项目两次实测误报之后定下的硬规则，这里照旧执行。

    ⚠ **为什么这个函数待在「模型」区后面**（2026-09-23 血账，别搬回去）：
      签名里写了 `-> list[FoundAsset]`，而**函数签名上的注解是在 `def` 被执行的那一刻
      求值的**（不是等到调用时）。只要 FoundAsset 还没定义，模块 import 就抛
      `NameError: name 'FoundAsset' is not defined` —— server 直接起不来。
      第一版我把它放在"厚函数"区（模型区之前），实测正是这个报错，
      宿主侧表现为 mcp-client(mine) 重连 10 次全败。
      结论：**返回值里带模型的函数，必须放在模型定义之后。**
    """
    kw = keyword.lower().strip()
    out: list[FoundAsset] = []
    if not kw:
        return out
    for type_name, paths in inventory.items():
        for p in paths:
            name = p.rsplit("/", 1)[-1]          # rsplit(...,1)[-1] = 取最后一段 = 资产名
            matched_by, seg = "", ""
            if token_match(kw, name):
                matched_by = "资产名"
            else:
                for part in p.split("/"):        # 逐段试文件夹名
                    if part and token_match(kw, part):
                        matched_by, seg = "文件夹名", part
                        break
            if matched_by:
                out.append(
                    FoundAsset(name=name, path=p, asset_type=type_name,
                               matched_by=matched_by, matched_segment=seg)
                )
    out.sort(key=lambda a: (a.matched_by != "资产名", len(a.path)))
    return out[:limit]


# --- [完工-05] 工具 1：链路自检 ---
# 实测 2026-09-23 12:07：返回 reachable=true / protocol 2025-11-25 / 52 个工具集。

@mcp.tool()
async def official_status(ctx: Context[AppContext]) -> OfficialStatus:
    """自检：能不能连上官方 Unreal MCP，并报告协议版本和工具集数量。

    任何依赖官方的操作之前，先用它确认链路。连不上时返回**错误原文**，不猜原因。

    ⚠ 本 server 是**编排层**：自己完全不碰 UE —— 改关卡 / 摆 Actor / 改材质都要经官方
      `unreal` 那侧的工具做。
    ⚠ **没有对应工具的能力 = 还没实现** —— 如实说「还没做」，不许硬凑、不许假装能做。
    ⚠ 讲流程时**以 `docs/` 下的规划文档为准，不许凭印象**。
    ⚠ 硬性禁止：不许寻找/猜测「疑似资产」；不许删资产；**不许存盘**（保存 UE 关卡 / 资产）。
    """
    try:
        catalog = await call_official(ctx, "list_toolsets", {})
        text = catalog if isinstance(catalog, str) else json.dumps(catalog, ensure_ascii=False)
        # 官方把工具集列成 "- 工具集名: 说明"。只数形如 "- xxx.yyy:" 的行，
        # 别把说明里的项目符号也算进去（实测：那样会数出 67，真实值是 52）。
        count = len(re.findall(r"^-\s+\S*\.\S*:", text, flags=re.MULTILINE))
    except ToolError as exc:
        return OfficialStatus(reachable=False, error=str(exc))

    # 协商出的协议版本：上面那次 list_toolsets 调用已经把连接建起来了，
    # 所以此刻读 client.protocol_version 是安全的（未连接时抛 RuntimeError）。
    # 读不到不算自检失败：版本只是报告项，不该把整条结果判死。
    version: str | None = None
    try:
        app = ctx.request_context.lifespan_context
        version = app.ue.protocol_version if app.ue is not None else None
    except (RuntimeError, AttributeError) as exc:
        logging.getLogger(__name__).warning("读协议版本失败（已忽略）：%r", exc)

    return OfficialStatus(reachable=True, protocol_version=version, toolset_count=count)


# --- [完工-06] 工具 2：确认元素清单 ---
# 实测 2026-09-23T10:26:36Z：catalog/elements.json（14 个元素）由它落盘。

@mcp.tool()
async def confirm_elements(
    elements: Annotated[
        list[ElementItem], Field(description="从参考图提取的、**已经过用户确认**的元素清单")
    ],
    source_image: Annotated[str, Field(description="参考图路径（留档用）")] = "",
) -> ElementList:
    """记录**用户已确认**的元素清单 —— 阶段一的第一步。

    为什么要有这一步：用户的要求是"根据上传图片提取所需资产**让用户确认**"。
    把确认结果落盘有两个好处：
      ① 后面 plan_assets() 不用再传一遍关键词，直接读这份清单
      ② 有据可查：到底确认过哪些元素，不会中途被悄悄改掉

    ⚠ 调用前必须先让用户确认过这张表。**没确认就别调**。
    ⚠ **阶段一的流程（2026-09-24 整改）**：拿用户上传的图 → 提取画面信息 → **填进表里对应的大类**
      → 有数量的填**预估数量** → 表里那两个**场景项**（地图大小 / 地图对应时间）也要填
      → 交用户确认 → **然后才**去找资产。
      ① 表 = `config/asset_categories.json`：11 个资产大类（Fab 的 3D 分类树，用户截图原文）
         + 2 个**场景项**（`kind=scene`）；
      ② 每个元素填一个 `category` key —— 这一步就是"根据参考图把表填好"；
         表里没有的 key 会被**拒收**（拒收信息里列出可用的 key），不许自己造大类；
         没把握就填 `uncategorized` 并在 note 里写明原因；
      ③ **有数量的要填 `count`**，并用 `count_source` 写明是估的还是数的；
         材质 / 面这类确实没有『个数』的可以留空，但要在 note 里写明为什么；
      ④ **两个场景项必须填**：地图大小 → `size_m: [X, Y]`（米，预估）；
         地图对应时间 → `time_of_day`（如 sunset 黄昏 / blue_hour 蓝调）—— 没填会被拒收；
      ⑤ ⚠ 场景项**不是资产**：`plan_assets` 不会去搜它们，`confirm_assets` 也不许写进资产清单。
      ⚠ 大类**不是官方的搜索参数**（find_assets 只按资产名/文件夹名/类路径过滤）——
        它的用处是分组确认、逐类核对有没有漏，**不许**假装它能过滤搜索结果。
    ⚠ 元素粒度由**资产库**定，不由画面部件数定：屋顶 / 石材基座 / 路缘石这类通常
      **并进主体资产**，拆出来只会给 plan_assets 喂搜不到的词、制造假缺口。
      同一 element 可以**多行**（同关键词在多处出现）；覆盖判定按关键词集合算，不按条数算。
    ⚠ 图上**看不清**的：留在清单 + 写「⚠ 待核实」+ 给备用关键词；**不许凭空添一条，也不许删**。
      清单是给用户**逐条确认**的 —— 塞进猜测会污染他的确认，删掉该留的会丢信息。
    """
    table = load_categories()
    warnings: list[str] = []

    # 表里没有的 key 当场拒收 —— 不然"先有表再填表"就是句空话
    known = set(table["by_key"])
    bad = sorted({
        str(e.category).strip() for e in elements
        if str(e.category).strip() and str(e.category).strip() not in known
    })
    if bad:
        raise ToolError(
            f"大类 key 不在表里：{bad}。可用的 key：{sorted(known)}"
            f"（表在 {CATEGORY_PATH}）。实在没把握就填 {table['fallback_key']}，"
            "并在 note 里写明为什么 —— **不许自己造一个大类**。"
        )

    # 空大类 → 未分类：照实登记 + 报警，不替它编一个
    filled = [
        e.model_copy(update={"category": str(e.category).strip() or table["fallback_key"]})
        for e in elements
    ]
    n_uncat = sum(1 for e in filled if e.category == table["fallback_key"])
    if n_uncat:
        warnings.append(
            f"有 {n_uncat} 个元素**没填大类**，已照实记成「{table['fallback_cn']}」—— "
            "这份表没填全，请用户确认时重点看这几个。"
        )
    if table["defined"] == 0:
        warnings.append(
            f"读不到大类表（{CATEGORY_PATH}）—— 全部只能记成「{table['fallback_cn']}」。"
            "先确认那个文件在不在，别就这么往下走。"
        )

    # 场景项校验（表里 kind=scene 的行）：必须在表里、且值必须填。
    # 值填在哪个字段由表决定（value_field），代码不写死 key —— 以后往表里加第三、
    # 第四个场景项，只要在表里写清 value_field 就行。
    _present_scene = {e.category for e in filled if is_scene_category(e.category, table)}
    _absent_scene = [table["by_key"][k] for k in table["scene_keys"]
                     if k not in _present_scene]
    if _absent_scene:
        raise ToolError(
            "表里**少了场景项**：" + "、".join(_absent_scene) + "。"
            "它们和资产大类一样是这张表的一部分（2026-09-24 用户要求新增）—— "
            "地图大小填 `size_m`（米，预估）、地图对应时间填 `time_of_day`（如 sunset / blue_hour）；"
            "少了它们就不是一张填好的表。"
        )
    _missing_scene: list[str] = []
    for e in filled:
        if not is_scene_category(e.category, table):
            continue
        _vf = table["value_field"].get(e.category, "")
        _cn = table["by_key"].get(e.category, e.category)
        if _vf == "size_m":
            if (not e.size_m or len(e.size_m) < 2
                    or min(float(e.size_m[0]), float(e.size_m[1])) <= 0):
                _missing_scene.append(f"{_cn}（要填 size_m: [X, Y]，单位米）")
        elif _vf == "time_of_day":
            if not str(e.time_of_day).strip():
                _missing_scene.append(f"{_cn}（要填 time_of_day，如 sunset / blue_hour）")
    if _missing_scene:
        raise ToolError(
            "场景项没填值：" + "；".join(_missing_scene) + "。"
            "这两项是 2026-09-24 用户要求加进表里的（地图大小 / 地图对应时间）—— "
            "它们**不是资产**，但**必须填**：后面的世界范围和灯光都靠它们，不填就没有依据。"
        )

    scene, scene_size, scene_time = scene_from_rows(
        [e.model_dump() for e in filled], table
    )

    # 缺数量的（2026-09-24 用户要求：有数量的就要填预估数量）
    no_count = [
        e.element for e in filled
        if not is_scene_category(e.category, table) and not (e.count and e.count >= 1)
    ]
    if no_count:
        warnings.append(
            f"有 {len(no_count)} 个元素**没填预估数量**：{'、'.join(no_count)}。"
            "用户 2026-09-24 要求『有数量的还要填预估数量』—— "
            "材质 / 面这类确实没有个数的，请在该行 note 里写明；其余的请补 count。"
        )

    result = ElementList(
        confirmed_at=datetime.now(timezone.utc).isoformat(),
        source_image=source_image,
        total=len(filled),
        elements=filled,
        groups=group_elements_by_category([e.model_dump() for e in filled], table),
        categories_defined=table["defined"],
        scene=scene,
        scene_map_size_m=scene_size,
        scene_time_of_day=scene_time,
        no_count=no_count,
        next_step=(
            "元素清单已记录（按大类填好了，含地图大小 / 地图对应时间两个场景项）。"
            "下一步调 plan_assets()（不传参数即可）去找资产 —— "
            "⚠ **场景项不参与找资产**（它们不是资产），会在报告的 scene 里原样带出。"
            "找到就是找到，没找到就直接告诉用户缺什么，"
            "并请用户给出【路径 + 名字】—— 禁止猜疑似的。"
        ),
        warnings=warnings,
    )
    save_json(ELEMENTS_PATH, result.model_dump())
    return result


# --- [完工-07] 工具 3：找资产（阶段一主工具）---
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   本轮白膜整改新增的两条断言都绿 ——「找不到的元素带出 placeholder_hint（要求登记白膜占位）」
#   与「找不到元素时不再说『跳过这个元素』」。
# 2026-09-24 改过本块逻辑（阶段一白膜整改）：
#   ① `ElementPlan` 新增 `placeholder_hint`（缺失 / 只有材质实例顶着的元素，
#      要带上"必须登记成白膜占位"的提示 —— confirm_assets 会拒收没登记的白膜）；
#   ② 新增 warning：点出哪几个元素只命中非网格资产；
#   ③ 提问文案不再说「跳过这个元素」（用户口径是登记成白膜，不是跳过）。
# 实测 2026-09-23 12:07（不传参读元素清单）、12:12（keywords=["grass"]）两次调用。

@mcp.tool()
async def plan_assets(
    ctx: Context[AppContext],
    keywords: Annotated[
        list[str] | None,
        Field(description="要查的元素名。不传 = 用 confirm_elements 记录的那份清单"),
    ] = None,
    max_per_element: Annotated[
        int, Field(ge=1, le=20, description="每个元素最多列几个候选（默认 4）")
    ] = 4,
) -> PlanReport:
    """按名字找资产 → 报告**找到 / 没找到**，并对每个元素给一句要问用户的话。

    查两条路（缺一不可）：
      ① **按资产名** —— 官方 find_assets 的常规能力
      ② **按文件夹名** —— ⚠ 官方只匹配资产名、**不匹配文件夹名**。所以哈希名资产
         （MI_sjfnch0a）靠①永远搜不到，但它所在文件夹叫 Fine_American_Road。
    ②很便宜：每类资产只要 1 次枚举调用，之后所有关键词都在本地匹配。

    ⚠ **本工具不猜、不找"疑似"资产**（用户明确要求的硬规则）。
      名字对得上就是找到；对不上就是没找到。
      **命中多个时，把命中的逐个列出来（最多 max_per_element 个）交给用户确认用哪一个**；
      用户也可以明确让模型挑最匹配的 —— 但**绝不拿名字对不上的资产顶替**。
      为什么：我给"名字是否规范"做过两版判据，两版都在实测里误报
      （v1 把 M_Weapon / SM_Pistol / GlassJar 判错，还建议把 SM_Pistol 改名成 SM_Bush；
        v2 把 QuarterCylinder / FlashlightBeam 判错）。
      根因是**没有词典时，随机哈希和英文单词拼接在字符层面无法区分**。猜不准就不猜。

    没找到时：直接告知缺什么，并请用户把"存在但没被找到"的资产的【路径 + 名字】给你；
    用户确认「确实没有」的，**登记成白膜占位**（不是"跳过" —— 跳过会让这个元素静默消失）。

    ⚠ **每个元素都带 `placeholder_hint`**（2026-09-24 用户要求）：非空 = 这个元素**没有可用资产**
      （没找到，或命中的全是材质实例这种摆不出实体的）。这类**必须先在 confirm_assets 里
      登记成白膜占位**（`is_placeholder=true` + `placeholder_shape` + **预估** `size_cm`）
      再让用户确认清单 —— **不许当资产行交出去**（路径验不过会被当场拒收）。
      命中的只有材质、但用户说"就用它当表面"的，那是用户拍板，占位提示以用户答复为准。

    ⚠ 本工具**不改动任何东西**，`needs_user_confirmation` 恒为 true。
    """
    calls = 0
    warnings: list[str] = []

    stored = load_json(ELEMENTS_PATH)
    _scene_rows: list[dict] = []          # 场景项（地图大小 / 地图对应时间）—— 不是资产
    if keywords:
        elements_kw = [k for k in keywords if k and k.strip()]
        source = "本次传入的关键词"
    elif stored:
        _tbl = load_categories()
        elements_kw = []
        for _e in (stored.get("elements") or []):
            if not (isinstance(_e, dict) and _e.get("element")):
                continue
            # 场景项不参与找资产：去搜「地图大小」这种词没有意义
            if is_scene_category(str(_e.get("category") or ""), _tbl):
                _scene_rows.append(_e)
            else:
                elements_kw.append(_e["element"])
        source = f"用户确认过的元素清单（{stored.get('confirmed_at', '?')}）"
    else:
        raise ToolError(
            "没有元素清单：既没传 keywords，也没有 confirm_elements 记录过。"
            "请先读参考图列出元素、让用户确认，然后调 confirm_elements。"
        )
    if not elements_kw and not _scene_rows:
        raise ToolError("元素清单是空的，没什么可查。")

    # 每类资产枚举一次，之后都在本地匹配（枚举逻辑收敛在 library_inventory() 一处）
    inventory, enum_calls = await library_inventory(ctx)
    calls += enum_calls

    if sum(len(v) for v in inventory.values()) == 0:
        warnings.append(
            "资产库枚举返回 0 条 —— 可能官方 find_assets 的用法变了，"
            "先用 official_status 确认链路再重试。"
        )

    elements: list[ElementPlan] = []
    found_count = 0

    for kw in elements_kw:
        kw_l = kw.lower().strip()
        found: list[FoundAsset] = []

        for type_name, paths in inventory.items():
            for p in paths:
                name = p.rsplit("/", 1)[-1]
                matched_by, seg = "", ""
                if token_match(kw_l, name):
                    matched_by = "资产名"
                else:
                    for part in p.split("/"):
                        if part and token_match(kw_l, part):
                            matched_by, seg = "文件夹名", part
                            break
                if matched_by:
                    found.append(
                        FoundAsset(
                            name=name, path=p, asset_type=type_name,
                            matched_by=matched_by, matched_segment=seg,
                        )
                    )

        for f in [x for x in found if x.asset_type in SIZE_QUERY_TYPES][:max_per_element]:
            try:
                box = await call_official(
                    ctx, "get_bounds", {"mesh": {"refPath": to_object_path(f.path)}},
                    toolset="editor_toolset.toolsets.static_mesh.StaticMeshTools",
                )
                calls += 1
                f.size_cm = size_from_box(box)
            except ToolError as exc:
                calls += 1
                warnings.append(f"查 {f.name} 尺寸失败：{exc}")

        found.sort(key=lambda a: (a.matched_by != "资产名", len(a.path)))

        # "只有材质实例顶着" = 这个元素摆不出实体（材质没有包围盒、量不出尺寸）。
        # 不能自作主张替用户判定：材质是真的不够用、还是本来就当表面用，得用户拍板 ——
        # 这里只把事实摆出来 + 给出白膜该怎么办。
        mesh_hits = [f for f in found if f.asset_type in SIZE_QUERY_TYPES]
        only_material = bool(found) and not mesh_hits
        hint = ""
        if not found:
            hint = (
                "找不到资产 → **登记成白膜占位**（先给预估尺寸，再让用户确认清单）："
                "`is_placeholder=true`、`asset_path` 留空、"
                "`placeholder_shape` 按它是什么填 cube（体）/ plane（面）、"
                f"`size_cm` 给 [X, Y, (Z)]、`size_source` 写 {SIZE_SOURCE_ESTIMATED}。"
            )
        elif only_material:
            types = "、".join(sorted({f.asset_type for f in found}))
            hint = (
                f"{MATERIAL_ONLY_MARK}（{types}）—— **材质没有包围盒、摆不出实体**，"
                "等于没资产。2026-09-24 用户要求：这类元素**先给预估尺寸、登记成白膜占位**"
                f"（`is_placeholder=true`、`placeholder_shape` 填 cube/plane、"
                f"`size_cm` 给预估、`size_source` 写 {SIZE_SOURCE_ESTIMATED}），"
                "**再让用户确认清单**。"
                "⚠ 但**要不要把它当资产用，由用户拍板** ——"
                "若用户确认「就用这个材质当表面」，那才是普通资产行；"
                "本工具不替你决定，也不许拿它顶替实体。"
            )

        if found:
            found_count += 1
            names = "、".join(f.name for f in found[:max_per_element])
            question = (
                f"「{kw}」找到 {len(found)} 个候选：{names}。"
                f"请确认用哪一个（或明确让我挑最匹配的）。"
            )
            if only_material:
                question += (
                    " ⚠ 这几个都是**非网格资产**（没有包围盒、摆不出实体）："
                    "请用户明确 —— 是就用它当**表面**，还是**登记成白膜占位**？"
                )
        else:
            # 不猜、不找疑似的 —— 直接说缺，请用户给路径
            question = (
                f"「{kw}」按名字没找到（资产名和文件夹名都试过了）。"
                f"**如果它其实存在、只是名字对不上，请把它的【路径 + 名字】告诉我，我来改名。**"
                f"如果确实没有，请告诉我：**登记成白膜占位**（先给预估尺寸），"
                f"而不是把它当资产行交出去。"
            )

        elements.append(
            ElementPlan(
                element=kw, status="found" if found else "missing",
                assets=found[:max_per_element],
                placeholder_hint=hint,
                question=question,
            )
        )

    missing = len(elements) - found_count

    # 白膜提醒（2026-09-24 用户要求：没有可用资产的元素，先给预估尺寸、登记白膜）
    # _none_found：按名字一个都没找到；_only_mat：只命中材质/材质实例（算 found，
    # 但摆不出实体）。两类原因不同、对策一样：登记成白膜占位，而不是"跳过"。
    _none_found = [p.element for p in elements if not p.assets and p.placeholder_hint]
    _only_mat = [p.element for p in elements if MATERIAL_ONLY_MARK in p.placeholder_hint]

    if _none_found or _only_mat:
        _parts: list[str] = []
        if _none_found:
            _parts.append(
                f"{len(_none_found)} 个**按名字一个都没找到**（{'、'.join(_none_found)}）"
            )
        if _only_mat:
            _parts.append(
                f"{len(_only_mat)} 个**只命中非网格资产**（材质/材质实例 —— "
                f"没有包围盒、摆不出实体：{'、'.join(_only_mat)}）"
            )
        warnings.append(
            "有 " + "；".join(_parts) + "。**禁止猜疑似的** —— 把事实如实告诉用户："
            "存在但名字对不上的，请用户给【路径 + 名字】；"
            "用户确认「确实没有」的，**登记成白膜占位**（`is_placeholder=true` + "
            "`placeholder_shape` + **预估** `size_cm`）再让用户确认清单 —— "
            "**不许当资产行交出去**（路径验不过会被 confirm_assets 当场拒收），"
            "也**不许「跳过」了事**（那会让这个元素在清单里静默消失）。"
            "详见各元素的 `placeholder_hint`。"
        )

    # 按大类分组（2026-09-24 用户要求：报告也按类给）
    # 元素 → 大类 来自 elements.json；本次显式传 keywords 时，清单里没记过的词落「未分类」。
    _cat_by_element = {
        str(e.get("element") or ""): str(e.get("category") or "")
        for e in ((stored or {}).get("elements") or []) if isinstance(e, dict)
    }
    _cat_table = load_categories()
    by_cat: dict[str, dict[str, list[str]]] = {}
    for p in elements:
        _cn = category_cn(_cat_by_element.get(p.element, ""), _cat_table)
        _bucket = by_cat.setdefault(_cn, {"found": [], "missing": []})
        _bucket["found" if p.status == "found" else "missing"].append(p.element)
    by_cat = {cn: by_cat[cn] for cn in order_category_names(set(by_cat), _cat_table)}

    scene_out, _scene_size, _scene_time = scene_from_rows(_scene_rows, _cat_table)
    if _scene_rows:
        warnings.append(
            f"清单里有 {len(_scene_rows)} 个**场景项**（" + "、".join(scene_out.keys())
            + "）—— 它们**不是资产**，本次没有去搜；值见返回里的 `scene`，"
            "后面的世界范围 / 灯光要用它们。"
        )

    return PlanReport(
        stage="阶段一 · 资产确认",
        needs_user_confirmation=True,
        source=source,
        total_elements=len(elements),
        found=found_count,
        missing=missing,
        elements=elements,
        by_category=by_cat,
        scene=scene_out,
        official_calls=calls,
        next_step=(
            "把每个元素的 question **原样逐条问用户**："
            "找到的问用哪个（**连预估数量一起报上去**，用户要按数量判断够不够）；"
            "**缺的请用户给出【路径 + 名字】**。"
            "⚠ 每个元素还带 `placeholder_hint`：**非空 = 它没有可用资产**"
            "（没找到，或命中的全是材质实例这种摆不出实体的），"
            "这类**必须登记成白膜占位**（`is_placeholder=true` + `placeholder_shape` + "
            "**预估** `size_cm`）再让用户确认清单 —— **不许当资产行交出去**"
            "（confirm_assets 会当场拒收一条验证不过的路径）。"
            "⚠ 用 `by_category` **逐类核对有没有漏**（哪个大类还缺哪些元素）——"
            "但大类**不是搜索参数**，缺了仍然是按名字找 + 请用户指路。"
            "⚠ `scene` 里那两个场景项**不是资产**，别去问用户『用哪个资产』；"
            "它们是地图大小 / 地图对应时间，后面摆场景时才用。"
            "拿到用户答复后：路径 → rename_assets 改名；"
            "用户说「确实没有」 → 按白膜登记；"
            "全部齐了 → confirm_assets 交付清单。"
        ),
        warnings=warnings,
    )


# --- [完工-10] 工具 4：改名（用户指路之后）----------------------------------------------
# 实测 2026-09-23 晚：check_tools 4 条全绿 —— 默认 dry_run / 一个都没真改 /
# 拦下带斜杠的非法名（本地就挡住，不发去 UE）/ 给出了改名前后路径。
# 它只测预览路径（confirm=False），绝不真改用户资产。

@mcp.tool()
async def rename_assets(
    ctx: Context[AppContext],
    items: Annotated[
        list[RenameItem], Field(description="要改名的资产（路径来自用户提供）")
    ],
    confirm: Annotated[
        bool, Field(description="false = 只预览改名前后路径（默认，安全）；true = 真的改")
    ] = False,
) -> RenameReport:
    """把用户指出的资产改成规范名 —— **默认只预览，不真改**。

    用在阶段一第 5 步：用户说了"存在但你没找到的那个资产在 XX 路径"，就用它改名，
    以后不会再有人认不出它。

    为什么必须两步（预览 → 确认）：
      - 改的是**用户工程里的资产**，`move` 会改变资产的包路径
      - UE 一般会自动更新引用，但那是"一般"，不是保证
      - 所以每次都先查 `get_referencers`（谁引用了它），把影响面摆给用户看

    走官方 `AssetTools.move(path, new_path)` —— 同目录内换个名字就是"重命名"。
    """
    report = RenameReport(
        dry_run=not confirm, requested=len(items), renamed=0, failed=0, items=[],
        note=(
            "改名前已查引用者。UE 通常会跟随更新引用，但**这里不做保证** —— "
            "若该资产被蓝图/关卡引用，改名后请重新打开确认一次。"
        ),
    )

    for item in items:
        old_path, new_name = item.path.strip(), item.new_name.strip()
        entry = RenameResult(old_path=old_path, new_path="", referencers=[], ok=False)

        # 本地合法性检查 —— 不合法就不必去打扰官方
        if "/" in new_name or not new_name:
            entry.error = f"new_name 只能是纯名字（不能有斜杠），收到 {new_name!r}"
            entry.new_path = "(未计算)"
            report.failed += 1
            report.items.append(entry)
            continue
        if old_path.rsplit("/", 1)[-1] == new_name:
            entry.error = "新名字和旧名字一样，没必要改"
            entry.new_path = old_path
            report.failed += 1
            report.items.append(entry)
            continue

        entry.new_path = f"{old_path.rsplit('/', 1)[0]}/{new_name}"

        # 两种路径形式都试：实测裸包路径会报 "Asset does not exist"
        refs, last_err = None, ""
        for candidate in (old_path, to_object_path(old_path)):
            try:
                refs = await call_official(
                    ctx, "get_referencers", {"asset_path": candidate}, toolset=TS_ASSET
                )
                break
            except ToolError as exc:
                last_err = str(exc)
        entry.referencers = (
            [r for r in (refs or []) if isinstance(r, str)]
            if refs is not None
            else [f"(查引用失败：{last_err})"]
        )

        if not confirm:
            entry.ok = True          # 预览：能改就算通过
            report.items.append(entry)
            continue

        try:
            await call_official(
                ctx, "move", {"path": old_path, "new_path": entry.new_path}, toolset=TS_ASSET
            )
            entry.ok = True
            report.renamed += 1
        except ToolError as exc:
            entry.error = f"改名失败：{exc}"
        report.items.append(entry)

    return report


# --- [完工-08] 工具 5：确认并交付资产清单（阶段一收尾）---
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   ① 纯逻辑那 11 条白膜校验断言全绿（带路径 / 没形状 / 形状写错 / 没尺寸 / cube 少一个数 /
#      来源写成实测 → 都拒收；plane 两个数、旧文案、空 size_source → 都算合格）；
#   ② 经 MCP 端到端两条拒收断言绿：「拒收路径验证不过的行（不再当 invalid_paths 交付）」
#      与「拒收没写 placeholder_shape 的白膜行」；
#      走通的那一批绿：1 个真资产 / 2 个白膜占位、`invalid_paths` 恒空、清单里点明了
#      "摆不出实体"、`note` 里点名了只拿材质顶着的元素、白膜行标成 ◻ 白膜且不带路径。
# 2026-09-24（二）再次整改（阶段一白膜契约收紧，逻辑改动不是文案）：
#   ① `placeholder_errors()` 四道校验（带路径 / 没形状 / 没尺寸 / 来源不是预估 → 拒收）；
#   ② 路径验证不通过不再记进 invalid_paths 交付，改为整表拒收 + 给出改法；
#   ③ 新增"只拿材质/材质实例顶着"的点名（只点名，不替用户改）；
#   ④ 拒收发生在写盘之前 —— catalog/ 不会被写到一半。
# 实测 2026-09-23 12:12（6/6 exists + 指纹签字）、12:24（4 个网格实测尺寸 + 重签）。
# 实测 2026-09-23 晚：复跑 check_tools —— 原先失败的 3 条全绿，
#   且末尾 [还原] 行列出了 asset_list.json / elements.json / library_snapshot.json，
#   证明函数体真跑到了写盘那一步。
# 2026-09-23 晚（二）：新增 unresolved_elements（未落位元素），尚无实测证据。

@mcp.tool()
async def confirm_assets(
    ctx: Context[AppContext],
    items: Annotated[
        list[AssetListItem],
        Field(description="用户确认过的「元素 → 资产」对照表（exists 字段由本工具回填）"),
    ],
) -> AssetListDelivery:
    """**阶段一收尾 + 交付**：验证资产是否真的存在 → 实测尺寸 → 落盘 → 签字 → 输出清单。

    做七件事：
      ① 逐个调官方 `exists()` **验证路径**（不是形式主义，见下）
      ② **实测尺寸**：网格调官方 `get_bounds`，把包围盒 X×Y×Z 与体积**回填进表**
         （调用方填的尺寸一律被实测值覆盖 —— 理由见 measure_asset 的说明）
      ③ 落盘到 `catalog/asset_list.json`（这是清单文件，不是 UE 资产，不违反"不许存盘"）
      ④ **给表签字**：记下当时的资产库指纹到 `catalog/library_snapshot.json`，
         之后 `get_asset_list()` 才判定得了这张表过没过期
      ⑤ 生成 `deliverable` —— 一段**给人看的清单正文**（带尺寸/体积两列），直接贴给用户确认
      ⑥ 列出**未落位元素**（元素清单里有、本表里没有对应资产）到 `unresolved_elements` ——
         免得它静默消失：读表的人必须一眼看出"这份清单不完整"，而不是以为一共就这么多
      ⑦ **白膜占位**：下面这两类元素**先给预估尺寸、登记成白膜**，再让用户确认清单（见下）

    ⚠ **第 ⑦ 步：什么元素要登记白膜占位**（2026-09-24 用户要求）
      ① 找不到资产的（`plan_assets` 报 missing）、或用户确认"这个没有"的元素；
      ② **现在只有材质实例顶着**的元素（如 road / grass）—— 材质没有包围盒、摆不出实体，
         等于没资产。
      两类都填：`is_placeholder=true`、`asset_path` 留空、
      `placeholder_shape` 填 `cube`（有体积的，如窗/车道）/ `plane`（覆盖面，如路面/草坪）、
      `size_cm` 给**预估尺寸**、`size_source` 写明 `预估（参考图目测，待核实）`。
      ⚠ 四样**缺一不可**，填错**当场拒收**（不是警告）：带路径的白膜（自相矛盾）、
      没写形状（阶段六没法实例化）、没给尺寸（等于没占位）、
      尺寸来源写成"实测"（预估值伪装成实测值 —— 硬规则 6）。

    ⚠ **路径验证不通过的行，本工具现在直接拒收**（2026-09-24 整改，理由如下）：
      以前它把这种行记进 `invalid_paths` 照常交付，于是"元素没有资产"这件事
      只在备注里出现，清单本身照样带着一条**解析不到的路径**往下走。
      按用户的要求（`docs/阶段一-资产确认.md` 第 9 步）：**没有资产 = 登记成白膜占位**。
      所以现在二选一 —— 要么给对路径（`exists()` 通过），要么登记成白膜；
      **拒收时 catalog/ 一个字节都不写**，不会把上一次交付物覆盖成半新半旧。

    ⚠ **白膜只是"清单登记"，不是"往关卡里摆东西"**：
      `docs/阶段一-资产确认.md` 硬规则 4 —— 用户确认资产列表前不许摆放任何东西；
      规划图闸门也一样。真正生成白膜是**阶段六**（官方 PrimitiveTools 往 Actor 上加 Cube/Plane
      图元就行，**不用新建任何 UE 资产、不用存盘**）。
    ⚠ **预估值不许伪装成实测值**：白膜行没有东西可测，它的 size_cm 就是你填的那个数；
      必须在 size_source 里写明是预估、待核实 —— 用户确认清单时要能一眼看出哪个是估的。
      `plane`（面）类要额外说明：它的覆盖面**阶段二会用参数几何重算**，这里的预估值只是占位。

    ⚠ 每行的 `element_key` 请填**元素关键词**（与 elements.json 里的元素名一致）：
      `get_asset_list()` 靠它算"还有哪些元素没落位"。不填就只能按标签首词推断，
      而那只是推断 —— 返回值里会明说，不会假装是事实。

    ⚠ 为什么必须逐个验证存在性（实测价值）：
      2026-09-23 实测：`/Game/Fab/Urban_Street_Pack` 整个文件夹在我工作期间消失了
      （材质实例总数 58 → 56，exists() = False），而我此前一直以为人行道材质还在用它的
      Material_002。有这一步就会立刻暴露。
      **"我以为它在"和"它真的在"是两回事。**

    ⚠ **只拿材质 / 材质实例顶着的行**：本工具**只点名、不替用户改**
      （`note` 里列出来）—— 到底"就用这个材质当表面"还是"登记成白膜"，得用户拍板；
      替用户决定就是猜（硬规则 1）。
    """
    results: list[AssetListItem] = []
    stored = load_json(ELEMENTS_PATH) or {}

    # 大类（2026-09-24 用户要求：资产清单也要分大类）
    # 调用方填了就用它；没填就从 elements.json 那张表里按关键词取；
    # 两边都没有 = 未分类。中文名一律查表回填 —— 表是唯一来源。
    _cat_table = load_categories()
    _cat_by_key: dict[str, str] = {}
    for _e in (stored.get("elements") or []):
        if isinstance(_e, dict):
            _k = str(_e.get("element") or "").strip().lower()
            if _k and str(_e.get("category") or "").strip():
                _cat_by_key.setdefault(_k, str(_e["category"]).strip())

    def _cat_of(it: AssetListItem) -> str:
        """这一行归哪个大类：调用方填的 → elements.json 里记的 → 空（记成未分类）。"""
        given = str(it.category).strip()
        if given:
            return given
        for probe in (str(it.element_key or "").strip().lower(),
                      str(it.element or "").strip().split(" ")[0].lower()):
            if probe and probe in _cat_by_key:
                return _cat_by_key[probe]
        return ""

    measured = 0        # 量到包围盒的网格数
    no_size = 0         # 本来就没有包围盒的（材质/材质实例等）
    size_failed = 0     # 想量却没量到的
    placeholders = 0    # 白膜占位几行（没有可用资产的元素）
    bad_rows: list[str] = []   # 不合格的行（白膜填错 / 路径验不过）—— 收齐再判，见循环里那段说明

    for item in items:
        # 场景项（地图大小 / 地图对应时间）不是资产 —— 不许写进资产清单
        if is_scene_category(_cat_of(item), _cat_table):
            raise ToolError(
                f"{item.element!r} 是**场景项**（{category_cn(_cat_of(item), _cat_table)}），"
                "不是资产 —— 资产清单里不该有它。它的值已经记在 catalog/elements.json 里了。"
            )

        # 白膜占位行：没有资产可验、没有东西可量 —— 校验填得合不合规矩。
        # 2026-09-24 用户要求：找不到资产的、用户确认没有的、只有材质实例顶着的元素，
        # 都要先给预估尺寸、登记成白膜，再让用户确认清单。只是清单登记，不往关卡里摆东西。
        # 校验不过的收进 bad_rows、等整表走完再一次性拒收（别探到第一个坏行就抛）。
        if item.is_placeholder:
            bad_rows += placeholder_errors(item)
            vol = None
            if item.size_cm and len(item.size_cm) >= 3:
                vol = num(float(item.size_cm[0]) * float(item.size_cm[1])
                          * float(item.size_cm[2]))
            placeholders += 1
            _cat = _cat_of(item)
            results.append(item.model_copy(update={
                "exists": False,          # 没有路径可验 —— 不许写成"存在"
                "bbox_volume_cm3": vol,
                "asset_type": item.asset_type or "whitebox",
                "size_source": item.size_source or SIZE_SOURCE_ESTIMATED,
                "category": _cat,
                "category_cn": category_cn(_cat, _cat_table),
            }))
            continue

        ok = False
        err = ""
        try:
            exists = await call_official(
                ctx, "exists", {"path": item.asset_path}, toolset=TS_ASSET
            )
            ok = exists is True or (isinstance(exists, str) and exists.lower() == "true")
        except ToolError as exc:
            err = str(exc)
        if not ok:
            # 2026-09-24（二）：不再记进 invalid_paths 一路交付出去。
            # 路径验不过的元素 = 没有可用资产 = 该登记成白膜；
            # 先收着，等整表走完一起拒收（带上"怎么改"的原文）。
            bad_rows.append(
                f"{item.element!r}：路径验证不通过"
                + (f"（{err}）" if err else "（官方 exists() 返回否）")
                + f" —— `asset_path` = {item.asset_path!r}。"
                "请二选一：① 用户给出正确路径 → 改成那一行重交；"
                "② 用户确认「确实没有」→ 改成**白膜占位行**"
                f"（`is_placeholder=true`、`asset_path` 留空、`placeholder_shape` 填 "
                f"{' / '.join(PLACEHOLDER_SHAPES)}、`size_cm` 给**预估**尺寸、"
                f"`size_source` 写 {SIZE_SOURCE_ESTIMATED}）。"
                "**不许当资产行交出去** —— 否则下一阶段会挂上一个解析不到的材质/网格。"
            )

        size: list[float] | None = None
        volume: float | None = None
        size_src = "路径不存在，没量"
        if ok:
            size, volume, size_src = await measure_asset(
                ctx, item.asset_path, item.asset_type
            )
        if size:
            measured += 1
        elif "没有包围盒" in size_src:
            no_size += 1
        else:
            size_failed += 1

        _cat = _cat_of(item)
        results.append(item.model_copy(update={
            "exists": ok,
            "size_cm": size,
            "bbox_volume_cm3": volume,
            "size_source": size_src,
            "category": _cat,
            "category_cn": category_cn(_cat, _cat_table),
        }))

    # 只拿材质 / 材质实例顶着的行：摆不出实体，要点名（2026-09-24 用户要求）。
    # 只点名、不替用户改 —— 当表面用还是登记白膜，得用户拍板（硬规则 1「不猜」）。
    mat_only = [
        r.element for r in results
        if not r.is_placeholder
        and str(r.asset_type or "").strip().lower() in ("material", "material_instance")
    ]

    # 不合格的行：拒收，一个都不许落盘（白膜填错 / 路径验不过）。
    # 一次列全再抛（一个一个抛，用户得改一轮试一轮）；且在写盘之前抛 ——
    # 写盘在函数末尾，在这里抛 = catalog/ 一个字节都没动。
    if bad_rows:
        raise ToolError(
            f"资产清单**拒收**：有 {len(bad_rows)} 行不合格 —— 先改掉，清单没落盘。\n"
            "  - " + "\n  - ".join(bad_rows)
        )

    # 未落位元素：元素清单里有、交付表里没有的 —— 不许静默消失。
    # note 原样带出元素清单里那一句，不推断原因
    # （例：sky 写着"按【光照环境】处理…不按资产找（用户已拍板）"）。
    delivered_keys, _cov_mode = element_keys_from_items([r.model_dump() for r in results])
    _notes_by_key: dict[str, list[str]] = {}
    for _e in (stored.get("elements") or []):
        if not isinstance(_e, dict):
            continue
        _k = str(_e.get("element") or "").strip().lower()
        if _k:
            _notes_by_key.setdefault(_k, []).append(str(_e.get("note") or ""))
    unresolved = [
        UnresolvedElement(
            element_key=_k,
            occurrences=len(_ns),
            note=" / ".join(n for n in _ns if n),
        )
        for _k, _ns in sorted(_notes_by_key.items())
        if _k not in delivered_keys
    ]

    lines = ["资产清单（阶段一交付）", ""]
    lines.append(f"参考图：{stored.get('source_image') or '(未记录)'}")
    lines.append(
        f"元素数：{len(results)}    路径验证通过：{sum(1 for r in results if r.exists)}"
        + (f"    白膜占位：{placeholders}（尺寸为**预估**，见该行 size_source）"
           if placeholders else "")
    )
    lines.append(
        f"尺寸实测：{measured} 个网格量到包围盒，{no_size} 个非网格本来就没有，"
        f"{size_failed} 个没量到（原因见该行下方）"
    )
    lines.append("")
    _mat_set = set(mat_only)          # 只拿材质/材质实例顶着的行（下面打印时点名）
    def _emit_rows(rows: list[AssetListItem]) -> None:
        lines.append(f"{'元素':<16} {'状态':<6} {'尺寸 X×Y×Z (cm)':<28} {'包围盒体积 (cm³)':>18}  资产路径")
        lines.append("-" * 122)
        for r in rows:
            size_txt = "×".join(f"{v:.1f}" for v in r.size_cm) if r.size_cm else "—"
            vol_txt = f"{r.bbox_volume_cm3:,.0f}" if r.bbox_volume_cm3 is not None else "—"
            status = ("◻ 白膜" if r.is_placeholder else ("✓ 存在" if r.exists else "✗ 不存在"))
            where = r.asset_path or f"(白膜占位 {r.placeholder_shape or 'cube'}，无资产)"
            if r.element in _mat_set:
                where += "（⚠ 只有材质实例，摆不出实体 —— 见下方点名）"
            lines.append(
                f"{r.element:<16} {status:<6} {size_txt:<28} {vol_txt:>18}  {where}"
            )
            if r.note:
                lines.append(f"{'':<16} {'':<6} └ {r.note}")
            if r.size_cm is None:
                lines.append(f"{'':<16} {'':<6} └ 无尺寸原因：{r.size_source or '(未记录)'}")

    # 按大类分组打印（2026-09-24 用户要求：资产清单要分大类，能逐类看）
    _grouped: dict[str, list[AssetListItem]] = {}
    for r in results:
        _grouped.setdefault(r.category_cn or "未分类", []).append(r)
    for _cn in order_category_names(set(_grouped), _cat_table):
        lines.append("")
        lines.append(f"## {_cn}（{len(_grouped[_cn])} 项）")
        _emit_rows(_grouped[_cn])
    if _grouped.get("未分类"):
        lines.append("")
        lines.append(
            "⚠ 上面「未分类」那些：`elements.json` 里也没给它们分类 —— "
            "先用 confirm_elements 把大类表填全，再交付更清楚。"
        )
    _scene_recap, _, _ = scene_from_rows(stored.get("elements", []) or [], _cat_table)
    if _scene_recap:
        lines.append("")
        lines.append(
            "场景项（**不是资产**，已记在 catalog/elements.json）："
            + "；".join(f"{k}：{v}" for k, v in _scene_recap.items())
        )
    lines.append("")
    lines.append(
        "⚠ 口径：尺寸/体积都是**官方 get_bounds 实测的包围盒**（体积 = X×Y×Z），"
        "**不是网格实际体积**；材质/材质实例没有包围盒，记 —。"
        "⚠ 标 `◻ 白膜` 的行**例外**：那是没有可用资产、用**预估尺寸**登记的白膜占位，"
        "尺寸不是实测 —— 请重点确认；`plane`（面）类的覆盖面阶段二会用参数几何重算。"
    )
    if mat_only:
        lines.append("")
        lines.append(
            "⚠ 下面这些元素**只拿材质 / 材质实例顶着** —— 材质能做表面覆盖（路面 / 草坪），"
            "但**没有包围盒、量不出尺寸，摆不出实体**："
        )
        for _name in mat_only:
            lines.append(f"  - {_name}")
        lines.append(
            "  用户 2026-09-24 的要求是：这类元素**先给预估尺寸、登记成白膜占位**，"
            "再确认清单。**到底当表面用还是登记白膜，请用户拍板** —— "
            "本工具不替他决定（不猜是硬规则）。"
        )

    if unresolved:
        lines.append("")
        lines.append(
            "⚠ 以下元素**在元素清单里有、但本表里没有对应资产** —— 不是被删了，是没落位："
        )
        for u in unresolved:
            lines.append(f"  - {u.element_key}（元素清单里 {u.occurrences} 处）")
            if u.note:
                lines.append(f"      └ 元素清单原话：{u.note}")
        lines.append(
            "  ⚠ 本工具**不推断**原因。可能是：找不到名字对得上的资产 / "
            "本来就按光照环境处理不走资产。**要原因，得问用户。**"
            "（路径验证不通过的行走不到这里 —— 它们在交付前就被拒收了。）"
        )

    base_note = (
        "资产清单已生成并落盘（catalog/asset_list.json）。"
        + (f"其中 **{placeholders} 行是白膜占位、尺寸为预估** —— 请用户重点确认这些尺寸。"
           if placeholders else "")
        + (f"⚠ 另有 {len(mat_only)} 行**只有材质/材质实例顶着**（摆不出实体）："
           + "、".join(mat_only)
           + " —— 请用户拍板：当表面用，还是登记成白膜占位。"
           if mat_only else "")
        + "**请把 deliverable 贴给用户做最终确认。**"
    )
    delivery = AssetListDelivery(
        delivered_at=datetime.now(timezone.utc).isoformat(),
        source_image=stored.get("source_image", ""),
        total=len(results),
        verified=sum(1 for r in results if r.exists),
        placeholders=placeholders,
        # invalid_paths 恒为空：路径验不过的行在上面就被拒收了，走不到这里。
        invalid_paths=[],
        items=results,
        unresolved_elements=unresolved,
        deliverable="\n".join(lines),
        note=base_note,
    )
    # 给这张清单「签字」：记下当时的资产库指纹（best-effort —— 指纹只是"下次判定过期"
    # 的依据，不该因为它失败就把整次交付判死；但失败必须说出来，不许默默吞掉）。
    fingerprint_note = ""
    try:
        inventory, fp_calls = await library_inventory(ctx)
        digest, counts = library_fingerprint(inventory)
        save_json(LIBRARY_PATH, {
            "captured_at": delivery.delivered_at,
            "hash": digest,
            "counts": counts,
            "total": sum(counts.values()),
            "note": "confirm_assets 落盘时记的资产库指纹；只覆盖路径层面（哪些资产存在）",
        })
        fingerprint_note = (
            f"资产库指纹已记录（{sum(counts.values())} 个资产 / {fp_calls} 次枚举）—— "
            "之后 get_asset_list() 才判定得了这张表过没过期。"
        )
    except Exception as exc:
        # 这里刻意接 Exception（比 ToolError 宽一档）：交付本身已经落盘了，
        # 指纹只是"下次判定过期"的依据。而 Exception 接不住 CancelledError
        # （BaseException 子类）—— 这正是我们要的：关机/取消要能正常往外抛。
        fingerprint_note = (
            f"⚠ 资产库指纹记录失败（{type(exc).__name__}: {exc}）—— "
            "这张表下次取用时会报『没有指纹』。"
        )

    delivery = delivery.model_copy(
        update={"note": f"{delivery.note} {fingerprint_note}"}
    )
    save_json(ASSET_LIST_PATH, delivery.model_dump())
    return delivery


# --- [完工-09] 工具 6：取清单（读）---
# 实测 2026-09-23 12:12（stale=false；bush 从"还缺的元素"里消失）、12:24（items 带尺寸）。
#
# 为什么需要它（用户 2026-09-23 拍板加）：工具 5 是写表，本工具是读表 + 判定这张表
# 还作不作数。没有它，宿主只能自己去读 catalog/asset_list.json，那就绕过了 MCP，
# 等于把"用哪张表"交回给模型自觉。

@mcp.tool()
async def get_asset_list(
    ctx: Context[AppContext],
    verify_paths: Annotated[
        bool,
        Field(description="true = 逐条调官方 exists() 验活（默认）；false = 只比指纹，省调用"),
    ] = True,
    max_per_element: Annotated[
        int,
        Field(ge=1, le=20, description="每个还没落位的元素最多列几个新候选（默认 5）"),
    ] = 5,
) -> AssetListStatus:
    """取当前**权威资产清单**，并判定它**还作不作数**。动任何东西之前先调它。

    它回答四个问题：
      ① 有没有交付过清单 —— 没有就别往下走，先用 confirm_assets 落一份；
      ② 这张表还是不是签字时的那张 —— 用**资产库指纹**比（哈希 + 每类数量）；
      ③ 表里的路径**逐条**还活着吗 —— verify_paths=True 时调官方 exists() 验；
      ④ 还没落位的元素，现在出现候选了吗 —— 实况枚举后按【资产名/文件夹名】两条路匹。

    顺带把**整张表原样带出**（`items` 字段）：每行的元素、路径、类别，以及交付时
    **实测的包围盒尺寸与体积** —— "列出表"用这一个调用就够，不必去读 catalog 里的文件。

    ⚠ **只读**：不改 asset_list.json、不碰关卡、**不猜**。第 ④ 步只报"名字对得上"的候选，
      找不到就是空 —— 禁止拿别的资产顶替。
    ⚠ 指纹只覆盖**路径层面**（哪些资产存在），覆盖不了"同一个路径内容变了"
      （你把某个材质实例的贴图换了，路径没变、exists() 仍是 true）。
    ⚠ **开场先查状态**：讲流程 / 给方案 / 报进度**之前**先调本工具 —— 不是「动东西之前」，
      是「**开口之前**」。状态只认本工具的**返回值**，不认文件里叙述性的旧措辞
      （例：`plan_v1.json` 里那句「参数或几何均未变，沿用上一次确认」——
      实际参数后来改过，那行文案早已过期）。
    ⚠ 宿主**不许**用上下文里记得的旧表；每次开工都必须重新调本工具。
    """
    delivery = load_json(ASSET_LIST_PATH)
    elements_doc = load_json(ELEMENTS_PATH) or {}
    elements = [
        e.get("element", "")
        for e in elements_doc.get("elements", [])
        if isinstance(e, dict) and e.get("element")
    ]
    # 场景项不是资产、永远不会出现在资产清单里 —— 不许算成"未落位元素"（假缺口）
    _tbl_all = load_categories()
    _scene_names = {
        str(e.get("element") or "")
        for e in elements_doc.get("elements", [])
        if isinstance(e, dict) and is_scene_category(str(e.get("category") or ""), _tbl_all)
    }
    elements = [e for e in elements if e not in _scene_names]
    _scene_out, _scene_size, _scene_time = scene_from_rows(
        elements_doc.get("elements", []) or [], _tbl_all
    )
    warnings: list[str] = []
    calls = 0

    # 情况 0：压根没交付过清单 —— 这不是错误，是一种明确状态
    if not delivery:
        return AssetListStatus(
            has_list=False,
            stale=None,
            missing_elements=elements,
            next_step=(
                "还没有交付过资产清单：先 confirm_elements 记元素、plan_assets 找资产，"
                "再用 confirm_assets 落一份表（它会顺手给表记上资产库指纹）。"
                "**在这之前没有任何『权威清单』可用 —— 禁止凭上下文里的旧表干活。**"
            ),
            warnings=["catalog/asset_list.json 不存在。"],
        )

    items = delivery.get("items", []) or []
    # 表里每一行原样带出（含交付时实测的尺寸/体积），不做二次加工
    rows = [
        AssetListRow(
            element=str(it.get("element") or ""),
            element_key=str(it.get("element_key") or ""),
            category=str(it.get("category") or ""),
            category_cn=str(it.get("category_cn") or ""),
            asset_path=str(it.get("asset_path") or ""),
            asset_type=str(it.get("asset_type") or ""),
            is_placeholder=bool(it.get("is_placeholder")),
            placeholder_shape=str(it.get("placeholder_shape") or ""),
            size_cm=it.get("size_cm"),
            bbox_volume_cm3=it.get("bbox_volume_cm3"),
            size_source=str(it.get("size_source") or ""),
            note=str(it.get("note") or ""),
        )
        for it in items
    ]

    inventory, calls = await library_inventory(ctx)
    live_hash, live_counts = library_fingerprint(inventory)

    signed = load_json(LIBRARY_PATH)
    if signed:
        signed_hash = signed.get("hash", "")
        signed_counts = signed.get("counts", {}) or {}
        stale = signed_hash != live_hash
    else:
        signed_hash, signed_counts, stale = "", {}, None
        warnings.append(
            "这张清单**没有指纹**（是旧版本 confirm_assets 落的，或指纹文件被删了）。"
            "重跑一次 confirm_assets 就能给它签字，之后才判定得了『还作不作数』。"
        )

    changed = describe_count_changes(signed_counts, live_counts) if signed else []

    checks: list[PathCheck] = []
    if verify_paths:
        for it in items:
            if it.get("is_placeholder"):
                continue      # 白膜占位没有路径 —— 不许拿空串去 exists()
            path = it.get("asset_path", "")
            entry = PathCheck(element=it.get("element", ""), asset_path=path, ok=False)
            try:
                exists = await call_official(
                    ctx, "exists", {"path": path}, toolset=TS_ASSET
                )
                calls += 1
                entry.ok = exists is True or (
                    isinstance(exists, str) and exists.lower() == "true"
                )
            except ToolError as exc:
                calls += 1
                entry.error = str(exc)
            checks.append(entry)
    dead = [c.asset_path for c in checks if not c.ok]

    covered, mode = element_keys_from_items(items)
    missing = [e for e in elements if e.lower().strip() not in covered]
    found: dict[str, list[str]] = {}
    for kw in missing:
        cands = candidates_for(kw, inventory, max_per_element)
        if cands:
            found[kw] = [c.path for c in cands]

    # 缺失再按大类分一次组（2026-09-24 用户要求分大类）
    _cat_table = load_categories()
    _cat_by_element = {
        str(e.get("element") or ""): str(e.get("category") or "")
        for e in elements_doc.get("elements", []) if isinstance(e, dict)
    }
    _miss_cat: dict[str, list[str]] = {}
    for kw in missing:
        _miss_cat.setdefault(category_cn(_cat_by_element.get(kw, ""), _cat_table), []).append(kw)
    missing_by_cat = {cn: _miss_cat[cn]
                      for cn in order_category_names(set(_miss_cat), _cat_table)}

    # 按优先级给出下一步（死路径 > 过期 > 有新候选 > 可以用）
    if dead:
        next_step = (
            f"⚠ 表里有 {len(dead)} 条路径**已经不存在**（见 dead_paths）。"
            "**先让用户处理掉**（重新给路径，或明确确认跳过），再往下走 —— "
            "否则下一阶段会挂上一个解析不到的材质/网格。"
        )
    elif stale:
        next_step = (
            f"资产库指纹变了（{'；'.join(changed) or '数量未变，路径集合变了'}），"
            "**这张表已不是签字时的那张**。把差异摆给用户，让他决定："
            "是重跑 confirm_assets 出新表，还是先查清这次变化。"
        )
    elif found:
        names = "、".join(found)
        next_step = (
            f"清单本身是活的，但发现了**新候选**（{names}）。"
            "把候选原样报给用户确认用哪一个，确认后再 confirm_assets 更新表 —— **不许自己挑**。"
        )
    else:
        _ph = sum(1 for it in items if it.get("is_placeholder"))
        next_step = (
            "清单 fresh、路径全部存活，可以用。"
            + (f"⚠ 表里有 {_ph} 行**白膜占位**（尺寸是**预估**、不是实测）—— "
               "用之前要让用户确认过这些尺寸。" if _ph else "")
            + "⚠ 照实说明：指纹只保证**路径有效**，不保证**同名资产的内容没被改过**。"
        )

    return AssetListStatus(
        has_list=True,
        delivered_at=delivery.get("delivered_at", ""),
        source_image=delivery.get("source_image", ""),
        total=len(items),
        placeholders=sum(1 for it in items if it.get("is_placeholder")),
        items=rows,
        stale=stale,
        signed_at=signed.get("captured_at", "") if signed else "",
        signed_hash=signed_hash,
        signed_counts=signed_counts,
        live_hash=live_hash,
        live_counts=live_counts,
        changed_types=changed,
        path_check=checks,
        dead_paths=dead,
        missing_elements=missing,
        missing_by_category=missing_by_cat,
        scene=_scene_out,
        new_candidates=found,
        coverage_mode=mode,
        official_calls=calls,
        next_step=next_step,
        warnings=warnings,
    )


# --- 阶段二辅助：参数合并 / 摘要 / 闸门取数 -------------------------------------

_PLANNING = None


def _planning_modules():
    """取规划层模块（plan）—— 惰性导入，带两种启动方式的兜底。

    为什么不在文件顶部 import（2026-09-23 血账，两次炸 server 的第二次）：
      ① 启动方式不兼容：宿主是按脚本方式起这个文件的
         （`python F:\\MCP_Server\\src\\mcp_server\\main.py`），这时 `__package__` 是空的，
         顶部写 `from .planning import ...` 会直接抛
         `ImportError: attempted relative import with no known parent package`
         —— 整个 server 起不来（宿主侧表现为 mcp-client(mine) 重连 7 次全败）。
      ② 不该连坐：规划层出任何问题，都不该把阶段一那 6 个工具一起带崩。
    """
    global _PLANNING
    if _PLANNING is not None:
        return _PLANNING

    errors: list[str] = []
    try:
        from .planning import plan as p
    except ImportError as exc:
        errors.append(f"相对导入失败：{exc}")
        # 脚本方式下 __package__ 为空，相对导入必失败 —— 自己把本文件所在目录放进
        # sys.path 再按顶层包导入。别依赖"宿主会把脚本目录加进 sys.path"（runpy 就不加）。
        here = str(Path(__file__).resolve().parent)
        if here not in sys.path:
            sys.path.insert(0, here)
        try:
            from planning import plan as p
        except ImportError as exc2:
            errors.append(f"顶层导入失败：{exc2}")
            # 两个错误都带上：只报第一个会让人查错方向
            raise ToolError("阶段二规划层导入失败（阶段一工具不受影响）："
                            + "；".join(errors)) from exc2
    _PLANNING = p
    return _PLANNING


def _planning_classify(previous: dict) -> tuple[set, set, str, bool, list[str]]:
    """判「哪些元素来自阶段一」「哪些没有可用资产」→ `(known, no_asset, 来源说明, 判没判出来, 警告)`。

    ⚠ **判据来源分两层**（2026-09-24 用户拍板按这个改）：
      ① **首选 `catalog/asset_list.json`** —— 它是阶段一**交付**的清单，
         `is_placeholder=true` 的行就是"没有可用资产"，这是**权威判据**；
      ② 读不到 → **不冒充判过**（返回 `判没判出来=False`）：旧 `elements.json` 里根本没有
         `is_placeholder` 字段，只看"asset_path 空"会把 `sky` 那种"本来就不走资产"的元素
         和 `road/grass` 那种"有材质但登记成白膜"的元素混在一起 —— 宁可不判，不许乱判。

    为什么不用 `get_asset_list()`（那个 MCP 工具）：它每次会实况枚举整个资产库
    （6 次官方调用），而这里只需要本地两份小文件；本工具本来就是离线的。
    """
    known = {str(e.get("element") or "").strip().lower()
             for e in (previous.get("rows") or []) if e.get("element")}
    warnings: list[str] = []

    # --- ① 交付清单（权威）---
    delivered = load_json(ASSET_LIST_PATH) or {}
    rows = [it for it in (delivered.get("items") or []) if isinstance(it, dict)]
    delivered_keys = {str(it.get("element_key") or "").strip().lower() for it in rows}
    delivered_keys.discard("")
    has_flag = any("is_placeholder" in it for it in rows)

    if rows and has_flag:
        no_asset = {str(it.get("element_key") or "").strip().lower() for it in rows
                    if bool(it.get("is_placeholder"))}
        no_asset.discard("")
        src = (f"catalog/asset_list.json（交付清单，{delivered.get('delivered_at', '时间未记')}，"
               f"{len(rows)} 行 / {len(no_asset)} 个无资产）")
        # 阶段一记过、但交付清单里没有的元素 → 报出来（不许静默漏）
        not_delivered = sorted(known - delivered_keys)
        if not_delivered:
            warnings.append(
                "这些元素**在阶段一记过、但交付清单里没有**：" + "、".join(not_delivered)
                + "。它们可能本来就不走资产（如 sky 按光照环境处理）—— "
                "**要摆它们之前先向用户确认**，别当成漏了。"
            )
        return known, no_asset, src, True, warnings

    # --- ② 判不出来：不冒充判过 ---
    if not rows:
        src = "catalog/asset_list.json **读不到** —— 判不出哪些元素没有可用资产（这条**没验**）"
        warnings.append("读不到 catalog/asset_list.json —— 白膜判据**没法判**，请留意。")
    else:
        src = ("catalog/asset_list.json 还是**旧格式**（行里没有 is_placeholder 字段）—— "
               "判不出哪些元素没有可用资产（这条**没验**）")
        warnings.append(
            "catalog/asset_list.json 还是**旧格式**（行里没有 is_placeholder 字段）—— "
            "白膜判据**没法判**。重跑一次阶段一的 confirm_assets 会补上这个字段。"
        )
    return known, set(), src, False, warnings


def _sync_scene_map_size(new_size, why: str) -> str:
    """把阶段二定下来的世界大小**回填**进阶段一的 `catalog/elements.json`（场景项「地图大小」）。

    为什么必须由**代码**干这件事（2026-09-24 用户要求 #6）：阶段一记的「地图大小」是从参考图
    **目测**来的，阶段二把确认过的元素一排，常常发现装不下（实测：记 120×30，实际进深要
    38.7 m → 120×40）。以前这件事只能**靠人手工回填** —— 换个 agent 就会忘，于是阶段一 /
    阶段二两份交付物**永久对不上**（`plan.world` 说自己被"调用方覆盖"、`elements.json` 还写着旧值）。
    现在由 `generate_plan` 在"调用方覆盖了 `world.size`"时**自动同步**，谁都不需要记得。

    只动 `map_size` 那一行 + 两个派生字段（`scene` / `scene_map_size_m`），其余原样保留；
    回填写进该行 `note`（谁改的、什么时候、原值多少 → 新值多少）。返回一句人话（没改则空串）。
    """
    doc = load_json(ELEMENTS_PATH) or {}
    rows = doc.get("elements")
    if not isinstance(rows, list):
        return ""
    target = None
    for e in rows:
        if isinstance(e, dict) and str(e.get("category") or "") == "map_size":
            target = e
            break
    if target is None:
        return ""
    try:
        old = [float(v) for v in (target.get("size_m") or [])][:2]
    except (TypeError, ValueError):
        old = []
    new = [float(new_size[0]), float(new_size[1])]
    if old == new:
        return ""                       # 已经一致：什么都不做（幂等 —— 重复调用不会刷出多条备注）
    old_txt = "×".join(f"{v:g}" for v in old) if old else "没记"
    target["size_m"] = new
    target["note"] = (str(target.get("note") or "").rstrip()
                      + f"\n【由阶段二回填】{datetime.now(timezone.utc).isoformat()}："
                        f"阶段一原记 {old_txt} m，{why} → 回填为 {new[0]:g}×{new[1]:g} m。")
    scene = dict(doc.get("scene") or {})
    scene["地图大小"] = f"{new[0]:g}×{new[1]:g} m（预估）"
    doc["scene"] = scene
    doc["scene_map_size_m"] = new
    save_json(ELEMENTS_PATH, doc)
    return (f"阶段一记的『地图大小』（{old_txt} m）与这版世界 {new[0]:g}×{new[1]:g} m 不一致 —— "
            "**已由代码回填**进 catalog/elements.json 的 map_size 行（免得两份交付物对不上；"
            "这种事不许靠人记得）。")


def _planning_measured() -> tuple[dict, set, bool, str]:
    """读交付清单里的**实测**占地 → `(路径→(X米,Y米), 有资产的元素集, 判没判出来, 说明)`。

    为什么要它（2026-09-24 收尾清单 #1）：AGENTS 的口径是"已有资产占地 = 阶段一**实测**
    包围盒 × `scale`"，可这条以前**没人查** —— 把 `footprint_m` 随手改成两倍，自检照样全绿。

    口径：官方 `get_bounds` 的实测值落在 `catalog/asset_list.json` 的 `size_cm`（**厘米**、三维）；
    本函数只取前两位转成米（`Z` 那一维是白膜的高度，由阶段二自己的 `height_m` 记）。
    只认 `is_placeholder=false` 的行 —— 白膜行没有实体，不参与这条对账。
    """
    delivered = load_json(ASSET_LIST_PATH) or {}
    rows = [it for it in (delivered.get("items") or []) if isinstance(it, dict)]
    if not rows:
        return {}, set(), False, "catalog/asset_list.json 读不到 —— 实测尺寸这条**没验**"

    expected: dict[str, tuple] = {}
    asset_keys: set[str] = set()
    for it in rows:
        if bool(it.get("is_placeholder")):
            continue
        path = str(it.get("asset_path") or "").strip()
        size = it.get("size_cm")
        if not path or not (isinstance(size, (list, tuple)) and len(size) >= 2):
            continue
        try:
            expected[path] = (float(size[0]) / 100.0, float(size[1]) / 100.0)
        except (TypeError, ValueError):
            continue
        asset_keys.add(str(it.get("element_key") or "").strip().lower())
    asset_keys.discard("")
    note = (f"catalog/asset_list.json（交付清单，{delivered.get('delivered_at', '时间未记')}："
            f"{len(expected)} 个资产路径有实测尺寸 / {len(asset_keys)} 个元素有资产）")
    return expected, asset_keys, True, note


def _planning_snapshot_check() -> list[str]:
    """查「交付清单和资产库指纹是不是**同一次签字**」→ 警告列表（只读、离线）。

    ⚠ **照实说清它查不出什么**：本工具是**离线**的（刻意的 —— 阶段二不依赖 UE，编辑器关着
    也能跑），所以"资产库**后来**变了"这件事它查不出来 —— 那要调 `get_asset_list()`
    （只有它会实况枚举 + 判过期）。这里只保证两份交付物**互相对得上**：
    `asset_list.json` 的 `delivered_at` 应当 == `library_snapshot.json` 的 `captured_at`。
    """
    warnings: list[str] = []
    delivered = load_json(ASSET_LIST_PATH) or {}
    if not delivered.get("items"):
        return warnings                      # 还没交付过清单：由阶段一那边去管，这里不喊
    snapshot = load_json(LIBRARY_PATH) or {}
    if not snapshot:
        warnings.append(
            "读不到 catalog/library_snapshot.json —— 这份交付清单**没有资产库指纹**，"
            "『清单没过期』这件事**没验**（要验请调 get_asset_list()）。"
        )
        return warnings
    d_at = str(delivered.get("delivered_at") or "")
    s_at = str(snapshot.get("captured_at") or "")
    if d_at and s_at and d_at != s_at:
        warnings.append(
            f"交付清单与资产库指纹**不是同一次签字**（清单 {d_at} / 指纹 {s_at}）—— "
            "要么清单被手改过、要么指纹被单独换过。用之前先调 get_asset_list() 查实况。"
        )
    if not snapshot.get("hash"):
        warnings.append("catalog/library_snapshot.json 里没有 hash —— 指纹不可用。")
    return warnings


def _summarize(plan: dict) -> PlanSummary:
    """从放置数据里数几个数出来。"""
    checks = plan.get("checks", [])
    failed = [c.get("name", "?") for c in checks if not c.get("ok")]
    world = plan.get("world", {}) or {}
    return PlanSummary(
        world_center=world.get("center", []) or [],
        world_size=world.get("size", []) or [],
        assets=len(plan.get("assets", []) or []),
        whiteboxes=len(plan.get("whiteboxes", []) or []),
        checks_total=len(checks),
        checks_failed=len(failed),
        failed_names=failed,
    )


def _gate_model(g: dict) -> PlanGate:
    """把 planning.gate_check() 的字典转成模型（显式取字段，不吃多余键）。"""
    return PlanGate(
        confirmed=bool(g.get("confirmed")),
        params_hash_ok=bool(g.get("params_hash_ok")),
        plan_hash_ok=bool(g.get("plan_hash_ok")),
        confirmed_by=g.get("confirmed_by", "") or "",
        confirmed_at=g.get("confirmed_at", "") or "",
        params_hash=g.get("params_hash", "") or "",
        plan_hash=g.get("plan_hash", "") or "",
    )


def _write_plan(plan: dict) -> dict:
    """落盘计划数据 —— 交给 `planning.write_plan()`（**全工程唯一写入点**）。

    为什么改成委托（2026-09-24 收尾清单 #4 / #8）：写盘之外还要**给上一版留档**、
    还要**清除不认这份数据的图**，而 CLI 的 `--confirm` 也走同一份逻辑 —— 写入点只能有一个，
    否则两条路迟早写出不一样的文件。返回它的结果字典（留档名 / 清掉的图 / 留下的图）。
    （净化 `-0.0` / 禁用 NaN 都在 `write_plan` 里，行为与原先逐字一致。）
    """
    planning = _planning_modules()
    return planning.write_plan(plan)


# --- [完工-12] 工具 7：generate_plan（阶段二 · 记放置表；写）---
# 实测 2026-09-23（旧版几何骨架）：改地块面宽 12→15 时自检全过、几何指纹可复现。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   工具面仍是 9 个、本工具经 MCP 端到端调用正常；confirm_assets 两条"该拒就拒"的断言也绿。
# ⚠ 指纹计算必须内部净化 -0.0（内存对象带 -0.0、落盘是 0.0，两边哈希就不等，
#   于是对着刚写进去的数据喊"文件被改过"）—— 预检第 ⑤ 项就是这条的回归检查。
# ⚠ 2026-09-24（四）按用户新规格整段换掉（只记元素放置，路网/地块骨架删除）。
# ✅ 2026-09-24（六）实测：「空表落盘」这条分支已验（generate_plan() 不带参数 → 两张表空、
#   自检 7/0；同 payload 重跑后指纹逐位回到 6674990729…）。
# ⚠ 2026-09-24（八）收尾清单 #1/#2/#3/#4/#6 落地：新增对账三条 + cube 高度一条自检（7 → 11 项）、
#   白膜 `height_m`、清单与指纹同源检查、**落盘改为 `write_plan()`（唯一写入点 + 上一版留档
#   + 自动清除不认账的图）**、**覆盖 world.size 时自动把新值回填进阶段一的 map_size 行**
#   （回填放在两份表校验通过之后），**初始化态（两张表都空）下覆盖类自检标"不适用"**，
#   保证 `generate_plan()` 空跑依旧全绿。
# ✅ 2026-09-24（八）实测（新代码上线后经 MCP 调用观察到）：
#   · 自检 **11 项 0 失败**在真数据上跑通（含 ⑧⑨⑩ 对账、⑪ cube 高度）；
#   · **自动回填阶段一**生效：catalog/elements.json 的『地图大小』= 100×60 m，
#     且数据里 `previous_elements.scene` 也是 100×60（回填后"重读阶段一"的直接证据）；
#   · **自动留档 + 自动清图**生效：views/archive/ 里 6 份 plan_v1_* 数据 + 4 张被清走的旧图；
#   · 新写入的数据里**没有 `status` 字段**（#5 生效）；
#   · 交付清单与资产库指纹快照**同一次签字**（captured_at == delivered_at = 12:17:50.970736Z）→ #3 无告警。
# ⚠ **仍未实测**：`confirm_plan`（MCP / CLI）改完后没被调过 —— "图不认数据就拒收"那条闸
#   与"确认时留档 / 清图"等第一次真确认再补证据。

# --- 工具 7：记录平面放置表（阶段二 · 写）--------------------------------------
# 本工具不依赖 UE：纯 2D 几何校验，编辑器关着也能跑。

@mcp.tool()
async def generate_plan(
    assets: Annotated[
        list[dict] | None,
        Field(description=(
            "**已有资产**的放置表（一物一行）。每行："
            "`element_key`（要与阶段一的元素名一致）、`label`（同类多个要能区分，如「行道树 #7」）、"
            "`asset_path`、`pos`（平面中心坐标 [X, Y]，米）、`footprint_m`（占地 [宽, 深]，米）、"
            "`rot_deg`（绕 Z 逆时针，度）、`scale`（模型缩放倍率）、`note`。"
            "⚠ **没有 count 字段**：摆 20 栋就写 20 行 —— 一条记录只能有一个 pos。"
        )),
    ] = None,
    whiteboxes: Annotated[
        list[dict] | None,
        Field(description=(
            "**白膜占位**的放置表（一物一行）。每行："
            "`element_key`、`label`、`shape`（cube / plane）、`pos`、`footprint_m`、"
            "`rot_deg`、`size_source`（**必须写明是「预估」**）、`note`；`asset_path` 留空。"
            "⚠ `shape=cube` 的**必须再给 `height_m`**（高度，米）—— 阶段一的白膜本来就有第三维"
            "（`size_cm` 的 Z），阶段六要靠它把 cube 实例化出来；缺了自检第⑪项会报出来。"
            "`plane`（覆盖面）不用给高度。"
            "⚠ 只许放**阶段一里没有可用资产**的元素（没找到的 / 只有材质实例顶着的）。"
            "⚠ **必须等已有资产放完之后再填这张表** —— 先占位，才知道白膜剩哪儿、该多大。"
        )),
    ] = None,
    world: Annotated[
        dict | None,
        Field(description=(
            "覆盖世界信息（一般不用传）：`center`（平面中心坐标，默认 **[0, 0]**）、"
            "`size`（[X, Y] 米，默认取阶段一记录的「地图大小」）。"
            "不传 = 用默认。传送了会在数据里标成「调用方覆盖」。"
        )),
    ] = None,
    params: Annotated[
        dict | None,
        Field(description=(
            "**这一版是怎么定的**（自由文本，记进数据的 `params` 段，用于留痕与复现）："
            "如 `{\"依据\": \"参考图纵深/沿街长估计\", \"用户意见\": \"主楼再往左 3 m\"}`。"
            "⚠ 改它会让几何指纹变化 → 上一版确认自动作废。"
        )),
    ] = None,
) -> PlanResult:
    """把**平面放置表**落盘成 `views/plan_v1.json` 并自检 —— 阶段二主工具（记录，不是规划）。

    三件事：
      ① 校验并规整：一物一行、每行必须有 `pos` 与 `footprint_m`（米）；
      ② 自检（**11 项**，具名）：两两不重叠（资产内 / 白膜内 / **白膜不压资产**）
         + 四角在世界边界内 + 元素必须来自阶段一 + 白膜只用在"阶段一没有可用资产"的元素上
         + **阶段一↔阶段二对账三条**（占地 = 实测包围盒 × `scale` / 有资产的元素都落了位 /
         无资产的元素都落了位）+ **cube 白膜记了高度**；
      ③ 落盘 + 钉**几何指纹**（除 `confirmation` 外全部内容，`params` 也算进去）
         + **给上一版留档**（`views/archive/`）。

    ⚠ **本工具不规划坐标** —— 坐标由**你**看图+按用户要求规划好再传进来。
    ⚠ **本工具不出图**（2026-09-24 用户拍板：别用定死的模板画）。`image_path` 恒为空；
      要给人看，**你自己拿 `data_path` 里的数据画** —— 每条记录就是「中心 + 占地 + 朝向」，
      画法由你定，不写死在代码里。画完记得**图内写上当前几何指纹**：`confirm_plan` 会拿它
      核对"图认不认这份数据"（收尾清单 #8）。
    ⚠ **单位是米**（到 UE / Blender 那层才 ×100 转厘米）。
    ⚠ **顺序不能反**：先放**已有资产**（占地大小 = 阶段一实测包围盒 × `scale`，是**定的**），
      再放**白膜**（占地要等资产占完位在剩余空间里**重新估**）。
    ⚠ **一个物体一行**：摆多少写多少行。用一条记录 + 数量代表多个不同位置的物体 =
      自检**看不见**那些没记录的物体（自检全绿、实际重叠）。
    ⚠ **谁能进白膜表**：`plan_assets` 报 missing 的、或只有材质实例顶着的元素
      （`placeholder_hint` 非空的那些）—— 这条由自检强制。
    ⚠ **本工具不联网、不碰 UE**（离线是刻意的）：所以"资产库**后来**变过没有"它查不出来 ——
      它只保证交付清单与资产库指纹**是同一次签字**；要查实况请调 `get_asset_list()`。
    ⚠ **覆盖 `world.size` 会顺手回填阶段一**：阶段一记的『地图大小』是目测值，装不下时你覆盖
      世界大小 —— 本工具会把新值**自动写回 `catalog/elements.json`** 的 `map_size` 行（并在
      `warnings` 里报出来），免得阶段一 / 阶段二两份交付物对不上。**这件事不许靠人记得。**
      （顺序上：两份放置表**校验通过之后**才回填 —— 负载被拒收时一个字节都不动。）
    ⚠ **落盘会顺手清除不认这份数据的图**（别的版本的图移进 `views/archive/`）：图是"用户确认过
      那一版"的凭据，数据一改旧图就没人认过 —— 留在 `views/` 只会误导人。**同样不许靠人记得。**
    ⚠ 自检**报失败名字**：把 `summary.failed_names` 和每项的 `bad` 明细贴给用户，不许只说"自检通过"。
    """
    planning = _planning_modules()

    # --- 读阶段一：世界大小从这儿来，元素的"合法性"也按它判 ---
    previous = planning.load_previous_elements()
    if not previous["rows"]:
        raise ToolError(
            "读不到阶段一的元素清单（catalog/elements.json）—— "
            "世界大小与『元素是否来自阶段一』都要靠它。请先在阶段一 confirm_elements。"
        )
    try:
        world_full, world_changed = planning.normalize_world(world, previous["scene"], previous)
    except ValueError as exc:
        raise ToolError(f"世界信息不成立：{exc}") from exc

    # --- 规整两份放置表（不合规当场拒收，一个都不落盘）---
    norm_assets: list[dict] = []
    norm_boxes: list[dict] = []
    try:
        for raw in (assets or []):
            norm_assets.append(planning.normalize_asset(raw))
        for raw in (whiteboxes or []):
            norm_boxes.append(planning.normalize_whitebox(raw))
    except ValueError as exc:
        raise ToolError(f"放置表拒收：{exc}") from exc

    # --- 世界被覆盖过 → **顺手把新大小回填进阶段一**（2026-09-24 收尾清单 #6）---
    # 为什么放在"两份表校验通过之后"：负载要是被拒收，就**一个字节都不该动** ——
    #   包括阶段一那份文件（之前放在 normalize_world 后面，等于被拒的调用也改了阶段一）。
    # 为什么由代码做：不这么做，阶段一的『地图大小』永远停在目测值上，而阶段二的世界是另一个数 ——
    #   两份交付物对不上，且**只能靠人手改**（换个 agent 就忘）。
    # 回填之后重新读一次阶段一，好让本版数据里的「阶段一记录」跟着更新（别留一个假来源）。
    sync_note = ""
    if world_changed and "world.size" in world_changed:
        try:
            sync_note = _sync_scene_map_size(
                world_full["size"],
                why=f"generate_plan 按确认过的元素把世界覆盖为 "
                    f"{world_full['size'][0]:g}×{world_full['size'][1]:g} m")
        except OSError as exc:
            sync_note = (f"⚠ 想把新世界大小回填进阶段一（catalog/elements.json）但写不进去：{exc}"
                         " —— 阶段一那份表还是旧值，两份交付物暂时对不上。")
        else:
            if sync_note:
                previous = planning.load_previous_elements()

    # --- ⚠ 允许两份表都空（2026-09-24 用户要求）---
    # 为什么允许：结构要能"先立起来、内容是空的" —— 图还没来的时候，坐标根本没有依据
    # （pos 的依据就是参考图）。所以空表不是错误，它是**初始化状态**。
    # 但它**不是可确认的规划**：`confirm_plan` 会拒收（空表），`get_plan` 报 status=initialized
    # 依然不许在没给用户看过图的情况下确认（见那边的 docstring）。
    empty = not norm_assets and not norm_boxes

    # 「哪些元素来自阶段一」「哪些没有可用资产」—— 判据优先读交付清单（见 _planning_classify）
    _known, _no_asset, _no_asset_src, _no_asset_known, warnings = _planning_classify(previous)

    # 实测尺寸（按资产路径）+ "有资产"的元素集 —— 阶段一 ↔ 阶段二对账要用（收尾清单 #1）
    _expected, _asset_keys, _measured_ok, _measured_note = _planning_measured()
    if not _measured_ok:
        warnings.append(
            "读不到交付清单里的实测尺寸 —— 『占地 = 阶段一实测包围盒 × scale』这条对账**没验**。"
        )
    # 清单与资产库指纹是不是同一次签字（收尾清单 #3；本工具离线，查不了"库后来变过没有"）
    warnings.extend(_planning_snapshot_check())

    plan = planning.build_plan(norm_assets, norm_boxes, world_full,
                               params=params or {}, previous=previous,
                               known=_known, no_asset=_no_asset,
                               source_note=_no_asset_src,
                               no_asset_known=_no_asset_known,
                               expected=_expected, asset_keys=_asset_keys,
                               measured_ok=_measured_ok, measured_note=_measured_note)

    if world_changed:
        warnings.append(f"世界信息被覆盖过：{world_changed}（已在数据里标成『调用方覆盖』）。")
    if sync_note:
        warnings.append(sync_note)
    if empty:
        warnings.append(
            "这是**初始化状态**（两张表都空）：`assets` / `whiteboxes` 里没有任何 pos —— "
            "坐标的依据（参考图）还没来。填完内容之后它就是一份 draft（`status` 由 get_plan "
            "现算，文件里不再写这个字段），那时才谈得上确认。"
        )
    elif not norm_boxes:
        warnings.append(
            "白膜表是空的：如果阶段一里还有『没找到资产 / 只有材质实例顶着』的元素，"
            "它们**还没落位** —— 别当成「摆完了」。"
        )
    # 一物一行：同类多个时提醒 agent 报的是个体数，不是阶段一的目视个数
    from collections import Counter as _Counter
    _by_key = _Counter(a["element_key"] for a in norm_assets)
    if any(c > 1 for c in _by_key.values()):
        warnings.append(
            "同类资产有多条（个体级放置）："
            + "、".join(f"{k}×{c}" for k, c in sorted(_by_key.items()) if c > 1)
            + "。⚠ 阶段一的 `count` 是**画面目视估计**，跟这里的个体数不是一回事 —— "
            "数字对不上是允许的，但要请用户确认过。"
        )

    # 几何一模一样 → 沿用上次确认（重算一遍不该把确认弄丢）
    if planning.OUT_JSON.exists():
        old_conf = (json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
                    .get("confirmation", {}) or {})
        if (old_conf.get("confirmed")
                and old_conf.get("plan_hash") == plan["confirmation"]["plan_hash"]):
            plan["confirmation"].update({
                "confirmed": True,
                "confirmed_by": old_conf.get("confirmed_by", ""),
                "confirmed_at": old_conf.get("confirmed_at", ""),
                "note": "几何未变，沿用上一次确认。",
            })
        elif old_conf.get("confirmed"):
            warnings.append(
                "这一版与上一次确认的**不是同一版**：上次确认**已作废**，"
                "必须重新拿给用户/客户确认。"
            )

    planning.VIEWS_DIR.mkdir(parents=True, exist_ok=True)
    written = _write_plan(plan)

    # 落盘时**代码自动清除**了不认这份数据的图（收尾清单 #8 加码）—— 报出来，别静默
    if written.get("removed_figures"):
        warnings.append(
            "已自动清除**不认这份数据**的图（移进 views/archive/）："
            + "；".join(written["removed_figures"])
            + "。要拿去让用户确认，请**按当前数据重画一张**（图内写明几何指纹 "
            + f"{plan['confirmation']['plan_hash'][:10]}…）。"
        )
    if written.get("archived"):
        warnings.append(f"上一版 plan_v1.json 已留档：views/archive/{written['archived']}。")

    return PlanResult(
        stage="阶段二 · 平面放置规划",
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=_summarize(plan),
        gate=_gate_model(planning.gate_check(plan)),
        changed_params=world_changed,
        next_step=(
            (
                "**当前是初始化状态**（两张表都空）：结构已按新口径立好，但没有任何坐标 —— "
                "**因为坐标的依据是参考图，图还没来**。下一步：拿到用户上传的图、"
                "过完阶段一（提元素 → 用户确认 → 找资产 → 交付清单）之后，"
                "你按图规划每件东西的 `pos` / `footprint_m`，再调本工具填进去。"
                "**别在没图的时候编坐标**（编了就是替用户决定，且违反『不猜』）。"
                if empty else
                "本工具**不规划坐标**，所以："
                "① 拿 `data_path`（plan_v1.json）的数据**画一张图给用户看**"
                "（每条记录就是中心 + 占地 + 朝向，米制）—— 用户**读不懂坐标**，"
                "**图是他唯一能参与确认的方式**；"
                "② 把 `summary.failed_names` 与各 check 的 `bad` 明细**原样**报出来；"
                "③ 用户说不行 → 按他的意思改 `pos` / `footprint_m` / `scale` 再调一次本工具，"
                "**重复到他说无误为止**；"
                "④ 他说无误 → `confirm_plan(确认人)` 落痕。**确认之前不许进第三阶段。**"
            )
        ),
        warnings=warnings,
    )


# --- [完工-11] 工具 8：get_plan（阶段二 · 读）---
# 实测 2026-09-23（重启后经 MCP 调用）：has_plan=true、自检 14 项 0 失败、
# gate.confirmed=false（闸门正确拦着）；预检 ⑤ 绿。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：工具面 9 个、本工具在链上正常。
# ⚠ 2026-09-24（三、四）改过本块逻辑与文案（闸门只剩几何指纹一道；不再有图；新增 status 判断
#   `initialized` / `draft` / `confirmed`）。其中 **status=initialized 那条分支尚未实测**。
# ⚠ 2026-09-24（五）更正本工具参数说明书里残留的旧口径（原先写着「这份几何只是等宽骨架 /
#   地块按固定面宽等宽剖分」—— 那套几何已删除，本数据是放置表）。**纯注释，不影响行为**。
# ✅ 2026-09-24（八）实测（新代码上线后经 MCP 调用观察到）：
#   · 三值由本工具**现算**：文件里已经**不写 `status`**，本工具照样报 draft / initialized；
#   · 真数据上跑通 `checks_total=11 / failed=0`（比旧版多 4 项：对账三条 + cube 高度）；
#   · 新增的"图认不认这份数据"告警生效：当前那张图内写有当前指纹前 10 位 → **不报警**；
#     初始化态按设计跳过图检查（不喊）。

# --- 工具 8：取规划（阶段二 · 读）----------------------------------------------

@mcp.tool()
async def get_plan(
    include_plan: Annotated[
        bool, Field(description="true = 连完整计划数据一起带出（默认）；false = 只给闸门状态与摘要")
    ] = True,
) -> PlanStatus:
    """取当前规划几何 + 判定**它还作不作数**。**动第三阶段之前必须先调它。**

    回答四件事：
      ① 有没有算过规划；
      ② **确认了没有**；
      ③ 确认之后**几何改过没有**（几何指纹对不对得上 —— 唯一那道闸）；
      ④ 几何自检过没过（`checks_failed` 必须为 0）。
      （⑤ 老版还问"几何是否只来自参数、不读那张 PNG" —— 现在没图了，这条自动成立。）

    ⚠ **这份数据是「平面放置表」，不是几何骨架**（2026-09-24 用户重定义）：世界中心 / 大小
      + `assets[]`（已有资产，占地 = 阶段一实测包围盒 × `scale`）+ `whiteboxes[]`（白膜占位，
      占地要等资产占完位在剩余空间里重估），**一个物体一行、每行自带 `pos`**；
      旧版那套路网 / 地块 / 绿化区 / 禁放区的写死几何**已整段删除**，本数据里没有它们的字段。
    ⚠ `status` 三个取值：`initialized`（两张表都空 —— 一份坐标都没有，谈不上确认）/
      `draft`（有内容、还没确认过）/ `confirmed`（闸门放行）。
    ⚠ 客户说「宽窄不一 / 间距不匀 / 错落」时：**那不在阶段二里**（属阶段三的资产尺寸差异 +
      ±5° 抖动、阶段四的换小一号户型 / 微调边界，**这两个阶段都还没实现**），
      **照实说明，别拿「改参数」糊弄**（「错落」没有任何参数能表达）。

    ⚠ **开场先查状态**：任何「走到哪了 / 下一步干什么 / 怎么搭」的回答**之前**先调本工具
      （与 get_asset_list 配套）。报「自检过了」必须报 `checks_failed` 与 `failed_names`，
      不许只说「几何自检通过」。
    ⚠ **只读**：不改几何、不确认、不猜。
    ⚠ `gate.confirmed = false` → **一律不许进第三阶段**（AGENTS.md「规划图闸门」）。
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        return PlanStatus(
            has_plan=False,
            next_step=(
                "还没算过规划：先 generate_plan() 算一版，再让用户/客户过目确认。"
                "**没有确认过的规划之前，不许往关卡里摆任何东西。**"
            ),
            warnings=["views/plan_v1.json 不存在。"],
        )

    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    gate = _gate_model(planning.gate_check(plan))
    summary = _summarize(plan)
    status = str(plan.get("status") or ("initialized" if not (
        plan.get("assets") or plan.get("whiteboxes")) else "draft"))
    if gate.confirmed:
        status = "confirmed"

    warnings: list[str] = []
    if status == "initialized":
        warnings.append(
            "**这是初始化状态**（`assets` / `whiteboxes` 都是空的）—— 结构立好了，"
            "但**一份坐标都没有**：坐标的依据（参考图）还没来。此时谈不上确认，也不许进第三阶段。"
        )
    if not gate.confirmed:
        warnings.append("这份规划**还没被确认** —— 不许进第三阶段。")
    if not gate.plan_hash_ok:
        warnings.append("plan_v1.json 的数据被手改过，与写进去时不一致 —— 这份规划作废。")
    if summary.checks_failed:
        warnings.append(f"自检有 {summary.checks_failed} 项没过：{summary.failed_names}")
    # 图与数据一致吗（收尾清单 #8）—— 空规划阶段不谈图，不喊
    if status != "initialized":
        try:
            fig = planning.figure_check(plan)
        except Exception as exc:        # noqa: BLE001 —— 图检查失败不该把读工具带崩
            warnings.append(f"图检查没跑成（{type(exc).__name__}: {exc}）。")
        else:
            if not fig["ok"]:
                warnings.append(
                    "⚠ 图不认这份数据：" + fig["note"]
                    + "（AGENTS：图与数据不一致 = 等于没确认；确认时会被拒。）"
                )

    ok = (status != "initialized") and gate.confirmed \
        and gate.plan_hash_ok and not summary.checks_failed
    return PlanStatus(
        has_plan=True,
        status=status,
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=summary,
        gate=gate,
        plan=plan if include_plan else None,
        next_step=(
            "闸门通过：可以进第三阶段（把资产按位置摆进关卡）。"
            if ok else
            (
                "**先要图**：拿 `plan_v1.json` 的数据**画一张图给用户看** —— "
                "用户读不懂 `pos` 这种坐标，**图是他唯一能参与确认的方式**。"
                "客户看完说「太挤 / 偏了 / 这栋挪一下」，就改 `pos` / `footprint_m` 重记一遍再出图，"
                "**重复到他说无误为止**；点头后用 confirm_plan(确认人) 落痕。"
                if status != "initialized" else
                "现在**没有任何坐标**：先去拿用户上传的图，走完阶段一（提元素 → 用户确认 → "
                "找资产 → 交付清单），再按图规划每件东西的 `pos` 填进来。**别在没图时编坐标。**"
            )
        ),
        warnings=warnings,
    )


# --- [完工-13] 工具 9：confirm_plan（阶段二 · 闸门）---
# 实测 2026-09-23T13:56:45Z（经 MCP 调用，用户本人确认）：
# gate.confirmed=true、confirmed_by="用户本人"、指纹一致、
# next_step 写出"阶段二闭环 —— 可以进第三阶段"；
# 并已核实写进了磁盘（plan_v1.json 的 confirmation 段）。
# 这一条是用真实确认验的，不是伪造的 —— 闸门的意义就在于没人能绕过它。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**）：工具面 9 个、本工具在链上正常。
# ✅ 2026-09-24（六）实测：新增的"**空规划拒收**"一条已验 ——
#   空结构（generate_plan() 不带参数 → status=initialized、两张表都空）落盘后，
#   调本工具 confirm_plan("验收探针") → 被 ToolError 拒（原文：「拒绝确认：这是**初始化状态**
#   （`assets` / `whiteboxes` 都空、一份坐标都没有）…」）；
#   拒收后 plan_v1.json **未被写**（get_plan 复查 plan_hash 未变、confirmed 仍 false），
#   且用**同一份 payload** 重跑 generate_plan 后几何指纹逐位回到探针前的值（6674990729…）。
# ⚠ 2026-09-24（八）本块改了：新增**第三条闸**（图不认这份数据 → 拒收）+ 确认落盘改走
#   `write_plan()`（确认前那一版自动留档、不认账的图自动清走）+ 空规划判据简化为"两张表都空"。
#   **尚未实测** —— 改完之后**没有确认过任何一版**，第一次真确认（用户看图画押）时补证据。

# --- 工具 9：确认规划（阶段二 · 闸门）------------------------------------------

@mcp.tool()
async def confirm_plan(
    confirmed_by: Annotated[str, Field(description="谁确认的（用户/客户的称呼，必填）")],
) -> PlanResult:
    """把「这份规划被确认了」写回 `plan_v1.json`：**谁 / 何时 / 哪一版**。

    闸门不过就**拒绝确认**（这就是闸门的意义）：
      ① **空规划不许确认**（两张表都空：一份坐标都没有，确认它毫无意义）；
      ② 数据指纹对不上 → `plan_v1.json` 被手改过，与写进去时不一致；
      ③ **图不认这份数据**（`views/` 里没有图 / 图里没有当前几何指纹 / 图比数据老）——
         AGENTS：图与数据不一致 = 等于没确认。图由 AI 手绘，**画完把当前指纹写进图里**。

    ⚠ 确认是**人的动作**：只有用户/客户**看过图并点头**之后，才准调它。
      你自己看着"差不多"就确认 = 把闸门作废。
    ⚠ **必须先给用户看图** —— 他读不懂坐标，图是他唯一能判断的依据。
    ⚠ 确认之后坐标一改，指纹就对不上，本次确认**自动作废**。
    ⚠ 落盘走 `planning.write_plan()`：确认前的那一版会**自动留档**到 `views/archive/`；
      **不认这份数据的图会被代码自动清除**（也移进 `views/archive/`）—— 图这件事不许靠人记得。
    """
    planning = _planning_modules()
    if not planning.OUT_JSON.exists():
        raise ToolError("还没有规划数据：先 generate_plan() 记一版，让用户过目之后再确认。")

    plan = json.loads(planning.OUT_JSON.read_text(encoding="utf-8-sig"))
    if not (plan.get("assets") or plan.get("whiteboxes")):
        raise ToolError(
            "拒绝确认：这是**初始化状态**（`assets` / `whiteboxes` 都空、一份坐标都没有）。"
            "先把放置表填上（先已有资产、后白膜），出图给用户看过，再确认。"
        )
    gate = planning.gate_check(plan)
    if not gate["plan_hash_ok"]:
        raise ToolError("拒绝确认：plan_v1.json 的数据与写进去时不一致（被改过）。")

    # --- ⚠ 图与数据必须一致（2026-09-24 收尾清单 #8）---
    # 判据在 planning.figure_check()：views/ 里要有图，且图认这份数据（svg 看指纹、位图看时间）。
    fig = planning.figure_check(plan)
    if not fig["ok"]:
        raise ToolError(
            "拒绝确认：图不认这份数据 —— " + fig["note"]
            + " 请拿 views/plan_v1.json 重画一张（**图内写明当前几何指纹**），再确认。"
        )

    plan = planning.mark_confirmed(plan, confirmed_by)
    written = planning.write_plan(plan)
    notes: list[str] = []
    if written.get("archived"):
        notes.append(f"确认前的那一版已留档：views/archive/{written['archived']}。")
    if written.get("removed_figures"):
        notes.append("已清除不认这份数据的图（移进 views/archive/）："
                     + "；".join(written["removed_figures"]) + "。")
    return PlanResult(
        stage="阶段二 · 平面放置规划",
        data_path=str(planning.OUT_JSON),
        image_path="",
        summary=_summarize(plan),
        gate=_gate_model(planning.gate_check(plan)),
        changed_params=[],
        next_step=(
            f"已确认并留痕（确认人：{confirmed_by}）。**阶段二闭环** —— "
            "可以进第三阶段：按这份放置表把东西摆进关卡。"
        ),
        warnings=notes,
    )


# --- 启动区 -------------------------------------------------------------------
# 只有"直接运行这个文件"时才启动；被 mcp dev / mcp run / 宿主导入时不启动。
if __name__ == "__main__":
    # 不带参数 = stdio（进程直连），由宿主负责启动这个进程
    mcp.run()

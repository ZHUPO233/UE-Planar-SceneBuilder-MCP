# =============================================================================
# 阶段二 · 平面放置规划（纯 2D 几何，单位统一米）
#
# 【这个阶段产出什么】
#   一份**放置数据结构** views/plan_v1.json：平面世界中心/大小 + **每个物体一行**的
#   平面坐标与占地。**不是**一套写死的几何骨架 —— 图不同、地图不同，这份数据就不同。
#
# 【谁提供什么】
#   world.size / world.center … 从阶段一的元素清单里读（`catalog/elements.json` 的
#                                「地图大小」场景项）；调用方可以覆盖。
#   每个物体的 pos / footprint … **agent 自己规划**（这里只做校验与落盘，不替它摆）。
#   已有资产的占地大小 …… = 阶段一**实测**的包围盒 × scale（大小是定的）。
#   白膜的占地大小 ……… 必须在**放完已有资产之后**再估（先占位才知道剩哪儿）。
#
# 【为什么没有出图和参数文件】
#   2026-09-24 用户拍板：① 不用固定模板画图（图由 AI 自己拿这份数据画）；
#   ② 参数不再落盘成单独文件，而是**记进本数据的 `params` 段**（哪一版是拿什么算的）。
#
# 【坐标】UE 左手系 Z-up：X 前进、Y 右、Z 上；平面内**右法线 = (-dy, dx)**（唯一口径）
#
# 【怎么跑】纯离线，不碰 UE：
#     $env:PYTHONPATH='F:\MCP_Server\src'
#     & F:\MCP_Server\.venv\Scripts\python.exe -m mcp_server.planning.plan          # 算默认一版
#     & F:\MCP_Server\.venv\Scripts\python.exe -m mcp_server.planning.plan --confirm "确认人"
# =============================================================================

# --- [完工-10] 阶段二几何 + 确认留痕 + 自检 ---
# 实测 2026-09-23：旧版（路网/地块骨架）自检 14/14 全过、确认留痕六条路径全过。
# 实测 2026-09-24（**check_tools 60 通过 / 0 失败**，用户喂回的原始输出）：
#   本文件被整段换成"放置表"之后，main.py 仍能起来、9 个工具全部注册成功
#   （check_tools 第一组就是在 import main.py 之后验工具面）；
#   阶段二那三个工具经 MCP 端到端调用：拒收路径验不过的行 / 拒收没写 shape 的白膜行，两条都绿。
# ⚠ 2026-09-24（四）整段换掉（用户新规格：只留元素放置，路网/地块/绿化区全由 agent 规划）。
#   旧版的多边形骨架算法（offset_polyline / band / lots / green_zones …）已随规格一起删除；
#   要恢复见 git 历史。
# ✅ 2026-09-24（六）实测补齐 —— 原先那两条「尚未实测」的分支，现在都有证据了：
#   ① 「空结构（status=initialized）落盘」：generate_plan() 不带参数 →
#      7 项自检 0 失败、world=[120,30]（读当次 elements.json 的『地图大小』场景项）、
#      两张表 []、gate.confirmed=false；get_plan() 复查 status=initialized。
#   ② 「拒收空规划（CLI 闸）」：`python -m mcp_server.planning.plan --confirm "验收探针"`
#      → 打印「拒绝确认：这是**初始化状态**…」、**退出码 4**；
#      随后 get_plan() 复查 plan_hash 与拒收前一致 —— 证明这次拒收**没写盘**。
#   ③ 「拒收空规划（MCP 闸，main.py 那条）」：confirm_plan("验收探针")
#      → ToolError「拒绝确认：这是**初始化状态**（`assets` / `whiteboxes` 都空…）」；
#      再用**同一份 payload** 重跑 generate_plan，几何指纹逐位回到探针前的值
#      （6674990729…），证明拒收无副作用、且 draft 可原样恢复。
# ✅ 2026-09-24（八）实测（新代码上线后经 MCP 调用观察到 —— 收尾清单 #1~#8 那一批）：
#   · 自检 **11 项 0 失败**在真数据上跑通（get_plan 返回 checks_total=11 / failed=0、
#     plan_hash=19cd2005a0…）：⑧⑨⑩ 阶段一↔阶段二对账三条、⑪ cube 高度都在链上；
#   · `write_plan()` 的**自动留档**生效：views/archive/ 里已有 6 份
#     `plan_v1_<UTC时间戳>_{draft|confirmed}.json`（其中 1 份是用户确认过的那版）；
#   · `clear_stale_figures()` 的**自动清图**生效：4 张旧图被移进 views/archive/，
#     views/ 里只剩当前那一张（且图内写有当前几何指纹）。
# ⚠ **仍未实测**：改完之后的 `confirm_plan`（MCP 与本文件 CLI 两条）**一次都没被调过** ——
#   它新加的"图不认数据就拒收"那条闸、确认时的留档与清图，等第一次真确认再补证据。

import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

# --- 常量 ---------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parents[3]
"""仓库根目录。本文件在 src/mcp_server/planning/ 下，往上三层即根。"""

VIEWS_DIR = REPO_ROOT / "views"
OUT_JSON = VIEWS_DIR / "plan_v1.json"
ARCHIVE_DIR = VIEWS_DIR / "archive"
"""每一版 plan_v1.json 的留档目录（2026-09-24 收尾清单 #4：确认版必须留得下来）。"""

# 给用户看的那张图的文件名候选（**图由 AI 手绘，代码不出图**）—— figure_check() 按这些模式找
FIGURE_GLOBS = ("plan_v1_overview*.svg", "plan_v1_overview*.png",
                "plan_v1_overview*.jpg", "plan_v1_overview*.jpeg",
                "plan_v1_overview*.webp", "plan_v1_overview*.gif")

ELEMENTS_PATH = REPO_ROOT / "catalog" / "elements.json"
"""阶段一的元素清单 —— 本阶段从这里读「地图大小」和「有哪些元素」。"""

Point = tuple[float, float]
Poly = list[Point]

# 场景项（不是物体）：它们的 element_key 不许出现在放置表里
SCENE_KEYS = ("map_size", "time_of_day")
# 白膜形状：cube（体）/ plane（覆盖面）
WHITEBOX_SHAPES = ("cube", "plane")
# 白膜行的尺寸来源必须含这两个字（预估值不许伪装成实测值）
ESTIMATED_MARK = "预估"


def load_json(path: Path):
    """读 JSON；不存在或读不动 → None（第一次跑本来就没有，不是错误）。"""
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None


# --- 占地矩形（阶段二特有的"最小几何"）----------------------------------------

def rect_corners(pos: Point, footprint: tuple[float, float],
                 rot_deg: float = 0.0) -> Poly:
    """把一个物体的**占地矩形**算成四个角（逆时针）。

    占地的定义：以 `pos`（平面中心坐标）为中心，`footprint = (宽, 深)`，
    绕 Z 轴逆时针转 `rot_deg` 度。返回 `[左下, 右下, 右上, 左上]`（旋转后）。

    ⚠ 为什么中心化 + 单独一个 rot：agent 规划时改"位置"和改"朝向"是两件事，
      绑在一起会让"往右挪 2 m"这种修改变成要重算四个角 —— 那是给 agent 下绊子。
    """
    hw, hd = float(footprint[0]) / 2.0, float(footprint[1]) / 2.0
    a = math.radians(float(rot_deg))
    ca, sa = math.cos(a), math.sin(a)
    out: Poly = []
    for dx, dy in ((-hw, -hd), (hw, -hd), (hw, hd), (-hw, hd)):
        out.append((pos[0] + dx * ca - dy * sa, pos[1] + dx * sa + dy * ca))
    return out


def rect_inside_bounds(corners: Poly, bounds: dict) -> bool:
    """四个角是不是都在世界边界内（含边界，留 1e-6 容差）。"""
    x0, y0 = bounds["min"]
    x1, y1 = bounds["max"]
    return all(x0 - 1e-6 <= p[0] <= x1 + 1e-6 and y0 - 1e-6 <= p[1] <= y1 + 1e-6
               for p in corners)


# --- 纯 2D 基础（无业务；重叠判定要用，阶段三/四的碰撞检测也会用）--------------

def v_add(a: Point, b: Point) -> Point:
    """向量相加：逐分量相加。"""
    return (a[0] + b[0], a[1] + b[1])


def v_sub(a: Point, b: Point) -> Point:
    """向量相减 a-b：求「从 a 指向 b」的方向。"""
    return (a[0] - b[0], a[1] - b[1])


def v_mul(a: Point, k: float) -> Point:
    """向量乘标量：把方向按长度缩放。"""
    return (a[0] * k, a[1] * k)


def v_len(a: Point) -> float:
    """向量长度（hypot 比 sqrt(x²+y²) 稳，中间不溢出）。"""
    return math.hypot(a[0], a[1])


def v_unit(a: Point) -> Point:
    """单位化；零向量原样返回（由调用方自己判，这里不抛异常）。"""
    n = v_len(a)
    return (0.0, 0.0) if n == 0.0 else (a[0] / n, a[1] / n)


def v_dot(a: Point, b: Point) -> float:
    """点积：判朝向是否一致（>0 = 大致同向）。"""
    return a[0] * b[0] + a[1] * b[1]


def cross(a: Point, b: Point) -> float:
    """2D 叉积（标量）：>0 表示 b 在 a 的逆时针侧；=0 共线。"""
    return a[0] * b[1] - a[1] * b[0]


def right_normal(d: Point) -> Point:
    """【全局唯一口径】右手法线：d = (dx, dy) → (-dy, dx)。

    ⚠ 定错方向，人行道/地块会整体镜像到马路另一边，且**不报错**。
    """
    return (-d[1], d[0])


def polygon_area(poly: Poly) -> float:
    """鞋带公式算**带符号**面积（逆时针为正）。⚠ 不许在外面偷偷取绝对值。"""
    total = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]      # % n 让末点接回首点，闭合
        total += x1 * y2 - x2 * y1
    return total / 2.0


def aabb_of(poly: Poly) -> dict:
    """多边形的轴对齐包围盒（AABB）：min/max 两个角。"""
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return {"min": [min(xs), min(ys)], "max": [max(xs), max(ys)]}


def _seg_hit(a: Point, b: Point, c: Point, d: Point) -> bool:
    """线段 ab 与 cd 是否「真交叉」（仅共端点/共线不算）。"""
    def side(p: Point, q: Point, r: Point) -> int:
        val = cross(v_sub(q, p), v_sub(r, p))
        if abs(val) < 1e-12:
            return 0
        return 1 if val > 0 else -1

    s1, s2 = side(a, b, c), side(a, b, d)
    s3, s4 = side(c, d, a), side(c, d, b)
    return s1 != s2 and s3 != s4 and 0 not in (s1, s2, s3, s4)


def point_in_polygon(p: Point, poly: Poly) -> bool:
    """射线法判点是否在多边形内（"一个东西有没有套在另一个里"要靠它）。"""
    x, y = p
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):        # 这条边跨过 p 的水平线
            hit_x = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < hit_x:
                inside = not inside
        j = i
    return inside


def polygons_overlap(a: Poly, b: Poly) -> bool:
    """两个多边形是否有**面积重叠**（仅共边、仅共点 → 不算重叠）。

    为什么不用"角点在不在对方里面"来判：**贴边摆放是允许的**（相邻两栋楼共墙、
    马路与人行道相接），而射线法对"边界上的点"判定不确定 —— 2026-09-23 实测因此误报过。
    所以判两步，都不依赖"边界点算内还是算外"：
      ① 任意一条边与对方任意一条边**真交叉**（`_seg_hit` 已排除共线/共端点）→ 重叠；
      ② 没有交叉时，再用**形心**判包含关系（一个完全套在另一个里也算重叠）。
         用形心不用顶点：凸多边形的形心一定在内部，不会落在边上。
    """
    na, nb = len(a), len(b)
    for i in range(na):
        for j in range(nb):
            if _seg_hit(a[i], a[(i + 1) % na], b[j], b[(j + 1) % nb]):
                return True
    cen_a = (sum(p[0] for p in a) / na, sum(p[1] for p in a) / na)
    cen_b = (sum(p[0] for p in b) / nb, sum(p[1] for p in b) / nb)
    return point_in_polygon(cen_a, b) or point_in_polygon(cen_b, a)


def clean_numbers(obj):
    """输出前把 **-0.0 归一成 0.0**（递归处理 dict / list / tuple）。

    为什么非做不可（2026-09-23 实测踩过，写在 main.py 的 num() 注释里）：
      Python 把 -0.0 序列化成 "-0.0"，而 JS 的 JSON.stringify(-0) 得到 "0" —— **往返不无损**，
      宿主会判定整条结果 "value is not lossless JSON" 并**整条拒绝**（不是丢一个字段，是整条不可用）。
      本文件里 -0.0 的来源很具体：`right_normal((1,0)) = (-0.0, 1.0)`（对 0 取负），
      再顺着 `facing_vector` 之类的字段漏进 JSON。

    ⚠ 非有限值（inf / nan）**不在这里静默修正** —— 那是真错误，应该炸出来看得见
      （配合 json.dumps(..., allow_nan=False)，它会直接抛异常而不是写出非法 JSON）。
    """
    if isinstance(obj, bool):        # bool 是 int 子类，先挡掉，别被当成数字处理
        return obj
    if isinstance(obj, float):
        return 0.0 if obj == 0.0 else obj
    if isinstance(obj, dict):
        return {k: clean_numbers(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean_numbers(v) for v in obj]
    return obj


# --- 放置表装配与校验 ---------------------------------------------------------

def load_previous_elements(path: Path = ELEMENTS_PATH) -> dict:
    """读阶段一的元素清单（`catalog/elements.json`）→ `(全部行, 人话场景项)`。

    为什么要读它（**不是多此一举**）：
      ① 「地图大小」是阶段一记的场景项 → 本阶段的世界大小默认值从这儿来，不靠人再报一遍；
      ② 放置表里的 `element_key` **必须**在阶段一确认过的清单里有记录
         （不许凭空多出一个元素 —— 那样等于规划了图里没有的东西）。
    读不到就返回空表：由调用方决定是报错还是只警告（这里**不抛**）。
    """
    doc = load_json(path) or {}
    rows = [e for e in (doc.get("elements") or []) if isinstance(e, dict)]
    scene: dict[str, str] = {}
    for e in rows:
        cat = str(e.get("category") or "")
        if cat == "map_size" and isinstance(e.get("size_m"), (list, tuple)) \
                and len(e["size_m"]) >= 2:
            scene["size_m"] = f"{float(e['size_m'][0]):g}×{float(e['size_m'][1]):g} m（阶段一记录）"
        elif cat == "time_of_day" and str(e.get("time_of_day") or "").strip():
            scene["time_of_day"] = str(e["time_of_day"]).strip()
    return {"rows": rows, "scene": scene, "confirmed_at": doc.get("confirmed_at", "")}


def normalize_world(given: dict | None, scene: dict, previous: dict) -> tuple[dict, list[str]]:
    """定出世界中心与大小 → `(world, 说明改了哪几处)`。

    默认值：**中心 = 世界原点 (0,0)**（2026-09-24 用户定）；**大小 = 阶段一记录的**
    「地图大小」场景项。调用方给的值优先，且**必须写清来源**（是阶段一的记录、还是你改过的）。
    """
    center = [0.0, 0.0]
    size: list[float] | None = None
    size_source = ""
    changed: list[str] = []

    for e in previous.get("rows") or []:
        if str(e.get("category") or "") == "map_size" and isinstance(e.get("size_m"), (list, tuple)) \
                and len(e["size_m"]) >= 2:
            size = [float(e["size_m"][0]), float(e["size_m"][1])]
            size_source = "阶段一 elements.json 的『地图大小』场景项"
    if size is None:
        raise ValueError(
            "世界大小没有来源：阶段一 elements.json 里没有『地图大小』场景项 —— "
            "请先在阶段一用 confirm_elements 填它，或由调用方显式给 world.size。"
        )

    g = given or {}
    if "center" in g:
        c = g["center"]
        if not (isinstance(c, (list, tuple)) and len(c) >= 2):
            raise ValueError("world.center 要写成 [X, Y]（米）")
        if [float(c[0]), float(c[1])] != center:
            changed.append("world.center")
        center = [float(c[0]), float(c[1])]
    if "size" in g:
        s = g["size"]
        if not (isinstance(s, (list, tuple)) and len(s) >= 2):
            raise ValueError("world.size 要写成 [X, Y]（米）")
        if min(float(s[0]), float(s[1])) <= 0:
            raise ValueError("world.size 必须都是正数（米）")
        if [float(s[0]), float(s[1])] != size:
            changed.append("world.size")
        size = [float(s[0]), float(s[1])]
        size_source = "调用方覆盖（不是阶段一记录）"

    hx, hy = size[0] / 2.0, size[1] / 2.0
    bounds = {
        "min": [center[0] - hx, center[1] - hy],
        "max": [center[0] + hx, center[1] + hy],
    }
    world = {
        "center": center,
        "size": size,
        "size_source": size_source,
        "bounds": bounds,
        "coordinate_system": {
            "handedness": "left",
            "height_axis": "Z",
            "forward_axis": "X",
            "right_axis": "Y",
            "right_normal_rule": "right_normal(d) = (-dy, dx)",
        },
    }
    return world, changed


def _norm_placement(raw: dict) -> dict:
    """把一行放置记录的数字字段规整成浮点/列表（缺字段直接报错，不猜）。"""
    if not isinstance(raw, dict):
        raise ValueError(f"放置记录必须是对象，收到 {type(raw).__name__}")
    key = str(raw.get("element_key") or "").strip()
    if not key:
        raise ValueError("放置记录缺 element_key（要与阶段一的元素名一致）")
    if key in SCENE_KEYS:
        raise ValueError(
            f"{key!r} 是**场景项**、不是物体 —— 它不该出现在放置表里"
            "（地图大小 / 时间已记在本数据的 world / 阶段一清单里）"
        )
    pos = raw.get("pos")
    if not (isinstance(pos, (list, tuple)) and len(pos) >= 2):
        raise ValueError(f"{key!r} 缺 pos —— 每一条放置都必须给平面中心坐标 [X, Y]（米）")
    fp = raw.get("footprint_m")
    if not (isinstance(fp, (list, tuple)) and len(fp) >= 2):
        raise ValueError(f"{key!r} 缺 footprint_m —— 每一条放置都必须给占地 [宽, 深]（米）")
    item = {
        "element_key": key,
        "label": str(raw.get("label") or "").strip(),
        "pos": [float(pos[0]), float(pos[1])],
        "footprint_m": [float(fp[0]), float(fp[1])],
        "rot_deg": float(raw.get("rot_deg") or 0.0),
        "note": str(raw.get("note") or ""),
    }
    if not (item["footprint_m"][0] > 0 and item["footprint_m"][1] > 0):
        raise ValueError(f"{key!r} 的 footprint_m 必须都是正数（米）")
    return item


def normalize_asset(raw: dict) -> dict:
    """规整一行**已有资产**放置；校验它是"有资产的元素"。"""
    item = _norm_placement(raw)
    path = str(raw.get("asset_path") or "").strip()
    if not path:
        raise ValueError(
            f"{item['element_key']!r} 在 assets[] 里却没给 asset_path —— "
            "**没有资产的元素请写进 whiteboxes[]**，不要混进已有资产表"
        )
    scale = raw.get("scale")
    if scale is None:
        raise ValueError(f"{item['element_key']!r} 缺 scale（模型缩放倍率）")
    if float(scale) <= 0:
        raise ValueError(f"{item['element_key']!r} 的 scale 必须为正")
    item["asset_path"] = path
    item["scale"] = float(scale)
    return item


def normalize_whitebox(raw: dict) -> dict:
    """规整一行**白膜**放置；校验"没有资产"的三样（路径空 / 有形状 / 尺寸是预估）。"""
    item = _norm_placement(raw)
    if str(raw.get("asset_path") or "").strip():
        raise ValueError(
            f"{item['element_key']!r} 是白膜行，asset_path 必须留空 —— "
            "有资产就该写进 assets[]，不能两边都写"
        )
    shape = str(raw.get("shape") or "").strip().lower()
    if shape not in WHITEBOX_SHAPES:
        raise ValueError(
            f"{item['element_key']!r} 的白膜缺 shape，只能是 {' / '.join(WHITEBOX_SHAPES)}"
            "（cube = 有体积的，plane = 覆盖面）"
        )
    src = str(raw.get("size_source") or "").strip()
    if ESTIMATED_MARK not in src:
        raise ValueError(
            f"{item['element_key']!r} 的白膜必须写明尺寸是**预估**"
            f"（size_source 里要有『{ESTIMATED_MARK}』二字，现在写的是 {src!r}）—— "
            "预估值不许伪装成实测值"
        )
    item["shape"] = shape
    item["size_source"] = src
    # --- 高度（Z）—— 选填，但给了就要校验（2026-09-24 收尾清单 #2）---
    # 为什么必须补这个字段：阶段一的白膜本来就有三维（size_cm = [X, Y, Z]，例如消防栓
    # [30, 30, 75]），可阶段二以前只记平面占地 —— **高度在阶段二被丢掉了**，只活在 note 里；
    # 阶段六要拿它把 cube 实例化出来，那时只能靠人读中文备注。
    # cube（有体积的）缺高度时由自检第⑪项报出来；plane（覆盖面）不需要。
    h = raw.get("height_m")
    if h is not None and str(h).strip() != "":
        try:
            height_m = float(h)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{item['element_key']!r} 的 height_m 不是数字：{h!r}") from exc
        if height_m <= 0:
            raise ValueError(f"{item['element_key']!r} 的 height_m 必须为正（米）")
        item["height_m"] = height_m
    return item


def build_checks(assets: list, whiteboxes: list, world: dict, known: set,
                 no_asset: set, source_note: str = "",
                 no_asset_known: bool = True,
                 expected: dict | None = None, asset_keys: set | None = None,
                 measured_ok: bool = False, measured_note: str = "") -> list:
    """算出自检项（每项**具名**，失败时带 `bad` 明细）。纯函数，不落盘。

    `known` / `no_asset` / `expected` / `asset_keys` 由调用方判好传进来（它们要看阶段一的
    **两份**文件，属于"取数"不属于"检查"）；这里只做纯几何与集合判定。

    ⚠ `no_asset_known=False` = "哪些元素没有可用资产"**判不出来**（交付清单读不到、
      旧 `elements.json` 又没 `is_placeholder` 字段）。这时第 ⑦ 项**不许冒充判过**：
      它不报红（会全是假红），但要在 `note` 里写明**没验**。
    ⚠ `measured_ok=False` 同理：交付清单里的**实测尺寸**读不到时，第 ⑧⑨ 项也**不许冒充判过**。

    参数：
      `expected`  —— 资产路径 → (X 米, Y 米)，来自阶段一官方 `get_bounds` 的**实测**包围盒；
      `asset_keys`—— 交付清单里"**有**资产"（非白膜）的元素关键词集合。
    """
    checks: list[dict] = []

    # ① 每条占地都是正的（归一化时也拦了，这里留痕，证明算过）
    bad_pos = [a["label"] or a["element_key"] for a in assets + whiteboxes
               if min(a["footprint_m"]) <= 0]
    checks.append({"name": "每条占地的宽/深都为正", "bad": bad_pos, "ok": not bad_pos})

    # ② 所有占地的四角都在世界边界内
    out = []
    for it in assets + whiteboxes:
        if not rect_inside_bounds(
                rect_corners(it["pos"], it["footprint_m"], it["rot_deg"]), world["bounds"]):
            out.append(it["label"] or it["element_key"])
    checks.append({"name": "所有占地的四角都在世界边界内", "bad": out, "ok": not out})

    # ③④⑤ 两两不重叠（面积重叠才算；共边/贴着是允许的）
    def pairs(items: list, tag_a: str, tag_b: str) -> list:
        polys = [(it["label"] or it["element_key"],
                  rect_corners(it["pos"], it["footprint_m"], it["rot_deg"]))
                 for it in items]
        bad = []
        for i in range(len(polys)):
            for j in range(i + 1, len(polys)):
                if polygons_overlap(polys[i][1], polys[j][1]):
                    bad.append(f"{polys[i][0]} × {polys[j][0]}")
        return bad

    bad_a = pairs(assets, "asset", "asset")
    checks.append({"name": "已有资产两两不重叠", "bad": bad_a, "ok": not bad_a})
    bad_w = pairs(whiteboxes, "whitebox", "whitebox")
    checks.append({"name": "白膜两两不重叠", "bad": bad_w, "ok": not bad_w})

    bad_cross = []
    for a in assets:
        pa = rect_corners(a["pos"], a["footprint_m"], a["rot_deg"])
        for w in whiteboxes:
            pw = rect_corners(w["pos"], w["footprint_m"], w["rot_deg"])
            if polygons_overlap(pa, pw):
                bad_cross.append(
                    f"{a['label'] or a['element_key']} × {w['label'] or w['element_key']}"
                )
    checks.append({
        "name": "白膜不压已有资产（= 先放资产、再放白膜）",
        "bad": bad_cross, "ok": not bad_cross,
    })

    # ⑥ 每个 element_key 都必须在阶段一确认过的清单里有记录
    unknown = sorted({it["element_key"] for it in assets + whiteboxes} - known) if known else []
    checks.append({
        "name": "每个元素的 element_key 都在阶段一的清单里有记录",
        "bad": unknown, "ok": not unknown,
        "note": source_note if known else "读不到阶段一的清单，这条**没验**",
    })

    # ⑦ 白膜只能盖在"阶段一没有可用资产"的元素上
    #    判据来源：**优先 catalog/asset_list.json**（交付清单里 `is_placeholder=true` 那些），
    #    读不到就不冒充判过（见 docstring 里那段）。
    if not no_asset_known:
        checks.append({
            "name": "白膜只用在『阶段一没有可用资产』的元素上",
            "bad": [], "ok": True,
            "note": "⚠ **没验**：" + (source_note or "判不出哪些元素没有可用资产"),
        })
    else:
        stray = sorted({w["element_key"] for w in whiteboxes} - no_asset) if known else []
        checks.append({
            "name": "白膜只用在『阶段一没有可用资产』的元素上",
            "bad": stray, "ok": not stray,
            "note": source_note,
        })

    # --- ⑧⑨ 阶段一 ↔ 阶段二 的**对账**（2026-09-24 收尾清单 #1）------------------
    # 为什么非有不可：AGENTS 的口径是"已有资产占地 = 阶段一**实测**包围盒 × scale"，可这条
    # 以前**没有任何人查** —— 把 footprint_m 随手改成两倍、或漏放整个白膜元素，自检照样全绿。
    # 于是"自检全绿"这件事本身不可信。这三项就是对账的守门员。
    #
    # ⚠ **初始化状态（两张表都空）例外**：那时"元素还没落位"是**设计如此**，不是漏放。
    #   不例外处理的话，`generate_plan()` 空跑一次就会报红（⑨⑩）—— 初始化状态直接被判成
    #   "不及格"，也就是"初始化后又用不了了"。所以覆盖类检查在空表时标成**不适用**。
    both_empty = not assets and not whiteboxes
    if not measured_ok:
        no_measured = "⚠ **没验**：" + (measured_note or "读不到交付清单里的实测尺寸")
        checks.append({
            "name": "已有资产占地 = 阶段一实测包围盒 × scale（按 asset_path 对账）",
            "bad": [], "ok": True, "note": no_measured,
        })
        checks.append({
            "name": "交付清单里『有资产』的元素都已落位",
            "bad": [], "ok": True, "note": no_measured,
        })
    else:
        table = expected or {}
        bad_scale: list[str] = []
        for a in assets:
            path = str(a.get("asset_path") or "")
            got = table.get(path)
            where = a["label"] or a["element_key"]
            if got is None:
                bad_scale.append(f"{where}：路径不在交付清单的实测尺寸里（{path}）")
                continue
            want_x, want_y = got[0] * a["scale"], got[1] * a["scale"]
            have_x, have_y = a["footprint_m"][0], a["footprint_m"][1]
            # 容差 0.02 m：数据本身保留两位小数（厘米级差异才算对不上，不许拿舍入报假红）
            if abs(want_x - have_x) > 0.02 or abs(want_y - have_y) > 0.02:
                bad_scale.append(
                    f"{where}：占地填的是 {have_x:g}×{have_y:g} m，"
                    f"而实测包围盒×scale = {want_x:.2f}×{want_y:.2f} m"
                )
        checks.append({
            "name": "已有资产占地 = 阶段一实测包围盒 × scale（按 asset_path 对账）",
            "bad": bad_scale, "ok": not bad_scale, "note": measured_note,
        })
        placed_asset_keys = {a["element_key"] for a in assets}
        missing_asset = sorted(set(asset_keys or ()) - placed_asset_keys)
        if both_empty:
            checks.append({
                "name": "交付清单里『有资产』的元素都已落位",
                "bad": [], "ok": True,
                "note": "初始化状态（两张表都空）：覆盖对账**不适用** —— 填了放置表才有意义",
            })
        else:
            checks.append({
                "name": "交付清单里『有资产』的元素都已落位",
                "bad": missing_asset, "ok": not missing_asset,
                "note": measured_note + "；没落位的要么补上行、要么在 params 里写明为什么不放",
            })

    # --- ⑩ 无资产元素的**覆盖完整性**：漏一个就是"未经记录地消失" ---------------
    if not no_asset_known:
        checks.append({
            "name": "阶段一判成『无资产』的元素都已落位（每个都有白膜行）",
            "bad": [], "ok": True,
            "note": "⚠ **没验**：" + (source_note or "判不出哪些元素没有可用资产"),
        })
    elif both_empty:
        checks.append({
            "name": "阶段一判成『无资产』的元素都已落位（每个都有白膜行）",
            "bad": [], "ok": True,
            "note": "初始化状态（两张表都空）：覆盖对账**不适用** —— 填了放置表才有意义",
        })
    else:
        placed_box_keys = {w["element_key"] for w in whiteboxes}
        missing_box = sorted(set(no_asset or ()) - placed_box_keys)
        checks.append({
            "name": "阶段一判成『无资产』的元素都已落位（每个都有白膜行）",
            "bad": missing_box, "ok": not missing_box, "note": source_note,
        })

    # --- ⑪ 白膜里的 cube 必须记了高度（2026-09-24 收尾清单 #2）-------------------
    no_height = [w["label"] or w["element_key"] for w in whiteboxes
                 if w.get("shape") == "cube" and not w.get("height_m")]
    checks.append({
        "name": "白膜里的 cube 都记了 height_m（阶段六实例化要用）",
        "bad": no_height, "ok": not no_height,
        "note": "plane（覆盖面）不需要高度；cube 缺高度时，阶段六只能靠人读 note 里的中文",
    })

    return checks


def build_plan(assets: list, whiteboxes: list, world: dict,
               params: dict | None = None, previous: dict | None = None,
               known: set | None = None, no_asset: set | None = None,
               source_note: str = "", no_asset_known: bool = True,
               expected: dict | None = None, asset_keys: set | None = None,
               measured_ok: bool = False, measured_note: str = "") -> dict:
    """把「世界 + 两份放置表」装配成 plan_v1.json 的内容（含自检 + 指纹）。

    这个函数**不规划坐标** —— 坐标由 agent 给（那是它看图+规划的活）。
    它只做四件事：装配、校验形状、算自检、钉指纹。

    `known` / `no_asset` / `expected` / `asset_keys`（哪些元素来自阶段一、哪些没有可用资产、
    每个资产路径的实测占地）由调用方算好传进来：它们要看阶段一的**两份**文件，属于"取数"。

    ⚠ **两份表都空 = 允许**（2026-09-24 用户要求）：那是**初始化状态** —— 结构先立起来、
      内容是空的，因为坐标的依据（参考图）还没来。它不是一份可确认的规划。
    ⚠ **文件里不再写 `status`**（2026-09-24 收尾清单 #5）：以前 `build_plan` 写 `draft`、
      `mark_confirmed` 却不动它，于是确认之后文件里是 `status: "draft"` +
      `confirmation.confirmed: true` —— 同一件事两个真值来源，读文件的人会被误导。
      现在三值（`initialized` / `draft` / `confirmed`）**只由 `get_plan` 现算**：
      空表 = initialized、有内容 = draft、闸门确认 = confirmed。
    """
    previous = previous or {"rows": [], "scene": {}}
    empty = not assets and not whiteboxes

    plan = {
        "stage": "阶段二 · 平面放置规划",
        "unit": "m",
        "world": world,
        "assets": assets,
        "whiteboxes": whiteboxes,
        "params": dict(params or {}),
        "checks": build_checks(assets, whiteboxes, world,
                               set(known or ()), set(no_asset or ()),
                               source_note, no_asset_known,
                               expected=expected, asset_keys=asset_keys,
                               measured_ok=measured_ok, measured_note=measured_note),
        "previous_elements": {
            "path": "catalog/elements.json",
            "confirmed_at": previous.get("confirmed_at", ""),
            "scene": previous.get("scene", {}),
        },
        "no_asset_source": source_note,
        "note": (
            "一个物体一行、自带 pos（平面中心坐标，米）。**没有 count 字段** —— "
            "摆几个就写几行，不许用一条记录代表多个不同位置的物体（那样自检看不见它们）。"
            "已有资产先放（大小是阶段一实测的）、白膜后放（大小要等资产占完位再估）。"
            "本数据不依赖任何图片；要图就由 AI 拿这份数据自己画（代码不出图）。"
            + ("⚠ **当前是初始化状态：两张表都是空的** —— 坐标的依据（参考图）还没来，"
               "所以这里没有任何 pos。" if empty else "")
        ),
        "confirmation": {
            "required": True,
            "confirmed": False,
            "confirmed_by": "",
            "confirmed_at": "",
            "note": "未确认前不许进入第三阶段（AGENTS.md「规划图闸门」）",
        },
    }
    plan["confirmation"]["plan_hash"] = plan_geometry_hash(plan)
    return plan



# --- 确认与留痕（闸门）--------------------------------------------------------

def plan_geometry_hash(plan: dict) -> str:
    """几何指纹：对 plan_v1.json 里**除 confirmation 之外**的全部内容做哈希。

    为什么排除 confirmation：确认信息要写回同一个文件，不能把自己算进去。
    这个指纹同时覆盖两种情况 —— **参数变了**、**代码改了**，只要几何不一样指纹就不一样。

    ⚠ **内部先做数字净化（-0.0 → 0.0）**，这是必须的：
      落盘写的是净化后的值，而内存里的对象可能带 -0.0（例如 facing_vector 的 (-0.0, 1.0)），
      两边直接比就会**对着一张刚算出的图喊"文件被改过"**（2026-09-23 经 MCP 实测踩到）。
      净化收在这里、不指望每个调用方记得做 —— 单点收口才不会再漏。
    """
    body = {k: v for k, v in clean_numbers(plan).items() if k != "confirmation"}
    blob = json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def gate_check(plan: dict) -> dict:
    """闸门状态：这张规划图**还作不作数**。只读，不改任何东西。

    谁都能调（MCP 工具 / CLI / 别的 agent），判定口径只有这一份。

    ⚠ 2026-09-24 起**只有几何指纹一道闸**：参数文件删了（参数由调用方给），
      没有"哪份参数"可比。闸门管的是**这张图**，不是"这组参数"。
      `params_hash_ok` 字段保留是为了兼容旧 plan_v1.json —— 老文件里存过 params_hash，
      这里**照它比**（比不了就判 ok），免得旧确认被无理由判死。
    """
    conf = plan.get("confirmation", {}) or {}
    now_geom = plan_geometry_hash(plan)
    stored_params = conf.get("params_hash", "")
    return {
        "params_hash_ok": not stored_params,     # 新文件不存 params_hash → 恒 true
        "plan_hash_ok": (not conf.get("plan_hash")) or conf["plan_hash"] == now_geom,
        "confirmed": bool(conf.get("confirmed")),
        "confirmed_by": conf.get("confirmed_by", ""),
        "confirmed_at": conf.get("confirmed_at", ""),
        "params_hash": "",
        "plan_hash": now_geom,
        "stored_params_hash": stored_params,
        "stored_plan_hash": conf.get("plan_hash", ""),
    }


def mark_confirmed(plan: dict, who: str) -> dict:
    """返回一份**带确认信息的新 plan**（不改传入的那个对象）。

    调用方负责先过 `gate_check`：闸门不过就别确认。
    """
    out = dict(plan)
    out["confirmation"] = {
        **(plan.get("confirmation", {}) or {}),
        "required": True,
        "confirmed": True,
        "confirmed_by": who,
        "confirmed_at": datetime.now(timezone.utc).isoformat(),
        "plan_hash": plan_geometry_hash(plan),
        "note": "已确认。几何一变，指纹就对不上，本次确认自动作废。",
    }
    # 老文件里可能带着 params_hash —— 它是"上一版机制"的残留，确认时顺手清掉，
    # 免得读的人以为现在还有"参数指纹"这道闸。
    out["confirmation"].pop("params_hash", None)
    return out


def figure_verdicts(plan: dict, plan_mtime: float | None = None) -> list[dict]:
    """逐张判 `views/` 里的图**认不认这份数据** → `[{name, path, ok, why}]`（只读、离线）。

    判据（写死，两选一）：
      - **文本图（svg）**：正文里要出现**当前几何指纹的前 10 位**（图是 AI 手绘的，本来就会把
        指纹写进抬头）→ 这才叫"这张图是拿这份数据画的"；
      - **二进制图（png/jpg/webp/gif）**：读不出指纹，就退一步看**时间** ——
        图的 mtime 不能早于 `plan_v1.json`（图必须是拿这份数据画的，不能比数据还老）。

    ⚠ `plan_mtime` 是"跟哪一版数据比时间"：默认取**现在磁盘上**那份 `plan_v1.json` 的时间；
      **落盘流程里必须显式传"写盘之前"的时间**（见 `write_plan()`）—— 否则刚写进去的新数据
      一定比图新，会把**用户刚确认的那张图**也一起清掉（这条是实测推演出来的坑）。

    它是 `figure_check()`（确认时把关）与 `clear_stale_figures()`（落盘时清除）**共用的唯一判据** ——
    判据只写一处，免得两条路各说各话。
    """
    head = plan_geometry_hash(plan)[:10]
    if plan_mtime is None:
        try:
            plan_mtime = OUT_JSON.stat().st_mtime if OUT_JSON.exists() else 0.0
        except OSError:
            plan_mtime = 0.0

    found: list[Path] = []
    for pattern in FIGURE_GLOBS:
        try:
            found += [p for p in VIEWS_DIR.glob(pattern) if p.is_file()]
        except OSError:
            continue

    out: list[dict] = []
    for path in sorted(set(found)):
        if path.suffix.lower() == ".svg":
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError as exc:
                out.append({"name": path.name, "path": path, "ok": False,
                            "why": f"读不动（{exc}）"})
                continue
            if head in text:
                out.append({"name": path.name, "path": path, "ok": True,
                            "why": f"正文里有当前指纹 {head}…（认账）"})
            else:
                out.append({"name": path.name, "path": path, "ok": False,
                            "why": f"正文里没有当前指纹 {head}…（是别的版本的图）"})
        else:
            try:
                mtime = path.stat().st_mtime
            except OSError as exc:
                out.append({"name": path.name, "path": path, "ok": False,
                            "why": f"取不到修改时间（{exc}）"})
                continue
            if mtime >= plan_mtime:
                out.append({"name": path.name, "path": path, "ok": True,
                            "why": "比 plan_v1.json 新（读不出指纹，按时间判）"})
            else:
                out.append({"name": path.name, "path": path, "ok": False,
                            "why": "比 plan_v1.json 老（是别的版本的图）"})
    return out


def figure_check(plan: dict) -> dict:
    """判「views/ 里还有没有一张**认这份数据**的图」→ `{ok, figures, note}`。只读、离线。

    为什么要有它（2026-09-24 收尾清单 #8）：AGENTS 的口径是 **图与数据必须一致 ——
    不一致 = 等于没确认**，但以前全靠人自觉（实测踩到过：图里还写着"本图未经用户确认"，
    而数据早已确认）。判据见 `figure_verdicts()`。

    ⚠ 判不过时**不猜**：说清是哪张图、为什么不算数，让调用方（confirm_plan）拒收。
    """
    verdicts = figure_verdicts(plan)
    if not verdicts:
        return {
            "ok": False, "figures": [],
            "note": (f"views/ 里没有图（{' / '.join(FIGURE_GLOBS)} 都没命中）—— "
                     "图是交付的一部分，没有图就不许拿去让用户确认。"),
        }
    return {
        "ok": any(v["ok"] for v in verdicts),
        "figures": [v["name"] for v in verdicts],
        "note": "；".join(f"{v['name']}：{v['why']}" for v in verdicts),
    }


def clear_stale_figures(plan: dict, plan_mtime: float | None = None) -> tuple[list[str], list[str]]:
    """把 `views/` 里**不认这份数据**的图移进 `views/archive/` → `(移走的, 留下的)`。

    为什么要**代码自动清除**（2026-09-24 用户要求，收尾清单 #8 加码）：图是"用户确认过的那一版"
    的凭据。数据一改（指纹就变），旧图就变成**没人确认过的图** —— 留在 `views/` 里只会让人
    （和下一个 agent）误以为"这就是当前这版"。以前只能靠人记得删。
    规则写死：**只留认账的图**（判据同 `figure_verdicts()`），其余移到 archive。
    当前正在给用户看的那张只要认账就**不会被删** —— 被清掉的永远是**别的版本**的图。

    ⚠ 是"移走"不是"销毁"：进 `views/archive/`（带原文件名），免得把人家画过的图无声无息弄丢。
    """
    removed: list[str] = []
    kept: list[str] = []
    for verdict in figure_verdicts(plan, plan_mtime):
        if verdict["ok"]:
            kept.append(verdict["name"])
            continue
        path: Path = verdict["path"]
        try:
            ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            target = ARCHIVE_DIR / path.name
            n = 1
            while target.exists():
                target = ARCHIVE_DIR / f"{path.stem}_{n}{path.suffix}"
                n += 1
            path.replace(target)                 # 同盘移动，原子
            removed.append(f"{verdict['name']}（{verdict['why']}）")
        except OSError as exc:
            kept.append(f"{verdict['name']}（清不掉：{exc}）")
    return removed, kept


def write_plan(plan: dict) -> dict:
    """落盘 `plan_v1.json` —— **全工程唯一写入点**。返回
    `{"archived": 留档文件名, "removed_figures": [...], "kept_figures": [...]}`。

    写盘时顺带做两件"不许靠人记得"的事：
      - **给上一版留档**（收尾清单 #4）：闸门要回答的是"我们现在搭的，是不是当初确认的那一版"，
        可每次都覆盖同一个文件 —— 数据本体没了，只剩一个指纹数字。所以覆盖前把上一版
        原样复制进 `views/archive/`（文件名带 UTC 时间戳）。内容一模一样时不重复留档。
      - **清除不认账的图**（收尾清单 #8 加码，2026-09-24 用户要求）：数据一改，旧图就变成
        "没人确认过的图"，留在 `views/` 里只会误导人 —— 由 `clear_stale_figures()` 移进 archive。
        当前这张只要认账就留着。
    """
    VIEWS_DIR.mkdir(parents=True, exist_ok=True)
    body = json.dumps(clean_numbers(plan), ensure_ascii=False, indent=2, allow_nan=False)
    # ⚠ 先记下"写盘之前"那份数据的时间：清图时要拿它当基准（写盘之后新数据一定比图新，
    #   会把用户刚确认的那张位图也一起清掉 —— 见 figure_verdicts() 里那段）。
    prev_mtime = 0.0
    if OUT_JSON.exists():
        try:
            prev_mtime = OUT_JSON.stat().st_mtime
        except OSError:
            prev_mtime = 0.0
    archived = ""
    if OUT_JSON.exists():
        try:
            old = OUT_JSON.read_text(encoding="utf-8-sig")
        except OSError:
            old = ""
        if old.strip() and old != body:
            ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            # 归档名里带上"这一版当初**有没有被人确认过**"（2026-09-24 用户口径：**草稿不入库**）——
            # `.gitignore` 靠这个后缀决定收不收：`*_draft.json` 不入库、`*_confirmed.json` 入库。
            # 读不出来（老文件 / 手改坏了）就按草稿算：**宁可少入库，也不把没确认的东西当凭据收进去**。
            try:
                was_confirmed = bool(
                    ((json.loads(old) or {}).get("confirmation") or {}).get("confirmed"))
            except (ValueError, TypeError):
                was_confirmed = False
            kind = "confirmed" if was_confirmed else "draft"
            target = ARCHIVE_DIR / f"plan_v1_{stamp}_{kind}.json"
            n = 1
            while target.exists():          # 同一秒连写两次也不许互相覆盖
                target = ARCHIVE_DIR / f"plan_v1_{stamp}_{kind}_{n}.json"
                n += 1
            target.write_text(old, encoding="utf-8")
            archived = target.name
    OUT_JSON.write_text(body, encoding="utf-8")
    try:
        removed, kept = clear_stale_figures(plan, plan_mtime=prev_mtime)
    except OSError as exc:                  # 清图失败不该把落盘本身带崩
        return {"archived": archived, "removed_figures": [],
                "kept_figures": [f"（清图没跑成：{exc}）"]}
    return {"archived": archived, "removed_figures": removed, "kept_figures": kept}


def confirm_plan(who: str) -> int:
    """把「这张图被确认了」写回 plan_v1.json：谁、何时、哪份几何。

    闸门不过就**拒绝确认**（三条，与 MCP 工具 confirm_plan 同款）：
      ① **空规划不许确认**（两张表都空）：一份坐标都没有，确认它毫无意义 ——
         那时还没有图能给用户看；
      ② 几何指纹对不上 → plan_v1.json 被手改过，与算出来时不一致；
      ③ **图不认这份数据**（`views/` 里没有图 / 图内没有当前指纹 / 图比数据老）——
         AGENTS：图与数据不一致 = 等于没确认。

    退出码：0 已确认 / 1 文件不存在 / 3 指纹对不上 / 4 空规划 / 5 图不认数据。
    """
    if not OUT_JSON.exists():
        print("还没有 plan_v1.json：先算几何，再确认。")
        return 1
    plan = json.loads(OUT_JSON.read_text(encoding="utf-8-sig"))

    # --- ⚠ 空规划不许确认（2026-09-24 补：CLI 这条路径原先漏了这道闸）---
    # 为什么要补：本函数是 `--confirm` 走的**唯一**入口，而空规划（初始化结构）的几何指纹
    #   是**自洽**的 —— 只比指纹就一路放行，等于"一份坐标都没有的规划"也能被确认成功，
    #   闸门就等于有个后门（MCP 工具那条 confirm_plan 拦得住，这条原先拦不住）。
    # 判据与 MCP 工具那条一致：**两张表都空**即拒；老文件里还带着 `status` 字段的，一并认。
    if str(plan.get("status") or "") == "initialized" or not (
            plan.get("assets") or plan.get("whiteboxes")):
        print("拒绝确认：这是**初始化状态**（assets / whiteboxes 都空、一份坐标都没有）。")
        print("  先把放置表填上（先已有资产、后白膜），出图给用户看过，再确认。")
        return 4

    gate = gate_check(plan)

    if not gate["plan_hash_ok"]:
        print("拒绝确认：plan_v1.json 的几何与算出来时不一致（被改过）。")
        return 3

    # --- ⚠ 图与数据必须一致（2026-09-24 收尾清单 #8）---
    # 为什么放在写盘之前：确认是"人对着一张图点头"这件事的留痕。图都没认这份数据，
    # 那次点头点的就不是这一版 —— 所以图不认账时**不写盘**。
    fig = figure_check(plan)
    if not fig["ok"]:
        print("拒绝确认：图不认这份数据 —— " + fig["note"])
        print("  先拿 views/plan_v1.json 重画一张（图内写明当前几何指纹），再确认。")
        return 5

    result = write_plan(mark_confirmed(plan, who))
    print(f"已确认并留痕：{who}")
    print(f"  时间      {plan['confirmation']['confirmed_at']}")
    print(f"  几何指纹  {gate['plan_hash'][:16]}…")
    print(f"  图        {'、'.join(fig['figures'])}")
    print(f"  上一版    {result['archived'] or '（没有旧版可留档）'}")
    if result["removed_figures"]:
        print(f"  清掉的图  {'；'.join(result['removed_figures'])}（已移进 views/archive/）")
    return 0


# --- 入口 ---------------------------------------------------------------------
#
# 画图**不在本文件、也不在任何代码里**（2026-09-24 用户拍板）：
#   本文件只算几何数据；要图就由 AI 拿 plan_v1.json 自己画。


def main() -> int:
    """CLI 入口 —— **本文件不再自己算一版**，只报当前状态。

    为什么改成这样（2026-09-24 用户新规格）：放置坐标要 agent 规划，**没有"默认摆法"**
    这种东西。所以 CLI 给不出一份有意义的默认数据 —— 想算，请走 MCP 工具 `generate_plan`
    （它要你把 world / assets / whiteboxes 三段给进去）。这里只负责"看状态"和"确认"。
    """
    if not OUT_JSON.exists():
        print("还没有 plan_v1.json。")
        print("  放置坐标要由 agent 规划，本文件不生成默认摆法 —— 请调 MCP 工具 generate_plan。")
        return 1

    plan = json.loads(OUT_JSON.read_text(encoding="utf-8-sig"))
    conf = plan.get("confirmation", {}) or {}
    checks = plan.get("checks", []) or []
    failed = [c for c in checks if not c.get("ok")]

    print("阶段二 · 平面放置规划（现状）")
    print(f"  几何数据: {OUT_JSON}")
    print(f"  世界    : 中心 {plan['world']['center']}  大小 {plan['world']['size']} m"
          f"（{plan['world'].get('size_source', '来源未记录')}）")
    print(f"  已有资产: {len(plan.get('assets', []))} 个")
    print(f"  白膜    : {len(plan.get('whiteboxes', []))} 个")
    print("  确认状态: " + (f"已确认 by {conf.get('confirmed_by')} @ {conf.get('confirmed_at')}"
                          if conf.get("confirmed") else
                          "未确认 —— 不许进第三阶段"))
    for chk in checks:
        print(f"  [{'通过' if chk.get('ok') else '失败'}] {chk.get('name')}"
              + (f"  细节={chk.get('bad')}" if chk.get("bad") else ""))
    print(f"自检：{len(checks)} 项，失败 {len(failed)} 项")
    return 0 if not failed else 1


if __name__ == "__main__":
    argv = sys.argv[1:]
    if argv and argv[0] == "--confirm":
        who = argv[1] if len(argv) > 1 else "用户"
        raise SystemExit(confirm_plan(who))
    raise SystemExit(main())
